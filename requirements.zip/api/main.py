# """
# FastAPI application for Cloud Rationalization Agent
# Complete fixed version - Properly reads credentials from .env
# """
# from fastapi import FastAPI, HTTPException, Body
# from fastapi.middleware.cors import CORSMiddleware
# from typing import Dict, Any, List, Optional
# import logging
# from datetime import datetime
# import os
# import sys
# from pathlib import Path
# from dotenv import load_dotenv

# # Load environment variables FIRST - before any other imports
# load_dotenv()

# # Add project root to path
# sys.path.append(str(Path(__file__).parent.parent))

# # Import helpers
# try:
#     from src.utils.helpers import apply_ssl_fix, safe_serialize
#     apply_ssl_fix()
#     HELPERS_AVAILABLE = True
# except ImportError:
#     HELPERS_AVAILABLE = False
#     def safe_serialize(obj):
#         if hasattr(obj, 'dict'):
#             return obj.dict()
#         if hasattr(obj, 'model_dump'):
#             return obj.model_dump()
#         return obj

# logging.basicConfig(level=logging.INFO)
# logger = logging.getLogger(__name__)

# # Create FastAPI app
# app = FastAPI(
#     title="Cloud Rationalization Agent API",
#     description="AI-powered cloud infrastructure optimization",
#     version="2.0.0"
# )

# # CORS
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# # Global agent instance
# agent = None

# @app.on_event("startup")
# async def startup_event():
#     """Initialize agent on startup with credentials from .env"""
#     global agent
#     try:
#         from src.agent import CloudRationalizationAgent
        
#         # Read ALL credentials from environment
#         openai_api_key = os.getenv("OPENAI_API_KEY")
#         aws_key = os.getenv("AWS_ACCESS_KEY_ID")
#         aws_secret = os.getenv("AWS_SECRET_ACCESS_KEY")
#         azure_key = os.getenv("AZURE_SUBSCRIPTION_KEY")
#         gcp_path = os.getenv("GCP_CREDENTIALS_PATH")
        
#         # Log what we found (without exposing secrets)
#         logger.info("="*50)
#         logger.info("LOADING CREDENTIALS FROM .ENV")
#         logger.info("="*50)
#         logger.info(f"OPENAI_API_KEY: {'✅ Found' if openai_api_key else '❌ Not found'}")
#         logger.info(f"AWS_ACCESS_KEY_ID: {'✅ Found' if aws_key else '❌ Not found'}")
#         logger.info(f"AWS_SECRET_ACCESS_KEY: {'✅ Found' if aws_secret else '❌ Not found'}")
#         logger.info(f"AZURE_SUBSCRIPTION_KEY: {'✅ Found' if azure_key else '❌ Not found'}")
#         logger.info(f"GCP_CREDENTIALS_PATH: {'✅ Found' if gcp_path else '❌ Not found'}")
        
#         # Check if GCP path exists if provided
#         if gcp_path and not os.path.exists(gcp_path):
#             logger.warning(f"⚠️ GCP credentials path does not exist: {gcp_path}")
#         logger.info("="*50)
        
#         # Prepare credentials dicts (None if not found)
#         aws_creds = None
#         if aws_key and aws_secret:
#             aws_creds = {
#                 'aws_access_key_id': aws_key,
#                 'aws_secret_access_key': aws_secret,
#                 'region_name': 'us-east-1'
#             }
#             logger.info("✅ AWS credentials configured")
        
#         azure_creds = None
#         if azure_key:
#             azure_creds = {'subscription_key': azure_key}
#             logger.info("✅ Azure credentials configured")
        
#         gcp_creds = None
#         if gcp_path and os.path.exists(gcp_path):
#             gcp_creds = {'credentials_path': gcp_path}
#             logger.info("✅ GCP credentials configured")
#         elif gcp_path:
#             logger.warning(f"⚠️ GCP credentials path not found: {gcp_path}")
#             gcp_creds = None
        
#         # Initialize agent with credentials
#         agent = CloudRationalizationAgent(
#             openai_api_key=openai_api_key,  # Can be None for tool-only
#             aws_credentials=aws_creds,
#             azure_credentials=azure_creds,
#             gcp_credentials=gcp_creds
#         )
        
#         mode_text = "FULL AGENT" if agent.llm else "TOOL-ONLY"
#         logger.info(f"✅ Agent initialized successfully in {mode_text} mode")
        
#         # Log pricing mode
#         live_providers = []
#         if aws_creds:
#             live_providers.append("AWS")
#         if azure_creds:
#             live_providers.append("Azure")
#         if gcp_creds:
#             live_providers.append("GCP")
        
#         if live_providers:
#             logger.info(f"💰 LIVE pricing enabled for: {', '.join(live_providers)}")
#         else:
#             logger.info("💰 Using DEMO pricing (no cloud credentials)")
        
#     except ImportError as e:
#         logger.error(f"Failed to import agent: {e}")
#         agent = None
#     except Exception as e:
#         logger.error(f"Failed to initialize agent: {e}")
#         agent = None

# @app.get("/")
# async def root():
#     """Root endpoint"""
#     return {
#         "message": "Cloud Rationalization Agent API",
#         "version": "2.0.0",
#         "status": "running",
#         "agent_mode": "full" if agent and agent.llm else "tool-only" if agent else "unavailable",
#         "endpoints": [
#             "/health",
#             "/compare-prices",
#             "/analyze",
#             "/providers",
#             "/regions/{provider}",
#             "/debug/credentials",
#             "/debug/tools",
#             "/docs"
#         ]
#     }

# @app.get("/health")
# async def health():
#     """Health check endpoint"""
#     # Check credentials status
#     aws_configured = False
#     azure_configured = False
#     gcp_configured = False
    
#     if agent:
#         for tool in agent.tools:
#             tool_name = tool.name.lower()
#             if 'aws' in tool_name:
#                 aws_configured = bool(getattr(tool, 'aws_access_key', None))
#             elif 'azure' in tool_name:
#                 azure_configured = bool(getattr(tool, 'subscription_key', None))
#             elif 'gcp' in tool_name:
#                 gcp_configured = bool(getattr(tool, 'credentials_path', None))
    
#     return {
#         "status": "healthy",
#         "agent_initialized": agent is not None,
#         "agent_mode": "full" if agent and agent.llm else "tool-only" if agent else "none",
#         "credentials": {
#             "aws": aws_configured,
#             "azure": azure_configured,
#             "gcp": gcp_configured,
#             "openai": agent.llm is not None if agent else False
#         },
#         "pricing_mode": "live" if any([aws_configured, azure_configured, gcp_configured]) else "demo",
#         "timestamp": datetime.now().isoformat()
#     }

# @app.post("/compare-prices")
# async def compare_prices(request: Dict[str, Any] = Body(...)):
#     """
#     Compare prices across cloud providers
#     """
#     try:
#         if not agent:
#             # Return demo data if agent not initialized
#             logger.warning("Agent not initialized, returning demo data")
#             return {
#                 "aws": {
#                     "provider": "AWS",
#                     "hourly_rate": 0.0416,
#                     "monthly_rate": 30.37,
#                     "currency": "USD",
#                     "pricing_model": "On-Demand (Demo)"
#                 },
#                 "azure": {
#                     "provider": "Azure",
#                     "hourly_rate": 0.0480,
#                     "monthly_rate": 35.04,
#                     "currency": "USD",
#                     "pricing_model": "Pay-As-You-Go (Demo)"
#                 },
#                 "gcp": {
#                     "provider": "GCP",
#                     "hourly_rate": 0.0375,
#                     "monthly_rate": 27.38,
#                     "currency": "USD",
#                     "pricing_model": "On-Demand (Demo)"
#                 }
#             }
        
#         # Extract parameters
#         resource_type = request.get("resource_type", "ec2")
#         specifications = request.get("specifications", {"instance_type": "t3.medium"})
#         regions = request.get("regions", ["us-east-1"])
        
#         logger.info(f"Comparing prices for {specifications.get('instance_type')} in {regions}")
        
#         # Call agent's compare_prices method (tool-only)
#         results = agent.compare_prices(
#             resource_type=resource_type,
#             specifications=specifications,
#             regions=regions
#         )
        
#         # Use safe_serialize to ensure JSON compatibility
#         return safe_serialize(results)
        
#     except Exception as e:
#         logger.error(f"Error in compare_prices: {e}")
#         import traceback
#         traceback.print_exc()
#         raise HTTPException(status_code=500, detail=str(e))

# @app.post("/analyze")
# async def analyze(request: Dict[str, Any] = Body(...)):
#     """
#     Analyze infrastructure
#     Returns tool-only analysis if no LLM, full analysis if LLM available
#     """
#     try:
#         if not agent:
#             # Return demo analysis if agent not initialized
#             resources = request.get("current_infrastructure", [])
#             total_cost = sum(r.get("monthly_cost", 0) for r in resources)
            
#             return {
#                 "summary": {
#                     "current_cost": total_cost,
#                     "optimized_cost": total_cost * 0.7,
#                     "savings": total_cost * 0.3,
#                     "savings_percentage": 30
#                 },
#                 "analysis": f"## Demo Analysis\n\nAnalyzed {len(resources)} resources.\n\nFor real analysis, please ensure agent is properly configured.",
#                 "recommendations": [
#                     {
#                         "title": "Right-size instances",
#                         "description": "Consider downsizing underutilized instances",
#                         "savings": total_cost * 0.15,
#                         "risk": "low"
#                     },
#                     {
#                         "title": "Purchase Reserved Instances",
#                         "description": "For steady-state production workloads",
#                         "savings": total_cost * 0.25,
#                         "risk": "medium"
#                     }
#                 ],
#                 "mode": "demo"
#             }
        
#         # Import models here to avoid circular imports
#         from src.models.schemas import RationalizationRequest, CloudResource, BusinessConstraints, OptimizationGoal
        
#         # Parse request
#         resources_data = request.get("current_infrastructure", [])
#         resources = []
        
#         for r in resources_data:
#             try:
#                 resource = CloudResource(
#                     name=r.get("name", "unknown"),
#                     resource_type=r.get("resource_type", "compute"),
#                     provider=r.get("provider", "aws"),
#                     region=r.get("region", "us-east-1"),
#                     specifications=r.get("specifications", {}),
#                     quantity=int(r.get("quantity", 1)),
#                     usage_pattern=r.get("usage_pattern", "steady"),
#                     monthly_cost=float(r.get("monthly_cost", 0)),
#                     fault_tolerant=r.get("fault_tolerant", False)
#                 )
#                 resources.append(resource)
#             except Exception as e:
#                 logger.warning(f"Error parsing resource: {e}")
        
#         # Create constraints
#         constraints_data = request.get("business_constraints", {})
#         constraints = BusinessConstraints(
#             max_budget=constraints_data.get("max_budget"),
#             min_availability=constraints_data.get("min_availability", "99.9%"),
#             compliance_requirements=constraints_data.get("compliance_requirements", []),
#             risk_tolerance=constraints_data.get("risk_tolerance", "medium")
#         )
        
#         # Create goals
#         goals_data = request.get("optimization_goals", ["cost_reduction"])
#         goals = []
#         for g in goals_data:
#             try:
#                 goals.append(OptimizationGoal(g))
#             except ValueError:
#                 goals.append(OptimizationGoal.COST_REDUCTION)
        
#         # Create request
#         req = RationalizationRequest(
#             current_infrastructure=resources,
#             business_constraints=constraints,
#             optimization_goals=goals,
#             time_horizon=request.get("time_horizon", "1 year")
#         )
        
#         # Run analysis (will auto-select mode based on agent.llm availability)
#         import asyncio
#         loop = asyncio.new_event_loop()
#         asyncio.set_event_loop(loop)
#         try:
#             result = loop.run_until_complete(
#                 asyncio.wait_for(
#                     agent.analyze_with_llm(req),
#                     timeout=60
#                 )
#             )
#         except asyncio.TimeoutError:
#             logger.error("Analysis timed out")
#             raise HTTPException(status_code=504, detail="Analysis timed out")
#         finally:
#             loop.close()
        
#         return safe_serialize(result)
        
#     except HTTPException:
#         raise
#     except Exception as e:
#         logger.error(f"Error in analyze: {e}")
#         import traceback
#         traceback.print_exc()
#         raise HTTPException(status_code=500, detail=str(e))

# @app.get("/compare-simple")
# async def compare_simple(
#     instance_type: str = "t3.medium",
#     region: str = "us-east-1"
# ):
#     """
#     Simple GET endpoint for quick price comparison
#     """
#     if not agent:
#         return {
#             "aws": 30.37,
#             "azure": 35.04,
#             "gcp": 27.38,
#             "note": "Demo data (agent not initialized)"
#         }
    
#     results = agent.compare_prices(
#         specifications={"instance_type": instance_type, "os": "Linux"},
#         regions=[region]
#     )
    
#     # Simplify for GET response
#     simplified = {}
#     for provider, data in results.items():
#         if provider != '_metadata' and isinstance(data, dict):
#             simplified[provider] = data.get('monthly_rate', data.get('monthly', 0))
    
#     return simplified

# @app.get("/providers")
# async def list_providers():
#     """List supported cloud providers"""
#     return {
#         "providers": [
#             {
#                 "name": "AWS",
#                 "services": ["EC2", "RDS", "S3", "Lambda", "EKS"],
#                 "regions": 30,
#                 "website": "https://aws.amazon.com"
#             },
#             {
#                 "name": "Azure",
#                 "services": ["Virtual Machines", "SQL Database", "Storage", "Functions", "AKS"],
#                 "regions": 60,
#                 "website": "https://azure.microsoft.com"
#             },
#             {
#                 "name": "GCP",
#                 "services": ["Compute Engine", "Cloud SQL", "Cloud Storage", "Cloud Functions", "GKE"],
#                 "regions": 35,
#                 "website": "https://cloud.google.com"
#             }
#         ]
#     }

# @app.get("/regions/{provider}")
# async def list_regions(provider: str):
#     """List available regions for a specific provider"""
#     regions = {
#         "aws": [
#             {"code": "us-east-1", "name": "US East (N. Virginia)"},
#             {"code": "us-east-2", "name": "US East (Ohio)"},
#             {"code": "us-west-1", "name": "US West (N. California)"},
#             {"code": "us-west-2", "name": "US West (Oregon)"},
#             {"code": "eu-west-1", "name": "EU (Ireland)"},
#             {"code": "eu-central-1", "name": "EU (Frankfurt)"},
#             {"code": "ap-southeast-1", "name": "Asia Pacific (Singapore)"},
#             {"code": "ap-northeast-1", "name": "Asia Pacific (Tokyo)"}
#         ],
#         "azure": [
#             {"code": "eastus", "name": "US East"},
#             {"code": "eastus2", "name": "US East 2"},
#             {"code": "westus", "name": "US West"},
#             {"code": "westus2", "name": "US West 2"},
#             {"code": "westeurope", "name": "West Europe"},
#             {"code": "northeurope", "name": "North Europe"},
#             {"code": "southeastasia", "name": "Southeast Asia"},
#             {"code": "japaneast", "name": "Japan East"}
#         ],
#         "gcp": [
#             {"code": "us-central1", "name": "Iowa"},
#             {"code": "us-east1", "name": "South Carolina"},
#             {"code": "us-west1", "name": "Oregon"},
#             {"code": "europe-west1", "name": "Belgium"},
#             {"code": "europe-west2", "name": "London"},
#             {"code": "asia-east1", "name": "Taiwan"},
#             {"code": "asia-southeast1", "name": "Singapore"},
#             {"code": "australia-southeast1", "name": "Sydney"}
#         ]
#     }
    
#     return {
#         "provider": provider,
#         "regions": regions.get(provider.lower(), [])
#     }

# @app.get("/debug/credentials")
# async def debug_credentials():
#     """Check what credentials are configured on the server"""
#     global agent
    
#     # Get raw env var status
#     env_status = {
#         "OPENAI_API_KEY": bool(os.getenv("OPENAI_API_KEY")),
#         "AWS_ACCESS_KEY_ID": bool(os.getenv("AWS_ACCESS_KEY_ID")),
#         "AWS_SECRET_ACCESS_KEY": bool(os.getenv("AWS_SECRET_ACCESS_KEY")),
#         "AZURE_SUBSCRIPTION_KEY": bool(os.getenv("AZURE_SUBSCRIPTION_KEY")),
#         "GCP_CREDENTIALS_PATH": bool(os.getenv("GCP_CREDENTIALS_PATH")),
#     }
    
#     # Check if GCP path exists
#     gcp_path = os.getenv("GCP_CREDENTIALS_PATH")
#     if gcp_path:
#         env_status["GCP_CREDENTIALS_PATH_EXISTS"] = os.path.exists(gcp_path)
#         env_status["GCP_CREDENTIALS_PATH_ABSOLUTE"] = os.path.abspath(gcp_path) if os.path.exists(gcp_path) else gcp_path
    
#     if not agent:
#         return {
#             "agent_initialized": False,
#             "env_vars": env_status,
#             "message": "Agent not initialized"
#         }
    
#     # Check what credentials are configured in the agent's tools
#     aws_configured = False
#     azure_configured = False
#     gcp_configured = False
    
#     for tool in agent.tools:
#         tool_name = tool.name.lower()
#         if 'aws' in tool_name:
#             aws_configured = bool(getattr(tool, 'aws_access_key', None))
#         elif 'azure' in tool_name:
#             azure_configured = bool(getattr(tool, 'subscription_key', None))
#         elif 'gcp' in tool_name:
#             gcp_configured = bool(getattr(tool, 'credentials_path', None))
    
#     return {
#         "agent_initialized": True,
#         "agent_mode": "full" if agent.llm else "tool-only",
#         "openai_configured": agent.llm is not None,
#         "aws_configured": aws_configured,
#         "azure_configured": azure_configured,
#         "gcp_configured": gcp_configured,
#         "pricing_mode": "live" if any([aws_configured, azure_configured, gcp_configured]) else "demo",
#         "env_vars": env_status,
#         "live_providers": {
#             "aws": aws_configured,
#             "azure": azure_configured,
#             "gcp": gcp_configured
#         }
#     }

# @app.get("/debug/tools")
# async def debug_tools():
#     """Check if tools are working"""
#     if not agent:
#         return {"tools_available": False, "reason": "Agent not initialized"}
    
#     try:
#         # Try a simple tool call
#         result = agent.compare_prices(
#             specifications={"instance_type": "t3.medium"},
#             regions=["us-east-1"]
#         )
        
#         # Extract just the monthly rates for summary
#         rates = {}
#         for k, v in result.items():
#             if k != '_metadata' and isinstance(v, dict):
#                 rates[k] = v.get('monthly_rate', v.get('monthly', 0))
        
#         return {
#             "tools_available": True,
#             "mode": "full" if agent.llm else "tool-only",
#             "sample_result": rates,
#             "provider_count": len([k for k in result.keys() if k != '_metadata'])
#         }
#     except Exception as e:
#         return {
#             "tools_available": False,
#             "error": str(e),
#             "error_type": type(e).__name__
#         }

# @app.get("/debug/env")
# async def debug_env():
#     """Debug environment variables (without exposing secrets)"""
#     return {
#         "env_file_exists": os.path.exists(".env"),
#         "current_directory": os.getcwd(),
#         "python_path": sys.path,
#         "credentials": {
#             "OPENAI_API_KEY": bool(os.getenv("OPENAI_API_KEY")),
#             "AWS_ACCESS_KEY_ID": bool(os.getenv("AWS_ACCESS_KEY_ID")),
#             "AWS_SECRET_ACCESS_KEY": bool(os.getenv("AWS_SECRET_ACCESS_KEY")),
#             "AZURE_SUBSCRIPTION_KEY": bool(os.getenv("AZURE_SUBSCRIPTION_KEY")),
#             "GCP_CREDENTIALS_PATH": bool(os.getenv("GCP_CREDENTIALS_PATH")),
#         }
#     }
"""
FastAPI application for Cloud Rationalization Agent
Complete fixed version - Proper event loop handling
"""
import certifi
import certifi
from fastapi import FastAPI, HTTPException, Body, Query
from fastapi.middleware.cors import CORSMiddleware
from typing import Dict, Any, List, Optional
import logging
from datetime import datetime
import os
import sys
from pathlib import Path
import httpx
import httpx
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_openai import ChatOpenAI

# Load environment variables FIRST
load_dotenv()

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent))
tool_agent = None
llm_agent = None

# Import helpers
try:
    from src.utils.helpers import apply_ssl_fix, safe_serialize
    apply_ssl_fix()
    HELPERS_AVAILABLE = True
except ImportError:
    HELPERS_AVAILABLE = False
    def safe_serialize(obj):
        if hasattr(obj, 'dict'):
            return obj.dict()
        if hasattr(obj, 'model_dump'):
            return obj.model_dump()
        return obj

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Cloud Rationalization Agent API",
    description="AI-powered cloud infrastructure optimization",
    version="2.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global agent instance
agent = None

@app.on_event("startup")
async def startup_event():
    """Initialize agent on startup with credentials from .env"""
    global agent
    global tool_agent
    global llm_agent
    try:
        from src.agent import CloudRationalizationAgent
        
        # Read ALL credentials from environment
        openai_api_key = os.getenv("OPENAI_API_KEY")
        aws_key = os.getenv("AWS_ACCESS_KEY_ID")
        aws_secret = os.getenv("AWS_SECRET_ACCESS_KEY")
        azure_key = os.getenv("AZURE_SUBSCRIPTION_KEY")
        gcp_path = os.getenv("GCP_CREDENTIALS_PATH")
        
        # Log what we found
        logger.info("="*50)
        logger.info("LOADING CREDENTIALS FROM .ENV")
        logger.info("="*50)
        logger.info(f"OPENAI_API_KEY: {'✅ Found' if openai_api_key else '❌ Not found'}")
        logger.info(f"AWS_ACCESS_KEY_ID: {'✅ Found' if aws_key else '❌ Not found'}")
        logger.info(f"AWS_SECRET_ACCESS_KEY: {'✅ Found' if aws_secret else '❌ Not found'}")
        logger.info(f"AZURE_SUBSCRIPTION_KEY: {'✅ Found' if azure_key else '❌ Not found'}")
        logger.info(f"GCP_CREDENTIALS_PATH: {'✅ Found' if gcp_path else '❌ Not found'}")
        logger.info("="*50)
        
        # Prepare credentials dicts
        aws_creds = None
        if aws_key and aws_secret:
            aws_creds = {
                'aws_access_key_id': aws_key,
                'aws_secret_access_key': aws_secret,
                'region_name': 'us-east-1'
            }
        
        azure_creds = None
        if azure_key:
            azure_creds = {'subscription_key': azure_key}
        
        gcp_creds = None
        if gcp_path and os.path.exists(gcp_path):
            gcp_creds = {'credentials_path': gcp_path}
        
        # Initialize agent
        # agent = CloudRationalizationAgent(
        #     openai_api_key=openai_api_key,
        #     aws_credentials=aws_creds,
        #     azure_credentials=azure_creds,
        #     gcp_credentials=gcp_creds
        # )
        
        # mode_text = "FULL AGENT" if agent.llm else "TOOL-ONLY"
        # logger.info(f"✅ Agent initialized successfully in {mode_text} mode")
        # ===== TOOL-ONLY AGENT (Always works) =====
        tool_agent = CloudRationalizationAgent(
            openai_api_key=None,
            aws_credentials=aws_creds,
            azure_credentials=azure_creds,
            gcp_credentials=gcp_creds
        )
        logger.info("✅ Tool-Only Agent initialized")
        
        # ===== LLM AGENT =====
        openai_api_key = os.getenv("OPENAI_API_KEY")
        if openai_api_key:
            try:
            #     # Test OpenAI connection
            #     http_client = httpx.Client(
            #         verify=certifi.where(),
            #         timeout=10.0
            #     )
                
            #     test_llm = ChatOpenAI(
            #         api_key=openai_api_key,
            #         model="gpt-3.5-turbo",
            #         http_client=http_client,
            #         max_retries=1
            #     )
                
            #     test_response = test_llm.invoke("Say 'test'")
            #     logger.info("✅ OpenAI connection test passed")
                
                # Create LLM agent
                llm_agent = CloudRationalizationAgent(
                    openai_api_key=openai_api_key,
                    aws_credentials=aws_creds,
                    azure_credentials=azure_creds,
                    gcp_credentials=gcp_creds
                )
                logger.info("✅ LLM Agent initialized")
                
            except Exception as e:
                logger.error(f"❌ LLM Agent failed: {e}")
                llm_agent = None
        else:
            logger.info("ℹ️ No OpenAI key - LLM unavailable")
            llm_agent = None
        
        logger.info("="*50)
        logger.info(f"Server ready - Tool: {'✅' if tool_agent else '❌'}, LLM: {'✅' if llm_agent else '❌'}")
        logger.info("="*50)
    except Exception as e:
        logger.error(f"Failed to initialize agent: {e}")
        #agent = None
        tool_agent = None
        llm_agent = None


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Cloud Rationalization Agent API",
        "version": "2.0.0",
        "status": "running",
        "agent_mode": "full" if agent and agent.llm else "tool-only" if agent else "unavailable",
        "endpoints": [
            "/health", "/compare-prices", "/analyze", 
            "/providers", "/regions/{provider}", "/debug/credentials"
        ]
    }

@app.get("/health")
async def health():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "agent_initialized": agent is not None,
        "agent_mode": "full" if agent and agent.llm else "tool-only" if agent else "none",
        "timestamp": datetime.now().isoformat()
    }

@app.post("/compare-prices")
async def compare_prices(request: Dict[str, Any] = Body(...)):
    """
    Compare prices across cloud providers
    """
    try:
        if not agent:
            # Return demo data
            return {
                "aws": {"provider": "AWS", "hourly_rate": 0.0416, "monthly_rate": 30.37},
                "azure": {"provider": "Azure", "hourly_rate": 0.0480, "monthly_rate": 35.04},
                "gcp": {"provider": "GCP", "hourly_rate": 0.0375, "monthly_rate": 27.38}
            }
        
        # Extract parameters
        resource_type = request.get("resource_type", "ec2")
        specifications = request.get("specifications", {"instance_type": "t3.medium"})
        regions = request.get("regions", ["us-east-1"])
        
        logger.info(f"Comparing prices for {specifications.get('instance_type')} in {regions}")
        
        # Call agent's compare_prices method (synchronous)
        results = agent.compare_prices(
            resource_type=resource_type,
            specifications=specifications,
            regions=regions
        )
        
        return safe_serialize(results)
        
    except Exception as e:
        logger.error(f"Error in compare_prices: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/analyze")
async def analyze(request: Dict[str, Any] = Body(...),
                use_llm: bool = Query(False, description="True for LLM mode, False for Tool mode")
):
    """
    Analyze infrastructure - FIXED event loop issue
    """
    try:
        # if use_llm and llm_agent:
        #     agent = llm_agent
        #     mode = "llm"
        #     logger.info(f"Using LLM agent as requested (use_llm={use_llm})")
        # else:
        #     agent = tool_agent
        #     mode = "tool_only"
        #     if use_llm and not llm_agent:
        #         logger.warning("LLM requested but not available, using Tool-Only")
        # Select agent based on client's request
        if use_llm:
            if llm_agent:
                agent = llm_agent
                logger.info("✅ Using LLM agent as requested")
                # Keep your existing LLM analysis code here
            else:
                logger.warning("⚠️ LLM requested but not available - using Tool agent")
                agent = tool_agent
        else:
            agent = tool_agent
            logger.info("🔧 Using Tool agent as requested")

        if not agent:
            # Return demo analysis
            resources = request.get("current_infrastructure", [])
            total_cost = sum(r.get("monthly_cost", 0) for r in resources)
            
            return {
                "summary": {
                    "current_cost": total_cost,
                    "optimized_cost": total_cost * 0.7,
                    "savings": total_cost * 0.3,
                    "savings_percentage": 30
                },
                "analysis": f"## Demo Analysis\n\nAnalyzed {len(resources)} resources.",
                "recommendations": [
                    {
                        "title": "Right-size instances",
                        "description": "Consider downsizing underutilized instances",
                        "savings": total_cost * 0.15,
                        "risk": "low"
                    }
                ],
                "mode": "demo"
            }
        
        # Import models
        from src.models.schemas import RationalizationRequest, CloudResource, BusinessConstraints, OptimizationGoal
        
        # Parse request
        resources_data = request.get("current_infrastructure", [])
        resources = []
        
        for r in resources_data:
            try:
                resource = CloudResource(
                    name=r.get("name", "unknown"),
                    resource_type=r.get("resource_type", "compute"),
                    provider=r.get("provider", "aws"),
                    region=r.get("region", "us-east-1"),
                    specifications=r.get("specifications", {}),
                    quantity=int(r.get("quantity", 1)),
                    usage_pattern=r.get("usage_pattern", "steady"),
                    monthly_cost=float(r.get("monthly_cost", 0)),
                    fault_tolerant=r.get("fault_tolerant", False)
                )
                resources.append(resource)
            except Exception as e:
                logger.warning(f"Error parsing resource: {e}")
        
        # Create constraints
        constraints_data = request.get("business_constraints", {})
        constraints = BusinessConstraints(
            max_budget=constraints_data.get("max_budget"),
            min_availability=constraints_data.get("min_availability", "99.9%"),
            compliance_requirements=constraints_data.get("compliance_requirements", []),
            risk_tolerance=constraints_data.get("risk_tolerance", "medium")
        )
        
        # Create goals
        goals_data = request.get("optimization_goals", ["cost_reduction"])
        goals = []
        for g in goals_data:
            try:
                goals.append(OptimizationGoal(g))
            except ValueError:
                goals.append(OptimizationGoal.COST_REDUCTION)
        
        # Create request
        req = RationalizationRequest(
            current_infrastructure=resources,
            business_constraints=constraints,
            optimization_goals=goals,
            time_horizon=request.get("time_horizon", "1 year")
        )
        if use_llm and llm_agent:
            import asyncio
            # FIX: Use await directly - no new loop creation
            try:
                result = await asyncio.wait_for(
                    agent.analyze_with_llm(req),
                    #llm_agent.analyze_with_llm(req),
                    timeout=60
                )
            except asyncio.TimeoutError:
                logger.error("Analysis timed out")
                raise HTTPException(status_code=504, detail="Analysis timed out")
        else:
            # TOOL MODE - Call the new method directly
            #result = agent.analyze_with_constraints(resources, constraints)
            result = agent._get_tool_only_analysis(req)
            result["mode"] = "tool_with_constraints"
        return safe_serialize(result)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in analyze: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/debug/credentials")
async def debug_credentials():
    """Check what credentials are configured"""
    if not agent:
        return {"agent_initialized": False}
    
    aws_configured = False
    azure_configured = False
    gcp_configured = False
    
    for tool in agent.tools:
        tool_name = tool.name.lower()
        if 'aws' in tool_name:
            aws_configured = bool(getattr(tool, 'aws_access_key', None))
        elif 'azure' in tool_name:
            azure_configured = bool(getattr(tool, 'subscription_key', None))
        elif 'gcp' in tool_name:
            gcp_configured = bool(getattr(tool, 'credentials_path', None))
    
    return {
        "agent_initialized": True,
        "agent_mode": "full" if agent.llm else "tool-only",
        "aws_configured": aws_configured,
        "azure_configured": azure_configured,
        "gcp_configured": gcp_configured,
        "pricing_mode": "live" if any([aws_configured, azure_configured, gcp_configured]) else "demo"
    }