# """
# Cloud Rationalization Agent - Complete Version with SSL Fix
# """
# from typing import Dict, List, Optional, Any, Union
# from langchain.agents import AgentExecutor, create_openai_tools_agent
# from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
# from langchain_openai import ChatOpenAI
# from langchain.memory import ConversationBufferMemory
# import logging
# import json
# import os
# import httpx
# import certifi
# from datetime import datetime

# # Import helpers
# from src.utils.helpers import apply_ssl_fix, safe_serialize, safe_call_tool

# # Import tools
# from src.tools.aws_pricing import AWSPricingTool
# from src.tools.azure_pricing import AzurePricingTool
# from src.tools.gcp_pricing import GCPPricingTool
# from src.tools.analyzers import WorkloadAnalyzer, CostOptimizer

# # Apply SSL fix at module level
# ssl_context = apply_ssl_fix()
# logger = logging.getLogger(__name__)

# class CloudRationalizationAgent:
#     """
#     AI Agent for cloud infrastructure rationalization
#     Features:
#     - Tool-only mode (works without OpenAI)
#     - Full agent mode (with OpenAI for explanations)
#     - SSL fixes for corporate networks
#     - Safe serialization for Pydantic models
#     """
    
#     def __init__(self, 
#                  openai_api_key: Optional[str] = None,
#                  aws_credentials: Optional[Dict] = None,
#                  azure_credentials: Optional[Dict] = None,
#                  gcp_credentials: Optional[Dict] = None,
#                  model: str = "gpt-3.5-turbo",  # Using 3.5 for faster response
#                  temperature: float = 0.1):
#         """
#         Initialize the agent - tools always work, LLM is optional
#         """
#         # Create HTTP client with SSL fix
#         self.http_client = httpx.Client(
#             verify=certifi.where(),  # Use certifi certificates
#             timeout=30.0,
#             follow_redirects=True
#         )
        
#         # ===== STEP 1: Initialize tools FIRST (always work) =====
#         self.tools = self._initialize_tools(
#             aws_credentials or {},
#             azure_credentials or {},
#             gcp_credentials or {}
#         )
#         logger.info(f"✅ Tools initialized: {len(self.tools)} tools available")
        
#         # ===== STEP 2: Try to initialize LLM (optional) =====
#         self.llm = None
#         self.agent = None
#         self.agent_executor = None
#         self.memory = None
        
#         if openai_api_key:
#             try:
#                 self.llm = ChatOpenAI(
#                     model=model,
#                     temperature=temperature,
#                     api_key=openai_api_key,
#                     http_client=self.http_client,
#                     timeout=30,
#                     max_retries=2
#                 )
#                 logger.info("✅ LLM initialized successfully")
                
#                 # Create agent if LLM works
#                 self.memory = ConversationBufferMemory(
#                     memory_key="chat_history",
#                     return_messages=True
#                 )
                
#                 self.agent = self._create_agent()
#                 self.agent_executor = AgentExecutor(
#                     agent=self.agent,
#                     tools=self.tools,
#                     verbose=True,
#                     handle_parsing_errors=True,
#                     max_iterations=10
#                 )
#                 logger.info("✅ Full agent initialized with LLM")
                
#             except Exception as e:
#                 logger.warning(f"⚠️ LLM initialization failed: {e}")
#                 logger.info("🔄 Running in TOOL-ONLY mode")
#         else:
#             logger.info("🔄 No API key provided - running in TOOL-ONLY mode")
    
#     def _initialize_tools(self, aws_creds, azure_creds, gcp_creds):
#         """Initialize all tools - ALWAYS WORKS"""
#         tools = []
        
#         # Pricing tools - always initialize (they handle missing credentials internally)
#         tools.append(AWSPricingTool(credentials=aws_creds or {}))
#         tools.append(AzurePricingTool(credentials=azure_creds or {}))
#         tools.append(GCPPricingTool(credentials=gcp_creds or {}))
        
#         from src.tools.analyzers import WorkloadAnalyzer, CostOptimizer        
#         # Analysis tools
#         tools.append(WorkloadAnalyzer())
#         tools.append(CostOptimizer())
        
#         return tools
    
#     def _create_agent(self):
#         """Create the LangChain agent (only called if LLM available)"""
#         prompt = ChatPromptTemplate.from_messages([
#             ("system", """You are an expert cloud rationalization advisor. 
#             Analyze infrastructure and provide cost optimization recommendations.
#             Be specific with numbers and actionable steps."""),
#             MessagesPlaceholder(variable_name="chat_history"),
#             ("user", "{input}"),
#             MessagesPlaceholder(variable_name="agent_scratchpad")
#         ])
        
#         return create_openai_tools_agent(self.llm, self.tools, prompt)
    
#     # ===== TOOL-ONLY METHODS (Work without LLM) =====
    
#     def compare_prices(self, 
#                        resource_type: str = "ec2",
#                        specifications: Union[Dict, str] = None,
#                        regions: Union[List[str], str] = None) -> Dict:
#         """
#         Compare prices across providers - ALWAYS WORKS
#         Uses safe_call_tool helper for robust parameter handling
#         """
#         if specifications is None:
#             specifications = {"instance_type": "t3.medium", "os": "Linux"}
#         if regions is None:
#             regions = ["us-east-1"]
        
#         results = {}
        
#         # Find pricing tools
#         pricing_tools = [t for t in self.tools if 'pricing' in t.name]
        
#         for tool in pricing_tools:
#             try:
#                 # Use safe helper to call tool
#                 result = safe_call_tool(
#                     tool=tool,
#                     resource_type=resource_type,
#                     region_input=regions,
#                     specifications=specifications,
#                     quantity=1
#                 )
                
#                 # Extract provider name
#                 provider = tool.name.replace('_pricing_tool', '').replace('_', '')
#                 results[provider] = result
                
#             except Exception as e:
#                 logger.error(f"Error with {tool.name}: {e}")
#                 provider = tool.name.replace('_pricing_tool', '')
#                 results[provider] = {
#                     "error": str(e),
#                     "provider": provider.upper(),
#                     "monthly_rate": 30.37 if 'aws' in provider else 35.04 if 'azure' in provider else 27.38,
#                     "hourly_rate": 0.0416 if 'aws' in provider else 0.0480 if 'azure' in provider else 0.0375,
#                     "fallback": True
#                 }
        
#         # Add summary
#         results['_metadata'] = {
#             "timestamp": datetime.now().isoformat(),
#             "mode": "tool_only",
#             "resource_type": resource_type,
#             "instance_type": specifications.get('instance_type') if isinstance(specifications, dict) else "t3.medium"
#         }
        
#         return results
    
#     def analyze_workload(self, resources: List[Dict]) -> Dict:
#         """
#         Analyze workload using tools only
#         """
#         analyzer = next((t for t in self.tools if 'WorkloadAnalyzer' in t.__class__.__name__), None)
        
#         if analyzer:
#             try:
#                 result = analyzer._run(resources)
#                 if isinstance(result, str):
#                     return json.loads(result)
#                 return result
#             except Exception as e:
#                 return {"error": str(e)}
        
#         return {"error": "Analyzer tool not found"}
    
#     def calculate_savings(self, current_costs: Dict, strategy: str = "combined") -> Dict:
#         """
#         Calculate savings using tools only
#         """
#         optimizer = next((t for t in self.tools if 'CostOptimizer' in t.__class__.__name__), None)
        
#         if optimizer:
#             try:
#                 result = optimizer._run(current_costs, strategy)
#                 if isinstance(result, str):
#                     return json.loads(result)
#                 return result
#             except Exception as e:
#                 return {"error": str(e)}
        
#         return {"error": "Optimizer tool not found"}
    
#     # ===== AGENT METHODS (Require LLM) =====
    
#     # async def analyze_with_llm(self, request):
#     #     """
#     #     Full agent analysis WITH LLM
#     #     Falls back to tool-only if LLM unavailable
#     #     """
#     #     # If no LLM, use tool-only mode
#     #     if not self.agent_executor:
#     #         logger.info("LLM unavailable - using tool-only mode")
            
#     #         # Extract resources from request
#     #         resources = []
#     #         if hasattr(request, 'current_infrastructure'):
#     #             for r in request.current_infrastructure:
#     #                 resources.append({
#     #                     'name': getattr(r, 'name', 'unknown'),
#     #                     'monthly_cost': getattr(r, 'monthly_cost', 0),
#     #                     'usage_pattern': getattr(r, 'usage_pattern', 'steady'),
#     #                     'fault_tolerant': getattr(r, 'fault_tolerant', False)
#     #                 })
            
#     #         # Use tool-only methods
#     #         prices = self.compare_prices()
#     #         analysis = self.analyze_workload(resources)
#     #         total_cost = sum(r.get('monthly_cost', 0) for r in resources)
#     #         savings = self.calculate_savings({"total": total_cost})
            
#     #         return {
#     #             "analysis": f"Tool-Only Analysis:\n"
#     #                        f"- Prices compared from {len(prices)-1} providers\n"
#     #                        f"- Resources analyzed: {len(resources)}\n"
#     #                        f"- Current monthly cost: ${total_cost:,.2f}\n"
#     #                        f"- Estimated savings potential: 30-60%",
#     #             "tool_outputs": safe_serialize({
#     #                 "prices": prices,
#     #                 "analysis": analysis,
#     #                 "savings": savings
#     #             }),
#     #             "mode": "tool_only"
#     #         }
        
#     #     # Use full agent with LLM
#     #     try:
#     #         result = await self.agent_executor.ainvoke({
#     #             "input": "Analyze this infrastructure and provide recommendations",
#     #             "chat_history": self.memory.chat_memory.messages if self.memory else []
#     #         })
#     #         result["mode"] = "full_agent"
#     #         return result
#     #     except Exception as e:
#     #         logger.error(f"LLM analysis failed: {e}")
#     #         # Recursive fallback to tool-only
#     #         return await self.analyze_with_llm(request)
#     async def analyze_with_llm(self, request):
#         """
#         Full agent analysis WITH LLM - FIXED event loop issue
#         Falls back to tool-only if LLM unavailable
#         """
#         # If no LLM, use tool-only mode
#         if not self.agent_executor:
#             logger.info("LLM unavailable - using tool-only mode")
            
#             # Extract resources from request
#             resources = []
#             if hasattr(request, 'current_infrastructure'):
#                 for r in request.current_infrastructure:
#                     resources.append({
#                         'name': getattr(r, 'name', 'unknown'),
#                         'monthly_cost': getattr(r, 'monthly_cost', 0),
#                         'usage_pattern': getattr(r, 'usage_pattern', 'steady'),
#                         'fault_tolerant': getattr(r, 'fault_tolerant', False)
#                     })
            
#             # Use tool-only methods
#             prices = self.compare_prices()
#             analysis = self.analyze_workload(resources)
#             total_cost = sum(r.get('monthly_cost', 0) for r in resources)
#             savings = self.calculate_savings({"total": total_cost})
            
#             return {
#                 "analysis": f"Tool-Only Analysis:\n"
#                         f"- Prices compared from providers\n"
#                         f"- Resources analyzed: {len(resources)}\n"
#                         f"- Current monthly cost: ${total_cost:,.2f}\n"
#                         f"- Estimated savings potential: 30-60%",
#                 "tool_outputs": safe_serialize({
#                     "prices": prices,
#                     "analysis": analysis,
#                     "savings": savings
#                 }),
#                 "mode": "tool_only"
#             }
        
#         # Use full agent with LLM - NO NEW LOOP CREATED
#         try:
#             # Just await directly - no new loop
#             result = await self.agent_executor.ainvoke({
#                 "input": "Analyze this infrastructure and provide recommendations",
#                 "chat_history": self.memory.chat_memory.messages if self.memory else []
#             })
#             result["mode"] = "full_agent"
#             return result
#         except Exception as e:
#             logger.error(f"LLM analysis failed: {e}")
#             return {
#                 "analysis": f"LLM analysis failed: {e}\nFalling back to tool data",
#                 "mode": "error_fallback",
#                 "error": str(e)
#             }
"""
Cloud Rationalization Agent - Complete Version with Retry Control
"""
from typing import Dict, List, Optional, Any
from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langchain.memory import ConversationBufferMemory
import logging
import json
import httpx
import certifi
from datetime import datetime
import asyncio

# Import tools
from src.tools.aws_pricing import AWSPricingTool
from src.tools.azure_pricing import AzurePricingTool
from src.tools.gcp_pricing import GCPPricingTool
from src.tools.analyzers import WorkloadAnalyzer, CostOptimizer

logger = logging.getLogger(__name__)

class CloudRationalizationAgent:
    """
    AI Agent for cloud infrastructure rationalization
    Fixed version with retry control and quota management
    """
    
    def __init__(self, 
                 openai_api_key: Optional[str] = None,
                 aws_credentials: Optional[Dict] = None,
                 azure_credentials: Optional[Dict] = None,
                 gcp_credentials: Optional[Dict] = None,
                 model: str = "gpt-3.5-turbo",
                 temperature: float = 0.1):
        """
        Initialize the agent with retries disabled
        """
        # Create HTTP client with SSL fix
        self.http_client = httpx.Client(
            verify=certifi.where(),
            timeout=30.0,
            follow_redirects=True
        )
        
        # Initialize tools FIRST
        self.tools = self._initialize_tools(
            aws_credentials or {},
            azure_credentials or {},
            gcp_credentials or {}
        )
        logger.info(f"✅ Tools initialized: {len(self.tools)} tools available")
        
        # Track quota status
        self._quota_exceeded = False
        self._last_quota_error = None
        
        # Initialize LLM (optional)
        self.llm = None
        self.agent = None
        self.agent_executor = None
        self.memory = None
        
        if openai_api_key:
            try:
                # FIX 1: Disable retries by setting max_retries=1
                self.llm = ChatOpenAI(
                    model=model,
                    temperature=temperature,
                    api_key=openai_api_key,
                    http_client=self.http_client,
                    max_retries=1,  # Only try ONCE, no retries
                    request_timeout=30
                )
                logger.info("✅ LLM initialized with retries disabled")
                
                # Create agent with limits
                self.memory = ConversationBufferMemory(
                    memory_key="chat_history",
                    return_messages=True
                )
                
                self.agent = self._create_agent()
                self.agent_executor = AgentExecutor(
                    agent=self.agent,
                    tools=self.tools,
                    verbose=False,  # Set to False to reduce noise
                    handle_parsing_errors=True,
                    max_iterations=2,  # Limit iterations
                    max_execution_time=30,  # Max 30 seconds
                    early_stopping_method="generate"
                )
                logger.info("✅ Full agent initialized with limits")
                
            except Exception as e:
                logger.warning(f"⚠️ LLM initialization failed: {e}")
                logger.info("🔄 Running in TOOL-ONLY mode")
        else:
            logger.info("🔄 No API key provided - running in TOOL-ONLY mode")
    
    def _initialize_tools(self, aws_creds, azure_creds, gcp_creds):
        """Initialize all tools"""
        tools = []
        tools.append(AWSPricingTool(credentials=aws_creds))
        tools.append(AzurePricingTool(credentials=azure_creds))
        tools.append(GCPPricingTool(credentials=gcp_creds))
        tools.append(WorkloadAnalyzer())
        tools.append(CostOptimizer())
        return tools
    
    def _create_agent(self):
        """Create the LangChain agent"""
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert cloud rationalization advisor."""),
            MessagesPlaceholder(variable_name="chat_history"),
            ("user", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad")
        ])
        return create_openai_tools_agent(self.llm, self.tools, prompt)
    
    # ===== SYNCHRONOUS TOOL METHODS (Always work) =====
    
    def compare_prices(self, 
                       resource_type: str = "ec2",
                       specifications: Dict = None,
                       regions: list = None) -> Dict:
        """Compare prices across providers - SYNCHRONOUS"""
        if specifications is None:
            specifications = {"instance_type": "t3.medium"}
        if regions is None:
            regions = ["us-east-1"]
        
        results = {}
        pricing_tools = [t for t in self.tools if 'pricing' in t.name]
        
        for tool in pricing_tools:
            try:
                region = regions[0] if regions else "us-east-1"
                result = tool._run(
                    resource_type=resource_type,
                    region=region,
                    specifications=specifications,
                    quantity=1
                )
                if isinstance(result, str):
                    result = json.loads(result)
                provider = tool.name.replace('_pricing_tool', '').replace('_', '')
                results[provider] = result
            except Exception as e:
                provider = tool.name.replace('_pricing_tool', '')
                results[provider] = {"error": str(e)}
        
        return results
    
    def analyze_workload(self, resources: List[Dict]) -> Dict:
        # """Analyze workload using tools only"""
        # analyzer = next((t for t in self.tools if 'WorkloadAnalyzer' in t.__class__.__name__), None)
        # if analyzer:
        #     try:
        #         result = analyzer._run(resources)
        #         return json.loads(result) if isinstance(result, str) else result
        #     except Exception as e:
        #         return {"error": str(e)}
        # return {"error": "Analyzer tool not found"}
        #    """Analyze ALL resources - fixed to process every resource"""
        
        """
        Enhanced workload analysis with better decision logic
        This REPLACES the old analyze_workload method
        """
        
        recommendations = []
        total_cost = 0
        skipped_resources = []
        
        for resource in resources:
            name = resource.get('name', 'Unknown')
            r_type = resource.get('resource_type', 'compute').lower()
            cost = resource.get('monthly_cost', 0)
            usage = resource.get('usage_pattern', 'steady')
            fault_tolerant = resource.get('fault_tolerant', False)
            criticality = resource.get('criticality', 'medium')
            
            # Get utilization metrics (default values if not provided)
            cpu_util = resource.get('specifications', {}).get('cpu_utilization', 50)
            if 'cpu_utilization' not in resource.get('specifications', {}):
                # Try to get from root level
                cpu_util = resource.get('cpu_utilization', 50)
            
            memory_util = resource.get('specifications', {}).get('memory_utilization', 50)
            if 'memory_utilization' not in resource.get('specifications', {}):
                memory_util = resource.get('memory_utilization', 50)
            
            storage_util = resource.get('specifications', {}).get('storage_utilization', 50)
            
            total_cost += cost
            resource_recommendations = []
            
            # ===== COMPUTE RESOURCES =====
            if r_type == 'compute':
                # Only recommend downsizing if ACTUALLY underutilized
                if cpu_util < 30 and memory_util < 40 and criticality != 'high':
                    savings = cost * 0.4
                    resource_recommendations.append({
                        "resource": name,
                        "type": "right_size",
                        "title": f"Downsize {name}",
                        "savings": round(savings, 2),
                        "risk": "low",
                        "reason": f"Low utilization (CPU: {cpu_util}%, Memory: {memory_util}%)"
                    })
                
                # Recommend upsizing if overutilized
                elif cpu_util > 80 or memory_util > 85:
                    resource_recommendations.append({
                        "resource": name,
                        "type": "upsize",
                        "title": f"Upgrade {name}",
                        "savings": 0,
                        "risk": "medium",
                        "reason": f"High utilization (CPU: {cpu_util}%, Memory: {memory_util}%) - prevent performance issues"
                    })
                
                # Spot instance recommendation (only for batch/fault-tolerant)
                if fault_tolerant and usage == 'batch' and cpu_util > 50:
                    savings = cost * 0.6
                    resource_recommendations.append({
                        "resource": name,
                        "type": "spot",
                        "title": f"Use Spot instances for {name}",
                        "savings": round(savings, 2),
                        "risk": "high",
                        "reason": "Fault-tolerant batch workload with good utilization"
                    })
                
                # Reserved instance recommendation (steady, critical)
                elif usage == 'steady' and criticality == 'high' and cpu_util > 40:
                    savings = cost * 0.3
                    resource_recommendations.append({
                        "resource": name,
                        "type": "reserved_instance",
                        "title": f"Add Reserved Instance for {name}",
                        "savings": round(savings, 2),
                        "risk": "medium",
                        "reason": "Critical steady workload - good RI candidate"
                    })
            
            # ===== DATABASE RESOURCES =====
            elif r_type == 'database':
                if usage == 'steady':
                    if criticality == 'high':
                        savings = cost * 0.35
                        resource_recommendations.append({
                            "resource": name,
                            "type": "ri_database",
                            "title": f"Add Reserved Instance for {name}",
                            "savings": round(savings, 2),
                            "risk": "medium",
                            "reason": "Production database with steady usage"
                        })
                    else:
                        savings = cost * 0.15
                        resource_recommendations.append({
                            "resource": name,
                            "type": "database_optimization",
                            "title": f"Optimize {name}",
                            "savings": round(savings, 2),
                            "risk": "low",
                            "reason": "Consider right-sizing based on connections"
                        })
            
            # ===== CACHE RESOURCES =====
            elif r_type == 'cache':
                if usage == 'steady':
                    savings = cost * 0.25
                    resource_recommendations.append({
                        "resource": name,
                        "type": "cache_reserved",
                        "title": f"Add reserved nodes for {name}",
                        "savings": round(savings, 2),
                        "risk": "low",
                        "reason": "Steady cache workload benefits from reserved capacity"
                    })
            
            # ===== STORAGE RESOURCES =====
            elif r_type == 'storage':
                if storage_util < 30:
                    savings = cost * 0.5
                    resource_recommendations.append({
                        "resource": name,
                        "type": "storage_optimization",
                        "title": f"Reduce {name} storage",
                        "savings": round(savings, 2),
                        "risk": "low",
                        "reason": f"Low storage utilization ({storage_util}%)"
                    })
                else:
                    resource_recommendations.append({
                        "resource": name,
                        "type": "lifecycle_policy",
                        "title": f"Add lifecycle policy for {name}",
                        "savings": round(cost * 0.2, 2),
                        "risk": "low",
                        "reason": "Move cold data to cheaper storage tiers"
                    })
            
            # ===== SERVERLESS RESOURCES =====
            elif r_type == 'serverless':
                invocations = resource.get('specifications', {}).get('invocations', 1000000)
                if invocations < 100000:
                    savings = cost * 0.3
                    resource_recommendations.append({
                        "resource": name,
                        "type": "serverless_rightsize",
                        "title": f"Reduce memory for {name}",
                        "savings": round(savings, 2),
                        "risk": "low",
                        "reason": "Low invocation count - can reduce allocated memory"
                    })
            
            # If no recommendations for this resource, add to skipped list
            if not resource_recommendations:
                skipped_resources.append({
                    "name": name,
                    "type": r_type,
                    "reason": "Already optimized or insufficient data"
                })
            else:
                recommendations.extend(resource_recommendations)
        
        # Sort by savings (positive savings first)
        recommendations.sort(key=lambda x: x['savings'], reverse=True)
        
        result = {
            "summary": {
                "total_resources": len(resources),
                "total_cost": round(total_cost, 2),
                "recommendations_count": len([r for r in recommendations if r['savings'] > 0]),
                "total_potential_savings": round(sum(r['savings'] for r in recommendations if r['savings'] > 0), 2)
            },
            "recommendations": recommendations
        }
        
        # Add skipped resources info if any
        if skipped_resources:
            result["skipped_resources"] = skipped_resources
            result["summary"]["skipped_count"] = len(skipped_resources)
        
        return result

    def calculate_savings(self, current_costs: Dict, strategy: str = "combined") -> Dict:
        """Calculate savings using tools only"""
        optimizer = next((t for t in self.tools if 'CostOptimizer' in t.__class__.__name__), None)
        if optimizer:
            try:
                result = optimizer._run(current_costs, strategy)
                return json.loads(result) if isinstance(result, str) else result
            except Exception as e:
                return {"error": str(e)}
        return {"error": "Optimizer tool not found"}
    
    # ===== ASYNC LLM METHOD (With quota handling) =====
    
    # async def analyze_with_llm(self, request):
    #     """
    #     Full agent analysis WITH LLM - Handles quota errors gracefully
    #     This is ASYNC and should be awaited
    #     """
    #     # Check quota cache first
    #     if self._quota_exceeded:
    #         if self._last_quota_error:
    #             # Wait 1 hour before trying again
    #             elapsed = (datetime.now() - self._last_quota_error).seconds
    #             if elapsed < 3600:  # 1 hour
    #                 return {
    #                     "analysis": "OpenAI quota exceeded. Please try again later or use Tool-Only Mode.",
    #                     "mode": "quota_cached",
    #                     "error": "quota_exceeded",
    #                     "retry_after": f"{3600 - elapsed} seconds"
    #                 }
    #             else:
    #                 self._quota_exceeded = False
        
    #     # If no LLM, use tool-only mode
    #     if not self.agent_executor:
    #         logger.info("LLM unavailable - using tool-only mode")
    #         return self._get_tool_only_analysis(request)
        
    #     try:
    #         # FIX 2: Use asyncio.wait_for to prevent hanging
    #         import asyncio
    #         result = await asyncio.wait_for(
    #             self.agent_executor.ainvoke({
    #                 "input": "Analyze this infrastructure and provide cost optimization recommendations with specific savings numbers.",
    #                 "chat_history": self.memory.chat_memory.messages if self.memory else []
    #             }),
    #             timeout=25  # Shorter timeout
    #         )
            
    #         # Reset quota flag on success
    #         self._quota_exceeded = False
    #         result["mode"] = "full_agent"
    #         return result
            
    #     except asyncio.TimeoutError:
    #         logger.error("Analysis timed out")
    #         return {
    #             "analysis": "Analysis timed out. Please try again or use Tool-Only Mode.",
    #             "mode": "timeout_error",
    #             "error": "timeout"
    #         }
    #     except Exception as e:
    #         error_str = str(e)
    #         logger.error(f"LLM analysis failed: {e}")
            
    #         # FIX 3: Handle quota errors specifically
    #         if "429" in error_str or "quota" in error_str.lower() or "rate limit" in error_str.lower():
    #             self._quota_exceeded = True
    #             self._last_quota_error = datetime.now()
    #             return {
    #                 "analysis": "OpenAI quota exceeded. Please switch to Tool-Only Mode or add funds to your account.",
    #                 "mode": "quota_error",
    #                 "error": "quota_exceeded",
    #                 "suggestion": "Use Tool-Only Mode in the sidebar for immediate results"
    #             }
            
    #         # Return tool-only analysis as fallback
    #         return {
    #             "analysis": f"LLM analysis failed: {error_str}\n\nFalling back to tool-only analysis.",
    #             "tool_outputs": self._get_tool_only_analysis(request).get("tool_outputs", {}),
    #             "mode": "error_fallback"
    #         }
    async def analyze_with_llm(self, request):
        """
        Full agent analysis WITH LLM - Handles quota and connection errors gracefully
        """
        # Check quota cache first
        if self._quota_exceeded:
            if self._last_quota_error:
                elapsed = (datetime.now() - self._last_quota_error).seconds
                if elapsed < 3600:  # 1 hour
                    return {
                        "analysis": "OpenAI quota exceeded. Please try again later or use Tool-Only Mode.",
                        "mode": "quota_cached",
                        "error": "quota_exceeded",
                        "retry_after": f"{3600 - elapsed} seconds",
                        "show_demo": True  # Flag to show demo analysis
                    }
                else:
                    self._quota_exceeded = False
        
        # If no LLM, use tool-only mode
        if not self.agent_executor:
            logger.info("LLM unavailable - using tool-only mode")
            return self._get_tool_only_analysis(request)
        
        try:
            import asyncio
            result = await asyncio.wait_for(
                self.agent_executor.ainvoke({
                    "input": "Analyze this infrastructure and provide cost optimization recommendations with specific savings numbers.",
                    "chat_history": self.memory.chat_memory.messages if self.memory else []
                }),
                timeout=25
            )
            
            self._quota_exceeded = False
            result["mode"] = "full_agent"
            return result
            
        except asyncio.TimeoutError:
            logger.error("Analysis timed out")
            return {
                "analysis": "Analysis timed out. This may be due to network latency or OpenAI slowness.",
                "mode": "timeout_error",
                "error": "timeout",
                "show_demo": True
            }
        except Exception as e:
            error_str = str(e)
            logger.error(f"LLM analysis failed: {e}")
            
            # Handle quota errors
            if "429" in error_str or "quota" in error_str.lower() or "rate limit" in error_str.lower():
                self._quota_exceeded = True
                self._last_quota_error = datetime.now()
                return {
                    "analysis": "OpenAI quota exceeded. Please switch to Tool-Only Mode or add funds to your account.",
                    "mode": "quota_error",
                    "error": "quota_exceeded",
                    "show_demo": True
                }
            
            # Handle connection errors (corporate network blocking)
            if "Connection" in error_str or "connect" in error_str.lower() or "SSL" in error_str or "certificate" in error_str.lower():
                return {
                    "analysis": """
    ## 🔒 Network Connection Error

    Cannot connect to OpenAI API. This is likely due to:

    1. **Corporate firewall/proxy** blocking OpenAI
    2. **SSL certificate issues** in your environment
    3. **Network connectivity problems**

    ### ✅ Solutions:
    - **Switch to Tool-Only Mode** in the sidebar (recommended)
    - Configure proxy settings in your `.env` file:
    ```

    HTTP_PROXY=http://proxy.company.com:8080
    HTTPS_PROXY=http://proxy.company.com:8080

    ```
    - Use **API Mode** with a server that has OpenAI access
    - Check with your IT department about allowing `api.openai.com`

    The agent will continue with **demo analysis** below.
    """,
                    "mode": "connection_error",
                    "error": "connection_failed",
                    "show_demo": True,
                    "error_type": "network"
                }
            
            # Generic error
            return {
                "analysis": f"LLM analysis failed: {error_str}\n\nFalling back to tool-only analysis.",
                "mode": "error_fallback",
                "error": str(e),
                "show_demo": True
            }

    def _get_tool_only_analysis(self, request):
        """Helper for tool-only analysis"""
        resources = []
        if hasattr(request, 'current_infrastructure'):
            for r in request.current_infrastructure:
                resources.append({
                    'name': getattr(r, 'name', 'unknown'),
                    #'resource_type': getattr(r, 'resource_type', 'unknown'),
                    'provider': getattr(r, 'provider', 'unknown'),
                    'monthly_cost': getattr(r, 'monthly_cost', 0),
                    'usage_pattern': getattr(r, 'usage_pattern', 'steady'),
                    'fault_tolerant': getattr(r, 'fault_tolerant', False)
                })
            constraints = {}
        if hasattr(request, 'business_constraints'):
            constraints = {
                'max_budget': getattr(request.business_constraints, 'max_budget', None),
                'risk_tolerance': getattr(request.business_constraints, 'risk_tolerance', 'medium'),
                # ... other constraints
            }
        
        # Reuse the same method to avoid duplication
        result = self.analyze_with_constraints(resources, constraints)
        #result = self.analyze_workload(resources, constraints)
        return result

    def analyze_with_constraints(self, resources: List[Dict], constraints: Dict) -> Dict:
        """
        Enhanced tool-only analysis that processes ALL resources and respects business constraints
        """
        
        # Convert resources to dictionaries
        resource_dicts = []
        for r in resources:
            if hasattr(r, 'dict'):  # Pydantic model
                resource_dicts.append(r.dict())
            elif isinstance(r, dict):  # Already dict
                resource_dicts.append(r)
            else:
                resource_dicts.append({
                    'name': str(r),
                    'monthly_cost': 0,
                    'resource_type': 'compute',
                    'usage_pattern': 'steady',
                    'fault_tolerant': False,
                    'criticality': 'medium',
                    'specifications': {}
                })
        
        # Log what we received
        print(f"📊 Processing {len(resource_dicts)} resources:")
        for r in resource_dicts:
            print(f"  - {r.get('name')} ({r.get('resource_type')})")
        
        # Extract constraints
        max_budget = constraints.get('max_budget', float('inf'))
        risk_tolerance = constraints.get('risk_tolerance', 'medium')
        min_availability = constraints.get('min_availability', '99.9%')
        compliance = constraints.get('compliance_requirements', [])
        
        print(f"📋 Constraints: risk={risk_tolerance}, budget={max_budget}")
        
        # Risk multipliers affect savings estimates
        risk_multipliers = {
            'low': 0.15,    # Conservative - lower savings estimates
            'medium': 0.25,  # Moderate
            'high': 0.35     # Aggressive - higher savings estimates
        }
        savings_multiplier = risk_multipliers.get(risk_tolerance, 0.25)
        
        # Generate recommendations for ALL resources
        recommendations = []
        total_cost = 0
        resources_by_type = {'compute': 0, 'database': 0, 'cache': 0, 'storage': 0, 'serverless': 0, 'other': 0}
        
        for r in resource_dicts:
            name = r.get('name', 'Unknown')
            r_type = r.get('resource_type', 'compute').lower()
            cost = r.get('monthly_cost', 0)
            usage = r.get('usage_pattern', 'steady')
            fault_tolerant = r.get('fault_tolerant', False)
            criticality = r.get('criticality', 'medium')
            
            # Track by type
            if r_type in resources_by_type:
                resources_by_type[r_type] += 1
            else:
                resources_by_type['other'] += 1
            
            # Get utilization metrics (with defaults)
            specs = r.get('specifications', {})
            cpu_util = specs.get('cpu_utilization', r.get('cpu_utilization', 50))
            memory_util = specs.get('memory_utilization', r.get('memory_utilization', 50))
            storage_util = specs.get('storage_utilization', r.get('storage_utilization', 50))
            invocations = specs.get('invocations', r.get('invocations', 1000000))
            
            total_cost += cost
            resource_recs = []
            
            # ===== COMPUTE RESOURCES =====
            if r_type == 'compute':
                # Right-sizing for underutilized
                if cpu_util < 30 and memory_util < 40:
                    savings = cost * 0.4 * savings_multiplier
                    resource_recs.append({
                        "title": f"Downsize {name}",
                        "description": f"Underutilized (CPU: {cpu_util}%, Memory: {memory_util}%)",
                        "savings": round(savings, 2),
                        "risk": "low",
                        "effort": "low",
                        "reasoning": f"Right-size opportunity with {risk_tolerance} risk tolerance"
                    })
                
                # Upsizing for overutilized
                elif cpu_util > 80 or memory_util > 85:
                    resource_recs.append({
                        "title": f"Upgrade {name}",
                        "description": f"High utilization (CPU: {cpu_util}%, Memory: {memory_util}%)",
                        "savings": 0,
                        "risk": "medium",
                        "effort": "medium",
                        "reasoning": "Prevent performance degradation"
                    })
                
                # Spot for batch/fault-tolerant
                if fault_tolerant and usage == 'batch':
                    savings = cost * 0.6 * savings_multiplier
                    resource_recs.append({
                        "title": f"Use Spot for {name}",
                        "description": "Fault-tolerant batch workload",
                        "savings": round(savings, 2),
                        "risk": "high",
                        "effort": "medium",
                        "reasoning": "70% savings potential with spot instances"
                    })
                
                # RI for steady/critical
                elif usage == 'steady' and criticality == 'high':
                    savings = cost * 0.3 * savings_multiplier
                    resource_recs.append({
                        "title": f"Add RI for {name}",
                        "description": "Critical steady workload",
                        "savings": round(savings, 2),
                        "risk": "medium",
                        "effort": "medium",
                        "reasoning": "40% savings with 1-year commitment"
                    })
            
            # ===== DATABASE RESOURCES =====
            elif r_type == 'database':
                if usage == 'steady':
                    if criticality == 'high':
                        savings = cost * 0.35 * savings_multiplier
                        resource_recs.append({
                            "title": f"Add RI for {name}",
                            "description": "Production database",
                            "savings": round(savings, 2),
                            "risk": "medium",
                            "effort": "medium",
                            "reasoning": "Critical database with steady usage"
                        })
                    else:
                        savings = cost * 0.15 * savings_multiplier
                        resource_recs.append({
                            "title": f"Optimize {name}",
                            "description": "Non-critical database",
                            "savings": round(savings, 2),
                            "risk": "low",
                            "effort": "low",
                            "reasoning": "Right-size based on connections"
                        })
            
            # ===== CACHE RESOURCES =====
            elif r_type == 'cache':
                if usage == 'steady':
                    savings = cost * 0.25 * savings_multiplier
                    resource_recs.append({
                        "title": f"Add reserved nodes for {name}",
                        "description": "Steady cache workload",
                        "savings": round(savings, 2),
                        "risk": "low",
                        "effort": "low",
                        "reasoning": "Reserved cache nodes save 30%"
                    })
            
            # ===== STORAGE RESOURCES =====
            elif r_type == 'storage':
                if storage_util < 30:
                    savings = cost * 0.5 * savings_multiplier
                    resource_recs.append({
                        "title": f"Reduce {name} storage",
                        "description": f"Low utilization ({storage_util}%)",
                        "savings": round(savings, 2),
                        "risk": "low",
                        "effort": "low",
                        "reasoning": "Downsize over-provisioned storage"
                    })
                else:
                    savings = cost * 0.2 * savings_multiplier
                    resource_recs.append({
                        "title": f"Add lifecycle policy for {name}",
                        "description": "Move cold data to cheaper tiers",
                        "savings": round(savings, 2),
                        "risk": "low",
                        "effort": "medium",
                        "reasoning": "Implement S3/Blob lifecycle policies"
                    })
            
            # ===== SERVERLESS RESOURCES =====
            elif r_type == 'serverless':
                if invocations < 100000:
                    savings = cost * 0.3 * savings_multiplier
                    resource_recs.append({
                        "title": f"Reduce memory for {name}",
                        "description": f"Low invocations ({invocations})",
                        "savings": round(savings, 2),
                        "risk": "low",
                        "effort": "low",
                        "reasoning": "Optimize memory allocation"
                    })
            
            # ===== DEFAULT FOR UNKNOWN TYPES =====
            else:
                # Generic recommendation for unknown types
                savings = cost * 0.1 * savings_multiplier
                resource_recs.append({
                    "title": f"Review {name}",
                    "description": f"Resource type: {r_type}",
                    "savings": round(savings, 2),
                    "risk": "low",
                    "effort": "low",
                    "reasoning": "General optimization opportunity"
                })
            
            # Always add at least a default recommendation
            if not resource_recs:
                resource_recs.append({
                    "title": f"Monitor {name}",
                    "description": "No immediate optimization identified",
                    "savings": 0,
                    "risk": "none",
                    "effort": "none",
                    "reasoning": "Resource appears optimized"
                })
            
            recommendations.extend(resource_recs)
        
            # Apply budget constraint
            budget_alert = None
            if max_budget != float('inf') and total_cost > max_budget:
                required_savings = total_cost - max_budget
                required_percentage = (required_savings / total_cost) * 100
                
                budget_alert = {
                    "title": "⚠️ BUDGET EXCEEDED",
                    "description": f"Current: ${total_cost:,.0f} > Budget: ${max_budget:,.0f}",
                    "savings": round(required_savings, 2),
                    "risk": "high",
                    "effort": "high",
                    "reasoning": f"Need {required_percentage:.0f}% savings to meet budget"
                }
            
            # Calculate totals
            total_savings = sum(r['savings'] for r in recommendations)
            positive_savings = [r for r in recommendations if r['savings'] > 0]
            
            # Sort by savings
            recommendations.sort(key=lambda x: x['savings'], reverse=True)
            
            # Prepare result
            result = {
                "summary": {
                    "total_resources": len(resource_dicts),
                    "resources_by_type": resources_by_type,
                    "current_cost": round(total_cost, 2),
                    "optimized_cost": round(total_cost - total_savings, 2),
                    "total_savings": round(total_savings, 2),
                    "savings_percentage": round((total_savings / total_cost * 100), 1) if total_cost > 0 else 0,
                    "recommendations_count": len(positive_savings),
                    "constraints_applied": {
                        "risk_tolerance": risk_tolerance,
                        "savings_multiplier": savings_multiplier,
                        "max_budget": max_budget if max_budget != float('inf') else "unlimited",
                        "min_availability": min_availability,
                        "compliance": compliance
                    }
                },
                "recommendations": recommendations[:15]  # Top 15 recommendations
            }
            
            # Add budget alert if needed
            if budget_alert:
                result["budget_alert"] = budget_alert
                result["summary"]["budget_status"] = "exceeded"
        
        return result

