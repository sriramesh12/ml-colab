"""
SSL Certificate Fix Module
Run this before any OpenAI or HTTP requests
"""
import certifi
import os
import ssl
import httpx
import requests
import atexit

def apply_ssl_fix():
    """Apply SSL certificate fixes for all HTTP clients"""
    
    # Set environment variables
    os.environ['SSL_CERT_FILE'] = certifi.where()
    os.environ['REQUESTS_CA_BUNDLE'] = certifi.where()
    
    # For urllib3
    try:
        import urllib3
        urllib3.disable_warnings()
    except:
        pass
    
    # Patch requests session
    old_session = requests.Session
    class PatchedSession(old_session):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.verify = certifi.where()
    
    requests.Session = PatchedSession
    
    # Print confirmation
    print(f"🔐 SSL Fix Applied - Using certificates from: {certifi.where()}")
    
    return True

def create_http_client():
    """Create an HTTP client with proper SSL configuration"""
    return httpx.Client(
        verify=certifi.where(),
        timeout=30.0,
        follow_redirects=True
    )

def create_async_http_client():
    """Create an async HTTP client with proper SSL configuration"""
    return httpx.AsyncClient(
        verify=certifi.where(),
        timeout=30.0,
        follow_redirects=True
    )

# Apply fix when module is imported
apply_ssl_fix()
