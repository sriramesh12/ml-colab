"""
Cloud Rationalization Agent - SSL Bypass Version for Non-Prod Testing
"""
from typing import Dict, List, Optional, Any
from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langchain.memory import ConversationBufferMemory
import logging
import json
import httpx
import ssl
import warnings

# Suppress SSL warnings
warnings.filterwarnings("ignore", category=Warning)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CloudRationalizationAgent:
    """
    AI Agent for cloud infrastructure - SSL Bypass Version for Non-Prod
    """
    
    def __init__(self, 
                 openai_api_key: str,
                 aws_credentials: Optional[Dict] = None,
                 azure_credentials: Optional[Dict] = None,
                 gcp_credentials: Optional[Dict] = None,
                 model: str = "gpt-3.5-turbo",  # Using 3.5 for faster testing
                 temperature: float = 0.1):
        """
        Initialize with SSL bypass for non-production environments
        """
        # Create SSL context that doesn't verify certificates
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        
        # Create HTTP client with SSL verification disabled
        self.http_client = httpx.Client(
            verify=False,  # SSL BYPASS - DO NOT USE IN PRODUCTION
            timeout=30.0,
            follow_redirects=True
        )
        
        # Initialize OpenAI with bypass client
        self.llm = ChatOpenAI(
            model=model,
            temperature=temperature,
            api_key=openai_api_key,
            http_client=self.http_client,
            max_retries=2
        )
        
        # Import tools
        from src.tools.aws_pricing import AWSPricingTool
        from src.tools.azure_pricing import AzurePricingTool
        from src.tools.gcp_pricing import GCPPricingTool
        from src.tools.analyzers import WorkloadAnalyzer, CostOptimizer
        
        # Initialize tools with credentials
        self.tools = []
        self.tools.append(AWSPricingTool(credentials=aws_credentials or {}))
        self.tools.append(AzurePricingTool(credentials=azure_credentials or {}))
        self.tools.append(GCPPricingTool(credentials=gcp_credentials or {}))
        self.tools.append(WorkloadAnalyzer())
        self.tools.append(CostOptimizer())
        
        # Initialize memory
        self.memory = ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True
        )
        
        # Setup agent
        self.agent = self._create_agent()
        self.agent_executor = AgentExecutor(
            agent=self.agent,
            tools=self.tools,
            verbose=True,
            handle_parsing_errors=True,
            max_iterations=10
        )
        
        logger.info("✅ Agent initialized with SSL BYPASS (NON-PROD MODE)")
        print("⚠️  WARNING: SSL verification is DISABLED - For testing only!")
    
    def _create_agent(self):
        """Create the LangChain agent"""
        prompt = ChatPromptTemplate.from_messages([
            ("system", "You are a cloud optimization expert. Provide practical advice."),
            MessagesPlaceholder(variable_name="chat_history"),
            ("user", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad")
        ])
        
        return create_openai_tools_agent(self.llm, self.tools, prompt)
    
    async def analyze(self, request):
        """Analyze infrastructure"""
        try:
            result = await self.agent_executor.ainvoke({
                "input": "Analyze this cloud infrastructure and provide optimization recommendations",
                "chat_history": self.memory.chat_memory.messages
            })
            return result
        except Exception as e:
            logger.error(f"Analysis error: {e}")
            return {"error": str(e), "output": "Analysis failed - check logs"}
