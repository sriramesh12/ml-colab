#!/usr/bin/env python3
"""
Cloud Rationalization Agent CLI - SSL Bypass Version for Non-Prod
"""
import sys
from pathlib import Path

# Add to path
sys.path.append(str(Path(__file__).parent.parent))

# Suppress SSL warnings
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import warnings
warnings.filterwarnings("ignore")

import click
import yaml
import json
import asyncio
import os
from datetime import datetime
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.panel import Panel
from dotenv import load_dotenv

# Load environment
load_dotenv()
console = Console()

# Import bypass agent
from src.agent_bypass import CloudRationalizationAgent
from src.models.schemas import (
    RationalizationRequest, 
    CloudResource,
    BusinessConstraints,
    OptimizationGoal
)

# SSL Bypass environment variables
os.environ['SSL_CERT_FILE'] = ''
os.environ['REQUESTS_CA_BUNDLE'] = ''
os.environ['CURL_CA_BUNDLE'] = ''

print("="*60)
print("🔓 SSL BYPASS MODE - FOR TESTING ONLY")
print("="*60)

class CloudAgentCLI:
    """CLI with SSL bypass"""
    
    def __init__(self):
        self.agent = None
        self.openai_key = os.getenv("OPENAI_API_KEY")
    
    def initialize_agent(self):
        """Initialize agent with SSL bypass"""
        if not self.openai_key:
            console.print("[red]❌ OPENAI_API_KEY not found[/red]")
            return False
        
        try:
            self.agent = CloudRationalizationAgent(
                openai_api_key=self.openai_key,
                aws_credentials={},
                azure_credentials={},
                gcp_credentials={}
            )
            console.print("[green]✅ Agent initialized with SSL bypass[/green]")
            return True
        except Exception as e:
            console.print(f"[red]❌ Error: {e}[/red]")
            return False

@click.group()
def cli():
    """Cloud Agent - SSL Bypass Version"""
    pass

@cli.command()
def init():
    """Initialize agent"""
    cli_obj = CloudAgentCLI()
    cli_obj.initialize_agent()

@cli.command()
@click.argument('config_file', type=click.Path(exists=True))
def analyze(config_file):
    """Analyze infrastructure"""
    cli_obj = CloudAgentCLI()
    if not cli_obj.initialize_agent():
        return
    
    # Load config
    with open(config_file, 'r') as f:
        if config_file.endswith(('.yaml', '.yml')):
            config = yaml.safe_load(f)
        else:
            config = json.load(f)
    
    console.print("[cyan]📊 Running analysis...[/cyan]")
    
    # Create simple request
    request = RationalizationRequest(
        current_infrastructure=[],
        business_constraints=BusinessConstraints(),
        optimization_goals=[OptimizationGoal.COST_REDUCTION],
        time_horizon="1 year"
    )
    
    # Run analysis
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    result = loop.run_until_complete(cli_obj.agent.analyze(request))
    loop.close()
    
    # Show result
    if isinstance(result, dict) and 'output' in result:
        console.print(Panel(result['output'], title="Analysis Result"))
    else:
        console.print(result)

@cli.command()
@click.option('--resource', default='ec2')
@click.option('--region', default='us-east-1')
@click.option('--type', 'instance_type', default='t3.medium')
def compare(resource, region, instance_type):
    """Compare prices"""
    console.print(f"[cyan]Comparing {instance_type} in {region}...[/cyan]")
    
    # Simple table with demo prices
    table = Table(title=f"Price Comparison - {instance_type}")
    table.add_column("Provider")
    table.add_column("Hourly Rate")
    table.add_column("Monthly Rate")
    
    table.add_row("AWS", "$0.0416", "$30.37")
    table.add_row("Azure", "$0.0480", "$35.04")
    table.add_row("GCP", "$0.0375", "$27.38")
    
    console.print(table)

@cli.command()
def quick_test():
    """Quick test without SSL"""
    console.print("[green]✅ SSL Bypass working![/green]")
    console.print("\nTry these commands:")
    console.print("  python cli/cloud_agent_bypass.py init")
    console.print("  python cli/cloud_agent_bypass.py compare")
    console.print("  python cli/cloud_agent_bypass.py analyze examples/sample_config.yaml")

if __name__ == '__main__':
    cli()
