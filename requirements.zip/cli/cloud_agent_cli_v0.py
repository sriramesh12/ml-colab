#!/usr/bin/env python3
"""
Command-line interface for Cloud Rationalization Agent
"""
import click
import yaml
import json
import asyncio
import sys
import os
from pathlib import Path
from datetime import datetime
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.panel import Panel
from rich.markdown import Markdown
from rich.syntax import Syntax
from rich import print as rprint
from dotenv import load_dotenv

import json
from datetime import datetime
from enum import Enum

class PydanticJSONEncoder(json.JSONEncoder):
    """Custom JSON encoder for Pydantic models and datetime objects"""
    def default(self, obj):
        if isinstance(obj, Enum):
            return obj.value
        if isinstance(obj, datetime):
            return obj.isoformat()
        if hasattr(obj, 'dict'):
            return obj.dict()
        return super().default(obj)

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent))

from src.agent import CloudRationalizationAgent
from src.models.schemas import (
    RationalizationRequest, 
    CloudResource,
    BusinessConstraints,
    CloudProvider,
    ResourceType,
    UsagePattern,
    OptimizationGoal
)

# Load environment variables
load_dotenv()

console = Console()

class CloudAgentCLI:
    """CLI wrapper for Cloud Rationalization Agent"""
    
    def __init__(self, openai_key=None, aws_key=None, aws_secret=None):
        self.agent = None
        self.openai_key = openai_key or os.getenv("OPENAI_API_KEY")
        self.aws_key = aws_key or os.getenv("AWS_ACCESS_KEY")
        self.aws_secret = aws_secret or os.getenv("AWS_SECRET_KEY")
        
    def initialize_agent(self):
        """Initialize the agent with API keys"""
        if not self.openai_key:
            console.print("[red]Error: OPENAI_API_KEY not found. Set it in .env or pass as argument.[/red]")
            console.print("[yellow]You can create a .env file with: OPENAI_API_KEY=your_key_here[/yellow]")
            return False
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            progress.add_task(description="Initializing agent...", total=None)
            
            try:
                self.agent = CloudRationalizationAgent(
                    openai_api_key=self.openai_key,
                    aws_credentials={
                        'aws_access_key_id': self.aws_key,
                        'aws_secret_access_key': self.aws_secret
                    } if self.aws_key and self.aws_secret else None
                )
                console.print("[green]✅ Agent initialized successfully![/green]")
                return True
            except Exception as e:
                console.print(f"[red]❌ Failed to initialize agent: {e}[/red]")
                return False
            
@click.group()
def cli():
    """☁️ Cloud Rationalization Agent - AI-powered cloud optimization"""
    pass

@cli.command()
@click.option('--openai-key', envvar='OPENAI_API_KEY', help='OpenAI API key')
@click.option('--aws-key', envvar='AWS_ACCESS_KEY', help='AWS access key')
@click.option('--aws-secret', envvar='AWS_SECRET_KEY', help='AWS secret key')
def init(openai_key, aws_key, aws_secret):
    """Initialize the cloud agent"""
    cli_obj = CloudAgentCLI(openai_key, aws_key, aws_secret)
    if cli_obj.initialize_agent():
        console.print("\n[yellow]You can now run commands like:[/yellow]")
        console.print("  cloud-agent analyze config.yaml")
        console.print("  cloud-agent compare --resource ec2 --region us-east-1")
        console.print("  cloud-agent interactive")

@cli.command()
@click.argument('config_file', type=click.Path(exists=True))
@click.option('--output', '-o', type=click.Choice(['table', 'json', 'yaml', 'markdown']), default='table')
@click.option('--save', '-s', help='Save output to file')
@click.option('--format', '-f', 'output_format', type=click.Choice(['json', 'yaml']), help='Output format for saved file')
def analyze(config_file, output, save, output_format):
    """Analyze cloud infrastructure from config file"""
    
    # Load configuration
    with open(config_file, 'r') as f:
        if config_file.endswith(('.yaml', '.yml')):
            config = yaml.safe_load(f)
        else:
            config = json.load(f)
    
    console.print("[cyan]📊 Loading configuration...[/cyan]")
    
    # Initialize CLI
    cli_obj = CloudAgentCLI()
    if not cli_obj.initialize_agent():
        return
    
    # Parse resources from config
    resources = []
    for r in config.get('resources', []):
        try:
            resources.append(CloudResource(
                name=r.get('name', 'unknown'),
                resource_type=r.get('resource_type', 'compute'),
                provider=r.get('provider', 'aws'),
                region=r.get('region', 'us-east-1'),
                specifications=r.get('specifications', {}),
                quantity=r.get('quantity', 1),
                usage_pattern=r.get('usage_pattern', 'steady'),
                monthly_cost=r.get('monthly_cost', 0),
                fault_tolerant=r.get('fault_tolerant', False)
            ))
        except Exception as e:
            console.print(f"[yellow]Warning: Skipping resource - {e}[/yellow]")
    
    console.print(f"[green]✅ Loaded {len(resources)} resources[/green]")
    
    # Create request with proper error handling
    try:
        # Handle constraints
        constraints_data = config.get('constraints', {})
        # Convert string values to proper types if needed
        if 'max_budget' in constraints_data and isinstance(constraints_data['max_budget'], str):
            constraints_data['max_budget'] = float(constraints_data['max_budget'])
        
        constraints = BusinessConstraints(**constraints_data)
        
        # Handle goals
        goals_data = config.get('optimization_goals', ['cost_reduction'])
        goals = []
        for g in goals_data:
            try:
                goals.append(OptimizationGoal(g))
            except ValueError:
                console.print(f"[yellow]Warning: Unknown goal '{g}', using cost_reduction[/yellow]")
                goals.append(OptimizationGoal.COST_REDUCTION)
        
        request = RationalizationRequest(
            current_infrastructure=resources,
            business_constraints=constraints,
            optimization_goals=goals,
            time_horizon=config.get('time_horizon', '1 year')
        )
        
    except Exception as e:
        console.print(f"[red]Error creating request: {e}[/red]")
        return
    
    # Run analysis
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        console=console
    ) as progress:
        task = progress.add_task("[cyan]Analyzing infrastructure...", total=None)
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(cli_obj.agent.analyze(request))
        loop.close()
        
        progress.update(task, completed=True)
    
    # Display results based on output format
    if output == 'table':
        display_table_result(result, resources)
    elif output == 'json':
        # Use custom encoder for JSON serialization
        console.print(json.dumps(result.dict(), indent=2, cls=PydanticJSONEncoder, default=str))
    elif output == 'yaml':
        # Convert to dict first for YAML
        result_dict = json.loads(json.dumps(result.dict(), cls=PydanticJSONEncoder, default=str))
        console.print(yaml.dump(result_dict, default_flow_style=False))
    elif output == 'markdown':
        if hasattr(result, 'analysis'):
            console.print(Markdown(result.analysis))
        else:
            console.print("[yellow]No analysis text available[/yellow]")
    
    # Save to file if requested
    if save:
        try:
            save_format = output_format or output
            if save_format in ['json', 'yaml']:
                # Convert to serializable dict
                save_data = json.loads(json.dumps(result.dict(), cls=PydanticJSONEncoder, default=str))
            else:
                save_data = result.analysis if hasattr(result, 'analysis') else str(result)
            
            with open(save, 'w') as f:
                if save_format == 'json':
                    json.dump(save_data, f, indent=2, default=str)
                elif save_format == 'yaml':
                    yaml.dump(save_data, f, default_flow_style=False)
                else:
                    f.write(save_data)
            
            console.print(f"[green]✅ Results saved to {save}[/green]")
        except Exception as e:
            console.print(f"[red]Error saving file: {e}[/red]")

@cli.command()
@click.option('--resource', '-r', default='ec2', help='Resource type (ec2, vm, storage)')
@click.option('--region', '-g', default='us-east-1', help='Region')
@click.option('--type', '-t', 'instance_type', default='t3.medium', help='Instance type')
@click.option('--providers', '-p', multiple=True, help='Providers to compare (aws, azure, gcp)')
def compare(resource, region, instance_type, providers):
    """Compare prices across cloud providers"""
    
    cli_obj = CloudAgentCLI()
    if not cli_obj.initialize_agent():
        return
    
    specs = {
        'instance_type': instance_type,
        'region': region,
        'os': 'Linux'
    }
    
    with console.status("[bold green]Fetching prices from providers..."):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        prices = loop.run_until_complete(
            cli_obj.agent.compare_prices(resource, specs, [region])
        )
        loop.close()
    
    # Display comparison
    table = Table(title=f"Price Comparison - {instance_type} in {region}")
    table.add_column("Provider", style="cyan")
    table.add_column("Hourly Rate", justify="right")
    table.add_column("Monthly Rate", justify="right")
    table.add_column("Commitment", style="green")
    
    for provider, data in prices.items():
        if isinstance(data, dict):
            table.add_row(
                provider.replace('_', ' ').title(),
                f"${data.get('hourly_rate', 0):.4f}",
                f"${data.get('monthly_rate', 0):,.2f}",
                data.get('pricing_model', 'On-Demand')
            )
    
    console.print(table)

@cli.command()
def interactive():
    """Start interactive session"""
    
    cli_obj = CloudAgentCLI()
    if not cli_obj.initialize_agent():
        return
    
    console.print(Panel.fit(
        "[bold cyan]Cloud Rationalization Agent - Interactive Mode[/bold cyan]\n"
        "Type your questions about cloud optimization, or 'exit' to quit.",
        title="Welcome"
    ))
    
    while True:
        try:
            question = console.input("\n[bold yellow]You:[/bold yellow] ")
            
            if question.lower() in ['exit', 'quit', 'q']:
                console.print("[cyan]Goodbye! 👋[/cyan]")
                break
            
            if question.lower() == 'clear':
                cli_obj.agent.clear_conversation()
                console.print("[green]Conversation cleared.[/green]")
                continue
            
            with console.status("[bold green]Thinking..."):
                # For now, just pass through to agent
                # In production, this would use the conversation flow
                response = f"Processing: {question}"
                console.print(f"\n[bold cyan]Agent:[/bold cyan] {response}")
                
        except KeyboardInterrupt:
            console.print("\n[yellow]Interrupted. Goodbye![/yellow]")
            break
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")

@cli.command()
@click.argument('file', type=click.Path(exists=True))
def validate(file):
    """Validate a configuration file"""
    
    try:
        with open(file, 'r') as f:
            if file.endswith(('.yaml', '.yml')):
                config = yaml.safe_load(f)
            else:
                config = json.load(f)
        
        # Validate structure
        required_keys = ['resources']
        missing = [k for k in required_keys if k not in config]
        
        if missing:
            console.print(f"[red]Missing required keys: {', '.join(missing)}[/red]")
            return
        
        # Validate resources
        for i, r in enumerate(config['resources']):
            resource_req = ['name', 'provider', 'region']
            missing_res = [k for k in resource_req if k not in r]
            if missing_res:
                console.print(f"[red]Resource {i} missing: {', '.join(missing_res)}[/red]")
        
        console.print("[green]✅ Configuration is valid![/green]")
        console.print(f"Found {len(config['resources'])} resources")
        
    except Exception as e:
        console.print(f"[red]Validation error: {e}[/red]")

def display_table_result(result, resources):
    """Display analysis results in a rich table"""
    
    # Calculate current total
    current_total = 0
    for r in resources:
        if hasattr(r, 'monthly_cost') and r.monthly_cost:
            current_total += r.monthly_cost
    
    # Estimate optimized cost (30% savings as example)
    optimized_total = current_total * 0.7
    
    # Summary metrics
    summary = Table.grid(padding=1)
    summary.add_column(justify="center")
    summary.add_column(justify="center")
    summary.add_column(justify="center")
    summary.add_row(
        f"[bold]Current Monthly:[/bold] ${current_total:,.2f}",
        f"[bold green]Optimized:[/bold green] ${optimized_total:,.2f}",
        f"[bold yellow]Savings:[/bold yellow] ${current_total - optimized_total:,.2f} (30%)"
    )
    console.print(Panel(summary, title="Summary"))
    
    # Recommendations section
    console.print("\n[bold cyan]📋 Key Recommendations[/bold cyan]")
    
    # Try to get recommendations from result
    recommendations = []
    if hasattr(result, 'recommendations') and result.recommendations:
        recommendations = result.recommendations
    elif hasattr(result, 'analysis') and result.analysis:
        # Parse recommendations from analysis text (simplified)
        console.print(Panel(result.analysis[:500] + "...", title="Analysis Preview"))
    
    # Show sample recommendations if none found
    if not recommendations:
        table = Table(title="Sample Optimization Opportunities")
        table.add_column("Resource", style="cyan")
        table.add_column("Recommendation", style="green")
        table.add_column("Est. Savings", justify="right")
        table.add_column("Risk", style="yellow")
        
        # Add sample rows based on actual resources
        for i, r in enumerate(resources[:3]):  # Show first 3 resources
            resource_name = getattr(r, 'name', f'Resource {i+1}')
            savings = getattr(r, 'monthly_cost', 100) * 0.3
            table.add_row(
                resource_name,
                "Right-size instance" if i % 2 == 0 else "Reserved Instance",
                f"${savings:,.0f}",
                "Low" if i % 2 == 0 else "Medium"
            )
        
        console.print(table)
    
    # Full analysis
    if hasattr(result, 'analysis') and result.analysis:
        console.print("\n[bold]Detailed Analysis:[/bold]")
        console.print(Panel(result.analysis[:1000] + "..." if len(result.analysis) > 1000 else result.analysis, 
                           title="Analysis"))

if __name__ == '__main__':
    cli()
