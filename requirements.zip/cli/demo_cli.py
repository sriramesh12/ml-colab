#!/usr/bin/env python3
"""
Beautiful Demo CLI for Cloud Rationalization Agent
Shows nice tables with prices just like you want!
"""
import click
import yaml
import json
import sys
from pathlib import Path
from datetime import datetime
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import print as rprint

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent))

console = Console()

@click.group()
def cli():
    """☁️ Cloud Rationalization Agent - Beautiful Demo Version"""
    pass

@cli.command()
@click.option('--resource', '-r', default='ec2', help='Resource type')
@click.option('--region', '-g', default='us-east-1', help='Region')
@click.option('--type', '-t', 'instance_type', default='t3.medium', help='Instance type')
def compare(resource, region, instance_type):
    """Compare prices across cloud providers with beautiful tables"""
    
    console.print(Panel.fit(
        "[bold cyan]☁️ Multi-Cloud Price Comparison[/bold cyan]\n"
        f"[yellow]Resource: {resource} | Region: {region} | Type: {instance_type}[/yellow]",
        title="Cloud Rationalization Agent"
    ))
    
    # Create the beautiful table
    table = Table(title=f"💰 Price Comparison - {instance_type} in {region}", 
                  title_style="bold cyan",
                  border_style="blue")
    
    table.add_column("Provider", style="cyan", width=12)
    table.add_column("Hourly Rate", justify="right", style="green", width=15)
    table.add_column("Monthly Rate", justify="right", style="yellow", width=15)
    table.add_column("Commitment", style="magenta", width=20)
    table.add_column("Savings vs On-Demand", justify="right", style="bold green", width=18)
    
    # AWS Prices
    aws_hourly = 0.0416
    aws_monthly = aws_hourly * 730
    table.add_row(
        "AWS", 
        f"${aws_hourly:.4f}", 
        f"${aws_monthly:.2f}", 
        "On-Demand",
        "-"
    )
    table.add_row(
        "AWS", 
        f"${aws_hourly * 0.6:.4f}", 
        f"${aws_monthly * 0.6:.2f}", 
        "1-Year RI (Partial)",
        "40%"
    )
    table.add_row(
        "AWS", 
        f"${aws_hourly * 0.4:.4f}", 
        f"${aws_monthly * 0.4:.2f}", 
        "3-Year RI (All)",
        "60%"
    )
    table.add_row(
        "AWS", 
        f"${aws_hourly * 0.3:.4f}", 
        f"${aws_monthly * 0.3:.2f}", 
        "Spot Instance",
        "70%"
    )
    
    table.add_section()
    
    # Azure Prices
    azure_hourly = 0.0480
    azure_monthly = azure_hourly * 730
    table.add_row(
        "Azure", 
        f"${azure_hourly:.4f}", 
        f"${azure_monthly:.2f}", 
        "Pay-As-You-Go",
        "-"
    )
    table.add_row(
        "Azure", 
        f"${azure_hourly * 0.65:.4f}", 
        f"${azure_monthly * 0.65:.2f}", 
        "1-Year Reserved",
        "35%"
    )
    table.add_row(
        "Azure", 
        f"${azure_hourly * 0.45:.4f}", 
        f"${azure_monthly * 0.45:.2f}", 
        "3-Year Reserved",
        "55%"
    )
    table.add_row(
        "Azure", 
        f"${azure_hourly * 0.2:.4f}", 
        f"${azure_monthly * 0.2:.2f}", 
        "Spot/Low Priority",
        "80%"
    )
    
    table.add_section()
    
    # GCP Prices
    gcp_hourly = 0.0375
    gcp_monthly = gcp_hourly * 730
    table.add_row(
        "GCP", 
        f"${gcp_hourly:.4f}", 
        f"${gcp_monthly:.2f}", 
        "On-Demand",
        "-"
    )
    table.add_row(
        "GCP", 
        f"${gcp_hourly * 0.7:.4f}", 
        f"${gcp_monthly * 0.7:.2f}", 
        "1-Year Committed",
        "30%"
    )
    table.add_row(
        "GCP", 
        f"${gcp_hourly * 0.5:.4f}", 
        f"${gcp_monthly * 0.5:.2f}", 
        "3-Year Committed",
        "50%"
    )
    table.add_row(
        "GCP", 
        f"${gcp_hourly * 0.2:.4f}", 
        f"${gcp_monthly * 0.2:.2f}", 
        "Preemptible VM",
        "80%"
    )
    
    console.print(table)
    
    # Show best recommendation
    console.print("\n[bold cyan]🤖 Agent Recommendation:[/bold cyan]")
    
    # Find cheapest option
    prices = [
        ("AWS Spot", aws_hourly * 0.3),
        ("Azure Spot", azure_hourly * 0.2),
        ("GCP Preemptible", gcp_hourly * 0.2)
    ]
    cheapest = min(prices, key=lambda x: x[1])
    
    console.print(Panel(
        f"[bold green]Best Value: {cheapest[0]} at ${cheapest[1]:.4f}/hour (${cheapest[1]*730:.2f}/month)[/bold green]\n\n"
        f"[yellow]Note: Spot/Preemptible instances are best for:[/yellow]\n"
        f"• Fault-tolerant workloads\n"
        f"• Batch processing\n"
        f"• CI/CD runners\n"
        f"• Development environments",
        title="💡 Recommendation",
        border_style="green"
    ))

@cli.command()
@click.argument('config_file', type=click.Path(exists=True))
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table')
def analyze(config_file, output):
    """Analyze infrastructure with beautiful output"""
    
    console.print(Panel.fit(
        "[bold cyan]📊 Infrastructure Analysis[/bold cyan]",
        title="Cloud Rationalization Agent"
    ))
    
    # Load config
    with open(config_file, 'r') as f:
        if config_file.endswith(('.yaml', '.yml')):
            config = yaml.safe_load(f)
        else:
            config = json.load(f)
    
    resources = config.get('resources', [])
    
    # Calculate totals
    total_cost = 0
    for r in resources:
        cost = r.get('monthly_cost', 0)
        if isinstance(cost, str):
            cost = float(cost)
        total_cost += cost
    
    # Resources Table
    resource_table = Table(title="📋 Current Infrastructure", title_style="bold cyan")
    resource_table.add_column("Name", style="cyan")
    resource_table.add_column("Provider", style="green")
    resource_table.add_column("Type", style="yellow")
    resource_table.add_column("Region", style="blue")
    resource_table.add_column("Monthly Cost", justify="right", style="red")
    
    for r in resources:
        resource_table.add_row(
            r.get('name', 'N/A'),
            r.get('provider', 'N/A'),
            r.get('instance_type', r.get('resource_type', 'N/A')),
            r.get('region', 'N/A'),
            f"${r.get('monthly_cost', 0):.2f}"
        )
    
    resource_table.add_section()
    resource_table.add_row(
        "[bold]TOTAL[/bold]",
        "",
        "",
        "",
        f"[bold red]${total_cost:,.2f}[/bold red]"
    )
    
    console.print(resource_table)
    
    # Optimization Table
    opt_table = Table(title="💡 Optimization Opportunities", title_style="bold cyan")
    opt_table.add_column("Strategy", style="cyan")
    opt_table.add_column("Description", style="white")
    opt_table.add_column("Est. Savings", justify="right", style="green")
    opt_table.add_column("Risk", style="yellow")
    opt_table.add_column("Effort", style="magenta")
    
    opt_table.add_row(
        "Right-sizing",
        "Downsize over-provisioned instances",
        f"${total_cost * 0.15:.2f}",
        "Low",
        "Low"
    )
    opt_table.add_row(
        "Reserved Instances",
        "1-year commitment for steady workloads",
        f"${total_cost * 0.25:.2f}",
        "Medium",
        "Medium"
    )
    opt_table.add_row(
        "Spot Instances",
        "Use spot for fault-tolerant jobs",
        f"${total_cost * 0.10:.2f}",
        "High",
        "Medium"
    )
    opt_table.add_row(
        "Multi-Cloud",
        "Use cheapest provider per workload",
        f"${total_cost * 0.08:.2f}",
        "Medium",
        "High"
    )
    
    opt_table.add_section()
    opt_table.add_row(
        "[bold]TOTAL POTENTIAL[/bold]",
        "",
        f"[bold green]${total_cost * 0.58:.2f}[/bold green]",
        "",
        ""
    )
    
    console.print(opt_table)
    
    # Summary Panel
    console.print(Panel(
        f"[bold cyan]Current:[/bold cyan] ${total_cost:,.2f}/month\n"
        f"[bold green]Optimized:[/bold green] ${total_cost * 0.42:,.2f}/month\n"
        f"[bold yellow]Savings:[/bold yellow] ${total_cost * 0.58:,.2f}/month (58%)\n\n"
        f"[bold]Recommendation:[/bold] Start with right-sizing (quick wins), then move to reserved instances for production workloads.",
        title="📈 Summary",
        border_style="cyan"
    ))

@cli.command()
def interactive():
    """Interactive mode with beautiful UI"""
    
    console.print(Panel.fit(
        "[bold cyan]🤖 Cloud Rationalization Agent[/bold cyan]\n"
        "[yellow]Interactive Mode[/yellow]",
        title="Welcome"
    ))
    
    console.print("\n[cyan]Available commands:[/cyan]")
    console.print("  • compare [resource] [region] [type] - Compare prices")
    console.print("  • analyze [config] - Analyze infrastructure")
    console.print("  • help - Show this help")
    console.print("  • exit - Quit")
    
    while True:
        try:
            cmd = console.input("\n[bold yellow]❯[/bold yellow] ").strip()
            
            if cmd.lower() in ['exit', 'quit', 'q']:
                console.print("[cyan]Goodbye! 👋[/cyan]")
                break
            
            elif cmd.lower() == 'help':
                console.print("\n[cyan]Commands:[/cyan]")
                console.print("  compare ec2 us-east-1 t3.medium")
                console.print("  analyze examples/sample_config.yaml")
            
            elif cmd.startswith('compare'):
                parts = cmd.split()
                if len(parts) >= 4:
                    resource = parts[1]
                    region = parts[2]
                    instance = parts[3]
                    
                    # Create beautiful comparison table
                    table = Table(title=f"💰 {instance} in {region}")
                    table.add_column("Provider", style="cyan")
                    table.add_column("Hourly", justify="right")
                    table.add_column("Monthly", justify="right")
                    table.add_column("Type", style="green")
                    
                    table.add_row("AWS", "$0.0416", "$30.37", "On-Demand")
                    table.add_row("Azure", "$0.0480", "$35.04", "On-Demand")
                    table.add_row("GCP", "$0.0375", "$27.38", "On-Demand")
                    
                    console.print(table)
                else:
                    console.print("[red]Usage: compare [resource] [region] [type][/red]")
            
            elif cmd.startswith('analyze'):
                parts = cmd.split()
                if len(parts) >= 2:
                    config_file = parts[1]
                    if Path(config_file).exists():
                        # Run analysis
                        ctx = click.Context(analyze)
                        ctx.invoke(analyze, config_file=config_file, output='table')
                    else:
                        console.print(f"[red]File not found: {config_file}[/red]")
                else:
                    console.print("[red]Usage: analyze [config_file][/red]")
            
            else:
                console.print(f"[red]Unknown command: {cmd}[/red]")
                
        except KeyboardInterrupt:
            console.print("\n[yellow]Goodbye![/yellow]")
            break
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")

@cli.command()
def list_prices():
    """Show sample prices for all providers"""
    
    console.print(Panel.fit(
        "[bold cyan]📊 Sample Cloud Pricing[/bold cyan]",
        title="Cloud Rationalization Agent"
    ))
    
    # AWS Table
    aws_table = Table(title="AWS EC2 Pricing (us-east-1)", title_style="bold cyan")
    aws_table.add_column("Instance Type", style="cyan")
    aws_table.add_column("vCPU", justify="right")
    aws_table.add_column("Memory (GB)", justify="right")
    aws_table.add_column("On-Demand", justify="right")
    aws_table.add_column("1-yr RI", justify="right", style="green")
    aws_table.add_column("Spot", justify="right", style="yellow")
    
    instances = [
        ("t3.micro", 2, 1, "$0.0104", "$0.0062", "$0.0031"),
        ("t3.small", 2, 2, "$0.0208", "$0.0125", "$0.0062"),
        ("t3.medium", 2, 4, "$0.0416", "$0.0250", "$0.0125"),
        ("t3.large", 2, 8, "$0.0832", "$0.0499", "$0.0250"),
        ("m5.large", 2, 8, "$0.0960", "$0.0576", "$0.0288"),
        ("c5.xlarge", 4, 8, "$0.1700", "$0.1020", "$0.0510"),
    ]
    
    for inst in instances:
        aws_table.add_row(*inst)
    
    console.print(aws_table)
    
    # Azure Table
    azure_table = Table(title="Azure VM Pricing (eastus)", title_style="bold cyan")
    azure_table.add_column("Instance Type", style="cyan")
    azure_table.add_column("vCPU", justify="right")
    azure_table.add_column("Memory (GB)", justify="right")
    azure_table.add_column("Pay-As-You-Go", justify="right")
    azure_table.add_column("1-yr Reserved", justify="right", style="green")
    
    azure_instances = [
        ("B2s", 2, 4, "$0.0416", "$0.0270"),
        ("B4ms", 4, 16, "$0.1660", "$0.1079"),
        ("D2s v3", 2, 8, "$0.0960", "$0.0624"),
        ("D4s v3", 4, 16, "$0.1920", "$0.1248"),
        ("F2s v2", 2, 4, "$0.0840", "$0.0546"),
    ]
    
    for inst in azure_instances:
        azure_table.add_row(*inst)
    
    console.print(azure_table)

if __name__ == '__main__':
    cli()
