#!/usr/bin/env python3
"""
Command-line interface for Cloud Rationalization Agent
FIXED VERSION - Properly handles Pydantic serialization
"""
import click
import yaml
import json
import asyncio
import sys
import os
from pathlib import Path
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

# Rich imports for beautiful CLI output
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.panel import Panel
from rich.markdown import Markdown
from rich.syntax import Syntax
from rich import print as rprint
from dotenv import load_dotenv

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent))

from src.agent import CloudRationalizationAgent
from src.models.schemas import (
    RationalizationRequest, 
    CloudResource,
    BusinessConstraints,
    CloudProvider,
    ResourceType,
    UsagePattern,
    OptimizationGoal
)

# Load environment variables
load_dotenv()

console = Console()

# ============================================
# CUSTOM JSON ENCODER - This is the key fix!
# ============================================
class PydanticJSONEncoder(json.JSONEncoder):
    """Custom JSON encoder that handles Pydantic models, Enums, and datetime"""
    def default(self, obj):
        # Handle Pydantic models
        if hasattr(obj, 'dict'):
            return obj.dict()
        # Handle Enums
        if isinstance(obj, Enum):
            return obj.value
        # Handle datetime
        if isinstance(obj, datetime):
            return obj.isoformat()
        # Handle lists and dicts recursively
        if isinstance(obj, (list, dict)):
            return obj
        # Default to string for anything else
        return str(obj)

def safe_json_dumps(data: Any, indent: int = 2) -> str:
    """Safely convert any object to JSON string"""
    try:
        # First try normal JSON
        return json.dumps(data, indent=indent, default=str)
    except:
        try:
            # Try with our custom encoder
            return json.dumps(data, indent=indent, cls=PydanticJSONEncoder)
        except Exception as e:
            # Last resort - convert to dict first
            if hasattr(data, 'dict'):
                return json.dumps(data.dict(), indent=indent, default=str)
            elif isinstance(data, list):
                return json.dumps([safe_convert(item) for item in data], indent=indent, default=str)
            else:
                return json.dumps(str(data), indent=indent)

def safe_convert(obj: Any) -> Any:
    """Recursively convert objects to JSON-serializable types"""
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, datetime):
        return obj.isoformat()
    if hasattr(obj, 'dict'):
        return obj.dict()
    if isinstance(obj, dict):
        return {k: safe_convert(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [safe_convert(item) for item in obj]
    return str(obj)

# ============================================
# CLI Class
# ============================================
class CloudAgentCLI:
    """CLI wrapper for Cloud Rationalization Agent"""
    
    def __init__(self, openai_key=None, aws_key=None, aws_secret=None):
        self.agent = None
        self.openai_key = openai_key or os.getenv("OPENAI_API_KEY")
        self.aws_key = aws_key or os.getenv("AWS_ACCESS_KEY")
        self.aws_secret = aws_secret or os.getenv("AWS_SECRET_KEY")
        
    def initialize_agent(self):
        """Initialize the agent with API keys"""
        if not self.openai_key:
            console.print("[red]❌ Error: OPENAI_API_KEY not found.[/red]")
            console.print("[yellow]Please set it in .env file or pass as argument:[/yellow]")
            console.print("  --openai-key YOUR_KEY")
            console.print("\nOr create a .env file with:")
            console.print("  OPENAI_API_KEY=your_key_here")
            return False
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            progress.add_task(description="Initializing agent...", total=None)
            
            try:
                self.agent = CloudRationalizationAgent(
                    openai_api_key=self.openai_key,
                    aws_credentials={
                        'aws_access_key_id': self.aws_key,
                        'aws_secret_access_key': self.aws_secret
                    } if self.aws_key and self.aws_secret else None
                )
                console.print("[green]✅ Agent initialized successfully![/green]")
                return True
            except Exception as e:
                console.print(f"[red]❌ Failed to initialize agent: {e}[/red]")
                return False

# ============================================
# CLI Commands
# ============================================
@click.group()
def cli():
    """☁️ Cloud Rationalization Agent - AI-powered cloud optimization"""
    pass

@cli.command()
@click.option('--openai-key', envvar='OPENAI_API_KEY', help='OpenAI API key')
@click.option('--aws-key', envvar='AWS_ACCESS_KEY', help='AWS access key')
@click.option('--aws-secret', envvar='AWS_SECRET_KEY', help='AWS secret key')
def init(openai_key, aws_key, aws_secret):
    """Initialize the cloud agent"""
    cli_obj = CloudAgentCLI(openai_key, aws_key, aws_secret)
    if cli_obj.initialize_agent():
        console.print("\n[yellow]You can now run commands like:[/yellow]")
        console.print("  cloud-agent analyze config.yaml")
        console.print("  cloud-agent compare --resource ec2 --region us-east-1")
        console.print("  cloud-agent interactive")

@cli.command()
@click.argument('config_file', type=click.Path(exists=True))
@click.option('--output', '-o', type=click.Choice(['table', 'json', 'yaml', 'markdown']), default='table')
@click.option('--save', '-s', help='Save output to file')
@click.option('--format', '-f', 'output_format', type=click.Choice(['json', 'yaml']), help='Output format for saved file')
@click.option('--openai-key', help='OpenAI API key (optional if in .env)')
def analyze(config_file, output, save, output_format, openai_key):
    """Analyze cloud infrastructure from config file"""
    
    console.print("[cyan]📊 Loading configuration...[/cyan]")
    
    # Load configuration
    try:
        with open(config_file, 'r') as f:
            if config_file.endswith(('.yaml', '.yml')):
                config = yaml.safe_load(f)
            else:
                config = json.load(f)
        console.print("[green]✅ Configuration loaded successfully[/green]")
    except Exception as e:
        console.print(f"[red]❌ Error loading config file: {e}[/red]")
        return
    
    # Initialize CLI
    cli_obj = CloudAgentCLI(openai_key)
    if not cli_obj.initialize_agent():
        # If no API key, run in demo mode
        console.print("[yellow]⚠️ Running in DEMO mode (no API key)[/yellow]")
        run_demo_analysis(config, output, save)
        return
    
    # Parse resources from config
    resources = []
    for i, r in enumerate(config.get('resources', [])):
        try:
            # Convert string values to appropriate types
            monthly_cost = r.get('monthly_cost', 0)
            if isinstance(monthly_cost, str):
                monthly_cost = float(monthly_cost)
            
            quantity = r.get('quantity', 1)
            if isinstance(quantity, str):
                quantity = int(quantity)
            
            resource = CloudResource(
                name=r.get('name', f'resource-{i}'),
                resource_type=r.get('resource_type', 'compute'),
                provider=r.get('provider', 'aws'),
                region=r.get('region', 'us-east-1'),
                specifications=r.get('specifications', {}),
                quantity=quantity,
                usage_pattern=r.get('usage_pattern', 'steady'),
                monthly_cost=monthly_cost,
                fault_tolerant=r.get('fault_tolerant', False)
            )
            resources.append(resource)
        except Exception as e:
            console.print(f"[yellow]⚠️ Warning: Skipping resource {i} - {e}[/yellow]")
    
    console.print(f"[green]✅ Loaded {len(resources)} resources[/green]")
    
    if not resources:
        console.print("[red]❌ No valid resources found in config[/red]")
        return
    
    # Create request
    try:
        # Handle constraints
        constraints_data = config.get('constraints', {})
        # Convert string values to proper types
        if 'max_budget' in constraints_data and isinstance(constraints_data['max_budget'], str):
            constraints_data['max_budget'] = float(constraints_data['max_budget'])
        
        constraints = BusinessConstraints(**constraints_data)
        
        # Handle goals
        goals_data = config.get('optimization_goals', ['cost_reduction'])
        goals = []
        for g in goals_data:
            try:
                goals.append(OptimizationGoal(g))
            except ValueError:
                console.print(f"[yellow]⚠️ Warning: Unknown goal '{g}', using cost_reduction[/yellow]")
                goals.append(OptimizationGoal.COST_REDUCTION)
        
        request = RationalizationRequest(
            current_infrastructure=resources,
            business_constraints=constraints,
            optimization_goals=goals,
            time_horizon=config.get('time_horizon', '1 year')
        )
        
    except Exception as e:
        console.print(f"[red]❌ Error creating request: {e}[/red]")
        return
    
    # Run analysis
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        console=console
    ) as progress:
        task = progress.add_task("[cyan]🤖 Analyzing infrastructure with AI...", total=None)
        
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            result = loop.run_until_complete(cli_obj.agent.analyze(request))
            loop.close()
            progress.update(task, completed=True)
            console.print("[green]✅ Analysis complete![/green]")
        except Exception as e:
            progress.update(task, completed=True)
            console.print(f"[red]❌ Analysis failed: {e}[/red]")
            return
    
    # Display results
    display_results(result, resources, output, save, output_format)

def run_demo_analysis(config, output, save):
    """Run a demo analysis without API key"""
    console.print("[yellow]Generating demo analysis...[/yellow]")
    
    # Calculate totals from config
    total_cost = 0
    resources = config.get('resources', [])
    for r in resources:
        cost = r.get('monthly_cost', 0)
        if isinstance(cost, str):
            cost = float(cost)
        total_cost += cost
    
    # Create demo result
    demo_result = {
        "analysis": f"""
## Demo Analysis (No API Key)

### Current Infrastructure Summary
- Total Resources: {len(resources)}
- Current Monthly Cost: ${total_cost:,.2f}
- Estimated Optimized Cost: ${total_cost * 0.7:,.2f}
- Potential Savings: ${total_cost * 0.3:,.2f} (30%)

### Sample Recommendations
1. **Right-size over-provisioned instances**
   - Look for instances with low CPU/memory utilization
   - Potential savings: 15-20%

2. **Purchase Reserved Instances**
   - For steady-state production workloads
   - Potential savings: 40-60% vs on-demand

3. **Use Spot Instances**
   - For fault-tolerant batch jobs
   - Potential savings: 60-90%

### Next Steps
- Add your OpenAI API key to get real AI-powered analysis
- Set up cloud provider credentials for live pricing
- Run with '--output json' to see structured data
""",
        "recommendations": [
            {"title": "Right-sizing", "savings": total_cost * 0.15, "risk": "low"},
            {"title": "Reserved Instances", "savings": total_cost * 0.25, "risk": "medium"},
            {"title": "Spot Instances", "savings": total_cost * 0.10, "risk": "high"}
        ],
        "current_cost": total_cost,
        "optimized_cost": total_cost * 0.7
    }
    
    display_results(demo_result, resources, output, save, output_format)

def display_results(result, resources, output, save, output_format):
    """Display results in the specified format"""
    
    if output == 'table':
        display_table_result(result, resources)
    elif output == 'json':
        # Use our safe JSON serialization
        console.print(safe_json_dumps(result))
    elif output == 'yaml':
        # Convert to safe dict first
        safe_result = safe_convert(result)
        console.print(yaml.dump(safe_result, default_flow_style=False))
    elif output == 'markdown':
        if isinstance(result, dict) and 'analysis' in result:
            console.print(Markdown(result['analysis']))
        elif hasattr(result, 'analysis'):
            console.print(Markdown(result.analysis))
        else:
            console.print("[yellow]No analysis text available[/yellow]")
    
    # Save to file if requested
    if save:
        try:
            save_format = output_format or output
            safe_data = safe_convert(result)
            
            with open(save, 'w') as f:
                if save_format == 'json':
                    json.dump(safe_data, f, indent=2, default=str)
                elif save_format == 'yaml':
                    yaml.dump(safe_data, f, default_flow_style=False)
                else:
                    if isinstance(result, dict) and 'analysis' in result:
                        f.write(result['analysis'])
                    elif hasattr(result, 'analysis'):
                        f.write(result.analysis)
                    else:
                        f.write(str(result))
            
            console.print(f"[green]✅ Results saved to {save}[/green]")
        except Exception as e:
            console.print(f"[red]❌ Error saving file: {e}[/red]")

def display_table_result(result, resources):
    """Display analysis results in a rich table"""
    
    # Calculate current total
    if isinstance(resources, list):
        current_total = 0
        for r in resources:
            if isinstance(r, dict):
                cost = r.get('monthly_cost', 0)
            else:
                cost = getattr(r, 'monthly_cost', 0)
            if isinstance(cost, str):
                cost = float(cost)
            current_total += cost
    else:
        current_total = 0
    
    # Get optimized cost
    if isinstance(result, dict):
        optimized_total = result.get('optimized_cost', current_total * 0.7)
        analysis_text = result.get('analysis', '')
        recommendations = result.get('recommendations', [])
    else:
        optimized_total = getattr(result, 'optimized_cost', current_total * 0.7)
        analysis_text = getattr(result, 'analysis', '')
        recommendations = getattr(result, 'recommendations', [])
    
    # Summary metrics
    summary = Table.grid(padding=1)
    summary.add_column(justify="center")
    summary.add_column(justify="center")
    summary.add_column(justify="center")
    summary.add_row(
        f"[bold]Current Monthly:[/bold] ${current_total:,.2f}",
        f"[bold green]Optimized:[/bold green] ${optimized_total:,.2f}",
        f"[bold yellow]Savings:[/bold yellow] ${current_total - optimized_total:,.2f} ({((current_total - optimized_total)/current_total*100):.1f}%)"
    )
    console.print(Panel(summary, title="Summary"))
    
    # Recommendations section
    if recommendations:
        console.print("\n[bold cyan]📋 Key Recommendations[/bold cyan]")
        table = Table()
        table.add_column("Recommendation", style="cyan")
        table.add_column("Savings", justify="right")
        table.add_column("Risk", style="yellow")
        
        for rec in recommendations[:5]:
            if isinstance(rec, dict):
                title = rec.get('title', 'N/A')
                savings = rec.get('savings', 0)
                risk = rec.get('risk', 'medium')
            else:
                title = getattr(rec, 'title', 'N/A')
                savings = getattr(rec, 'savings', 0)
                risk = getattr(rec, 'risk', 'medium')
            
            table.add_row(
                title,
                f"${savings:,.0f}",
                risk.upper()
            )
        
        console.print(table)
    
    # Analysis text
    if analysis_text:
        console.print("\n[bold]📝 Analysis:[/bold]")
        # Show first 500 chars if too long
        if len(analysis_text) > 1000:
            console.print(Panel(analysis_text[:1000] + "...", title="Analysis Preview"))
        else:
            console.print(Panel(analysis_text, title="Analysis"))

@cli.command()
@click.option('--resource', '-r', default='ec2', help='Resource type (ec2, vm, storage)')
@click.option('--region', '-g', default='us-east-1', help='Region')
@click.option('--type', '-t', 'instance_type', default='t3.medium', help='Instance type')
@click.option('--providers', '-p', multiple=True, help='Providers to compare (aws, azure, gcp)')
@click.option('--openai-key', help='OpenAI API key (optional if in .env)')
def compare(resource, region, instance_type, providers, openai_key):
    """Compare prices across cloud providers"""
    
    cli_obj = CloudAgentCLI(openai_key)
    if not cli_obj.initialize_agent():
        console.print("[yellow]Running in demo mode - showing sample prices[/yellow]")
        show_demo_prices(resource, region, instance_type)
        return
    
    specs = {
        'instance_type': instance_type,
        'region': region,
        'os': 'Linux'
    }
    
    with console.status("[bold green]Fetching prices from providers..."):
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            prices = loop.run_until_complete(
                cli_obj.agent.compare_prices(resource, specs, [region])
            )
            loop.close()
            
            # Display comparison
            table = Table(title=f"Price Comparison - {instance_type} in {region}")
            table.add_column("Provider", style="cyan")
            table.add_column("Hourly Rate", justify="right")
            table.add_column("Monthly Rate", justify="right")
            table.add_column("Commitment", style="green")
            
            for provider, data in prices.items():
                if isinstance(data, dict):
                    table.add_row(
                        provider.replace('_', ' ').title(),
                        f"${data.get('hourly_rate', 0):.4f}",
                        f"${data.get('monthly_rate', 0):,.2f}",
                        data.get('pricing_model', 'On-Demand')
                    )
            
            console.print(table)
            
        except Exception as e:
            console.print(f"[red]Error fetching prices: {e}[/red]")
            show_demo_prices(resource, region, instance_type)

def show_demo_prices(resource, region, instance_type):
    """Show demo prices when API is not available"""
    table = Table(title=f"Demo Price Comparison - {instance_type} in {region}")
    table.add_column("Provider", style="cyan")
    table.add_column("Hourly Rate", justify="right")
    table.add_column("Monthly Rate", justify="right")
    table.add_column("Commitment", style="green")
    
    # Sample prices
    table.add_row("AWS", "$0.0416", "$30.37", "On-Demand")
    table.add_row("Azure", "$0.0480", "$35.04", "On-Demand")
    table.add_row("GCP", "$0.0375", "$27.38", "On-Demand")
    
    console.print(table)
    console.print("\n[yellow]⚠️ These are sample prices. Add API keys for real pricing.[/yellow]")

@cli.command()
@click.option('--openai-key', help='OpenAI API key (optional if in .env)')
def interactive(openai_key):
    """Start interactive session"""
    
    cli_obj = CloudAgentCLI(openai_key)
    if not cli_obj.initialize_agent():
        console.print("[yellow]Running in demo mode[/yellow]")
    
    console.print(Panel.fit(
        "[bold cyan]Cloud Rationalization Agent - Interactive Mode[/bold cyan]\n"
        "Type your questions about cloud optimization, or 'exit' to quit.",
        title="Welcome"
    ))
    
    while True:
        try:
            question = console.input("\n[bold yellow]You:[/bold yellow] ")
            
            if question.lower() in ['exit', 'quit', 'q']:
                console.print("[cyan]Goodbye! 👋[/cyan]")
                break
            
            if question.lower() == 'clear':
                if cli_obj.agent:
                    cli_obj.agent.clear_conversation()
                console.print("[green]Conversation cleared.[/green]")
                continue
            
            with console.status("[bold green]Thinking..."):
                if cli_obj.agent:
                    # TODO: Implement conversation with agent
                    response = f"Processing: {question}\n(Full agent conversation coming soon)"
                else:
                    response = f"Demo mode: Received '{question}'\nAdd OpenAI API key for full functionality."
                
                console.print(f"\n[bold cyan]Agent:[/bold cyan] {response}")
                
        except KeyboardInterrupt:
            console.print("\n[yellow]Interrupted. Goodbye![/yellow]")
            break
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")

@cli.command()
@click.argument('file', type=click.Path(exists=True))
def validate(file):
    """Validate a configuration file"""
    
    try:
        with open(file, 'r') as f:
            if file.endswith(('.yaml', '.yml')):
                config = yaml.safe_load(f)
            else:
                config = json.load(f)
        
        console.print("[green]✅ File is valid YAML/JSON[/green]")
        
        # Validate structure
        required_keys = ['resources']
        missing = [k for k in required_keys if k not in config]
        
        if missing:
            console.print(f"[red]❌ Missing required keys: {', '.join(missing)}[/red]")
            return
        
        # Validate resources
        valid_count = 0
        for i, r in enumerate(config['resources']):
            resource_req = ['name', 'provider', 'region']
            missing_res = [k for k in resource_req if k not in r]
            if missing_res:
                console.print(f"[yellow]⚠️ Resource {i} missing: {', '.join(missing_res)}[/yellow]")
            else:
                valid_count += 1
        
        console.print(f"[green]✅ Found {len(config['resources'])} resources ({valid_count} valid)[/green]")
        
        # Show sample
        if config['resources']:
            console.print("\n[cyan]Sample resource:[/cyan]")
            sample = config['resources'][0]
            console.print(json.dumps(sample, indent=2))
        
    except Exception as e:
        console.print(f"[red]❌ Validation error: {e}[/red]")

if __name__ == '__main__':
    cli()