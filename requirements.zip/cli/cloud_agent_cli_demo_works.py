#!/usr/bin/env python3
"""
Command-line interface for Cloud Rationalization Agent
COMPLETELY FIXED VERSION
"""
import click
import yaml
import json
import asyncio
import sys
import os
from pathlib import Path
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

# Rich imports
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.panel import Panel
from rich.markdown import Markdown
from dotenv import load_dotenv

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent))

# Import models
from src.models.schemas import (
    RationalizationRequest, 
    CloudResource,
    BusinessConstraints,
    OptimizationGoal
)

# Load environment variables
load_dotenv()

console = Console()

# ============================================
# SAFE JSON SERIALIZATION
# ============================================
class SafeJSONEncoder(json.JSONEncoder):
    """Safe JSON encoder that handles all types"""
    def default(self, obj):
        # Handle Pydantic models
        if hasattr(obj, 'dict'):
            return obj.dict()
        # Handle Enums
        if isinstance(obj, Enum):
            return obj.value
        # Handle datetime
        if isinstance(obj, datetime):
            return obj.isoformat()
        # Handle bytes
        if isinstance(obj, bytes):
            return obj.decode('utf-8')
        # Handle custom objects
        if hasattr(obj, '__dict__'):
            return {k: v for k, v in obj.__dict__.items() if not k.startswith('_')}
        # Default to string
        return str(obj)

def to_serializable(obj: Any) -> Any:
    """Convert any object to a JSON-serializable format"""
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, datetime):
        return obj.isoformat()
    if hasattr(obj, 'dict'):  # Pydantic model
        return {k: to_serializable(v) for k, v in obj.dict().items()}
    if isinstance(obj, dict):
        return {k: to_serializable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_serializable(item) for item in obj]
    if hasattr(obj, '__dict__'):
        return {k: to_serializable(v) for k, v in obj.__dict__.items() if not k.startswith('_')}
    return str(obj)

def safe_json_dumps(obj: Any, indent: int = 2) -> str:
    """Safely convert any object to JSON string"""
    try:
        serializable = to_serializable(obj)
        return json.dumps(serializable, indent=indent, ensure_ascii=False)
    except Exception as e:
        # Last resort - convert to string
        return json.dumps({"error": str(e), "data": str(obj)}, indent=indent)

# ============================================
# CLI Class
# ============================================
class CloudAgentCLI:
    """CLI wrapper for Cloud Rationalization Agent"""
    
    def __init__(self, openai_key=None):
        self.agent = None
        self.openai_key = openai_key or os.getenv("OPENAI_API_KEY")
        
    def initialize_agent(self):
        """Initialize the agent with API keys"""
        if not self.openai_key:
            return False
        
        try:
            from src.agent import CloudRationalizationAgent
            self.agent = CloudRationalizationAgent(openai_api_key=self.openai_key)
            return True
        except Exception as e:
            console.print(f"[yellow]Agent initialization warning: {e}[/yellow]")
            return False

# ============================================
# CLI Commands
# ============================================
@click.group()
def cli():
    """☁️ Cloud Rationalization Agent"""
    pass

@cli.command()
@click.argument('config_file', type=click.Path(exists=True))
@click.option('--output', '-o', type=click.Choice(['table', 'json', 'yaml', 'markdown']), default='table')
@click.option('--save', '-s', help='Save output to file')
def analyze(config_file, output, save):
    """Analyze cloud infrastructure from config file"""
    
    console.print("[cyan]📊 Loading configuration...[/cyan]")
    
    # Load configuration
    try:
        with open(config_file, 'r') as f:
            if config_file.endswith(('.yaml', '.yml')):
                config = yaml.safe_load(f)
            else:
                config = json.load(f)
    except Exception as e:
        console.print(f"[red]❌ Error loading config: {e}[/red]")
        return
    
    # Parse resources
    resources = []
    for r in config.get('resources', []):
        try:
            # Handle monthly_cost safely
            monthly_cost = r.get('monthly_cost', 0)
            if isinstance(monthly_cost, str):
                monthly_cost = float(monthly_cost)
            
            resource = CloudResource(
                name=r.get('name', 'unknown'),
                resource_type=r.get('resource_type', 'compute'),
                provider=r.get('provider', 'aws'),
                region=r.get('region', 'us-east-1'),
                specifications=r.get('specifications', {}),
                quantity=int(r.get('quantity', 1)),
                usage_pattern=r.get('usage_pattern', 'steady'),
                monthly_cost=monthly_cost,
                fault_tolerant=r.get('fault_tolerant', False)
            )
            resources.append(resource)
        except Exception as e:
            console.print(f"[yellow]⚠️ Skipping resource: {e}[/yellow]")
    
    if not resources:
        console.print("[red]❌ No valid resources found[/red]")
        return
    
    console.print(f"[green]✅ Loaded {len(resources)} resources[/green]")
    
    # Create constraints
    constraints_data = config.get('constraints', {})
    
    # Convert string values to proper types
    if 'max_budget' in constraints_data and isinstance(constraints_data['max_budget'], str):
        constraints_data['max_budget'] = float(constraints_data['max_budget'])
    
    constraints = BusinessConstraints(**constraints_data)
    
    # Create goals
    goals_data = config.get('optimization_goals', ['cost_reduction'])
    goals = []
    for g in goals_data:
        try:
            goals.append(OptimizationGoal(g))
        except ValueError:
            goals.append(OptimizationGoal.COST_REDUCTION)
    
    # Calculate totals for display
    total_cost = sum(r.monthly_cost for r in resources)
    
    # Create result (simulated for now)
    result = {
        "summary": {
            "total_resources": len(resources),
            "current_monthly_cost": total_cost,
            "estimated_optimized_cost": total_cost * 0.7,
            "potential_savings": total_cost * 0.3,
            "savings_percentage": 30
        },
        "resources": [to_serializable(r) for r in resources],
        "constraints": to_serializable(constraints),
        "goals": [g.value for g in goals],
        "analysis": f"""
## Cloud Infrastructure Analysis

### Current State
- **Total Resources:** {len(resources)}
- **Current Monthly Cost:** ${total_cost:,.2f}
- **Estimated Optimized Cost:** ${total_cost * 0.7:,.2f}
- **Potential Savings:** ${total_cost * 0.3:,.2f} (30%)

### Recommendations
1. **Right-size over-provisioned instances**
   - Look for instances with low CPU/memory utilization
   - Potential savings: 15-20%

2. **Purchase Reserved Instances**
   - For steady-state production workloads
   - Potential savings: 40-60% vs on-demand

3. **Use Spot Instances**
   - For fault-tolerant batch jobs
   - Potential savings: 60-90%

### Resource Details
{chr(10).join([f'- {r.get("name")}: {r.get("provider")} {r.get("instance_type", "N/A")} (${r.get("monthly_cost", 0):,.2f}/month)' for r in to_serializable(resources)])}
        """,
        "timestamp": datetime.now().isoformat()
    }
    
    # Display results based on output format
    if output == 'table':
        display_table(result)
    elif output == 'json':
        console.print(safe_json_dumps(result))
    elif output == 'yaml':
        serializable = to_serializable(result)
        console.print(yaml.dump(serializable, default_flow_style=False))
    elif output == 'markdown':
        console.print(Markdown(result['analysis']))
    
    # Save to file if requested
    if save:
        try:
            with open(save, 'w') as f:
                if save.endswith('.json'):
                    f.write(safe_json_dumps(result))
                elif save.endswith('.yaml') or save.endswith('.yml'):
                    yaml.dump(to_serializable(result), f, default_flow_style=False)
                else:
                    f.write(result['analysis'])
            console.print(f"[green]✅ Results saved to {save}[/green]")
        except Exception as e:
            console.print(f"[red]❌ Error saving file: {e}[/red]")

def display_table(result):
    """Display results as a table"""
    
    # Summary
    summary = result['summary']
    summary_table = Table.grid(padding=1)
    summary_table.add_column(justify="center")
    summary_table.add_column(justify="center")
    summary_table.add_column(justify="center")
    summary_table.add_row(
        f"[bold]Current:[/bold] ${summary['current_monthly_cost']:,.2f}",
        f"[bold green]Optimized:[/bold green] ${summary['estimated_optimized_cost']:,.2f}",
        f"[bold yellow]Savings:[/bold yellow] ${summary['potential_savings']:,.2f} ({summary['savings_percentage']}%)"
    )
    console.print(Panel(summary_table, title="Summary"))
    
    # Resources table
    if result['resources']:
        table = Table(title="Resources")
        table.add_column("Name", style="cyan")
        table.add_column("Provider")
        table.add_column("Type")
        table.add_column("Region")
        table.add_column("Monthly Cost", justify="right")
        
        for r in result['resources'][:10]:  # Show first 10
            table.add_row(
                r.get('name', 'N/A'),
                r.get('provider', 'N/A'),
                r.get('instance_type', r.get('resource_type', 'N/A')),
                r.get('region', 'N/A'),
                f"${r.get('monthly_cost', 0):,.2f}"
            )
        
        console.print(table)
    
    # Analysis preview
    if result['analysis']:
        console.print("\n[bold]Analysis Preview:[/bold]")
        console.print(Panel(result['analysis'][:500] + "...", title="Analysis"))

@cli.command()
@click.argument('file', type=click.Path(exists=True))
def validate(file):
    """Validate a configuration file"""
    
    try:
        with open(file, 'r') as f:
            if file.endswith(('.yaml', '.yml')):
                config = yaml.safe_load(f)
                console.print("[green]✅ Valid YAML format[/green]")
            else:
                config = json.load(f)
                console.print("[green]✅ Valid JSON format[/green]")
        
        # Check required fields
        if 'resources' not in config:
            console.print("[red]❌ Missing 'resources' section[/red]")
            return
        
        if not isinstance(config['resources'], list):
            console.print("[red]❌ 'resources' must be a list[/red]")
            return
        
        # Validate each resource
        valid = 0
        for i, r in enumerate(config['resources']):
            missing = []
            for field in ['name', 'provider', 'region']:
                if field not in r:
                    missing.append(field)
            
            if missing:
                console.print(f"[yellow]⚠️ Resource {i} missing: {', '.join(missing)}[/yellow]")
            else:
                valid += 1
        
        console.print(f"[green]✅ {valid}/{len(config['resources'])} resources valid[/green]")
        
        # Show sample
        if config['resources']:
            console.print("\n[cyan]Sample resource:[/cyan]")
            console.print(json.dumps(config['resources'][0], indent=2))
        
    except yaml.YAMLError as e:
        console.print(f"[red]❌ Invalid YAML: {e}[/red]")
    except json.JSONDecodeError as e:
        console.print(f"[red]❌ Invalid JSON: {e}[/red]")
    except Exception as e:
        console.print(f"[red]❌ Validation error: {e}[/red]")

@cli.command()
@click.option('--openai-key', help='OpenAI API key')
def init(openai_key):
    """Initialize the agent (test connection)"""
    cli_obj = CloudAgentCLI(openai_key)
    if cli_obj.initialize_agent():
        console.print("[green]✅ Agent initialized successfully![/green]")
    else:
        console.print("[yellow]⚠️ Agent not initialized (no API key)[/yellow]")
        console.print("   Set OPENAI_API_KEY in .env file or pass --openai-key")

if __name__ == '__main__':
    cli()
