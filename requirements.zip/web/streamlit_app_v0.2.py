"""
Streamlit web interface for Cloud Rationalization Agent
Fixed version with proper error handling
"""
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import asyncio
import json
import sys
import os
from pathlib import Path
from datetime import datetime
import traceback

# Add project root to path
project_root = str(Path(__file__).parent.parent)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# Page configuration
st.set_page_config(
    page_title="Cloud Rationalization Agent",
    page_icon="☁️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1E88E5;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1.5rem;
        border-radius: 10px;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    .recommendation-card {
        background-color: #f0f8ff;
        padding: 1rem;
        border-radius: 5px;
        border-left: 4px solid #1E88E5;
        margin: 0.5rem 0;
    }
    .savings-positive {
        color: #00C853;
        font-weight: bold;
    }
    .error-message {
        color: #D32F2F;
        background-color: #FFEBEE;
        padding: 1rem;
        border-radius: 5px;
        border-left: 4px solid #D32F2F;
    }
</style>
""", unsafe_allow_html=True)

# Import agent with error handling
try:
    from src.agent import CloudRationalizationAgent
    from src.models.schemas import (
        RationalizationRequest, 
        CloudResource,
        BusinessConstraints,
        CloudProvider,
        ResourceType,
        UsagePattern,
        OptimizationGoal
    )
    AGENT_AVAILABLE = True
except ImportError as e:
    AGENT_AVAILABLE = False
    st.error(f"Failed to import agent modules: {e}")
    st.code(traceback.format_exc())

# Async helper
def run_async_safely(coro):
    """Safely run async function"""
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        return loop.run_until_complete(coro)
    except Exception as e:
        st.error(f"Async error: {e}")
        return None
    finally:
        loop.close()

# Initialize session state
if 'resources' not in st.session_state:
    st.session_state.resources = []
if 'analysis_result' not in st.session_state:
    st.session_state.analysis_result = None
if 'agent' not in st.session_state:
    st.session_state.agent = None
if 'agent_initialized' not in st.session_state:
    st.session_state.agent_initialized = False

# Sidebar
with st.sidebar:
    st.image("https://img.icons8.com/color/96/000000/cloud--v1.png", width=80)
    st.title("Cloud Rationalization Agent")
    
    st.header("⚙️ Configuration")
    
    # API Key input
    openai_key = st.text_input(
        "OpenAI API Key", 
        type="password",
        help="Required for intelligent analysis"
    )
    
    # Initialize agent button
    if st.button("🚀 Initialize Agent", type="primary"):
        if openai_key and AGENT_AVAILABLE:
            with st.spinner("Initializing agent..."):
                try:
                    st.session_state.agent = CloudRationalizationAgent(
                        openai_api_key=openai_key
                    )
                    st.session_state.agent_initialized = True
                    st.success("Agent initialized successfully!")
                except Exception as e:
                    st.error(f"Failed to initialize agent: {e}")
                    st.code(traceback.format_exc())
        elif not AGENT_AVAILABLE:
            st.error("Agent modules not available. Running in demo mode.")
            st.session_state.agent_initialized = False
        else:
            st.warning("Please enter OpenAI API Key")
    
    st.markdown("---")
    st.markdown("### 📊 Quick Stats")
    st.metric("Total Resources", len(st.session_state.resources))
    
    if st.button("🗑️ Clear All"):
        st.session_state.resources = []
        st.session_state.analysis_result = None
        st.rerun()

# Main content
st.markdown("<h1 class='main-header'>☁️ Cloud Infrastructure Optimizer</h1>", unsafe_allow_html=True)

# Check if agent is available
if not AGENT_AVAILABLE:
    st.warning("""
    ⚠️ Running in DEMO MODE - Agent modules not available.
    - Add resources manually below
    - Get simulated recommendations
    """)

# Create tabs
tab1, tab2, tab3 = st.tabs(["📋 Infrastructure", "📈 Analysis", "💡 Recommendations"])

# Tab 1: Infrastructure Input
with tab1:
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Add Cloud Resource")
        
        with st.form("resource_form"):
            row1_col1, row1_col2, row1_col3 = st.columns(3)
            
            with row1_col1:
                name = st.text_input("Resource Name", "web-server-01")
                provider = st.selectbox("Provider", ["aws", "azure", "gcp"])
            
            with row1_col2:
                instance_type = st.text_input("Instance Type", "t3.medium")
                region = st.text_input("Region", "us-east-1")
            
            with row1_col3:
                quantity = st.number_input("Quantity", 1, 100, 1)
                monthly_cost = st.number_input("Monthly Cost ($)", 0.0, 10000.0, 100.0)
            
            col_a, col_b, col_c = st.columns(3)
            with col_a:
                usage = st.selectbox("Usage Pattern", ["steady", "variable", "batch"])
            with col_b:
                criticality = st.selectbox("Criticality", ["high", "medium", "low"])
            with col_c:
                fault_tolerant = st.checkbox("Fault Tolerant")
            
            submitted = st.form_submit_button("➕ Add Resource")
            
            if submitted:
                st.session_state.resources.append({
                    "name": name,
                    "provider": provider,
                    "resource_type": "compute",
                    "region": region,
                    "instance_type": instance_type,
                    "quantity": quantity,
                    "monthly_cost": monthly_cost,
                    "usage_pattern": usage,
                    "criticality": criticality,
                    "fault_tolerant": fault_tolerant,
                    "specifications": {
                        "instance_type": instance_type,
                        "os": "Linux"
                    }
                })
                st.success(f"Added {name}")
    
    with col2:
        st.subheader("Business Constraints")
        with st.form("constraints_form"):
            max_budget = st.number_input("Max Monthly Budget ($)", 0, 100000, 5000)
            availability = st.select_slider("Availability", ["99%", "99.9%", "99.99%"], "99.9%")
            risk_tolerance = st.select_slider("Risk Tolerance", ["low", "medium", "high"], "medium")
            goals = st.multiselect("Optimization Goals", 
                                  ["cost_reduction", "performance", "green_it"],
                                  ["cost_reduction"])
            st.form_submit_button("Save Constraints")
    
    # Display current resources
    if st.session_state.resources:
        st.subheader("📋 Current Infrastructure")
        df = pd.DataFrame(st.session_state.resources)
        st.dataframe(df[['name', 'provider', 'instance_type', 'region', 'quantity', 'monthly_cost']], 
                    use_container_width=True)
        
        # Quick stats
        total = df['monthly_cost'].sum()
        col1, col2, col3 = st.columns(3)
        col1.metric("Total Monthly", f"${total:,.2f}")
        col2.metric("Resources", len(df))
        col3.metric("Avg Cost", f"${df['monthly_cost'].mean():,.2f}")

# Tab 2: Analysis
with tab2:
    if not st.session_state.resources:
        st.info("Add some resources first in the Infrastructure tab")
    else:
        st.subheader("Run Analysis")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🔍 Analyze with AI", type="primary", use_container_width=True):
                if st.session_state.agent_initialized and st.session_state.agent:
                    with st.spinner("Analyzing with AI..."):
                        try:
                            # Create request
                            resources = []
                            for r in st.session_state.resources:
                                resources.append(CloudResource(
                                    name=r['name'],
                                    resource_type=r.get('resource_type', 'compute'),
                                    provider=r['provider'],
                                    region=r['region'],
                                    specifications=r.get('specifications', {}),
                                    quantity=r['quantity'],
                                    usage_pattern=r.get('usage_pattern', 'steady'),
                                    monthly_cost=r['monthly_cost'],
                                    fault_tolerant=r.get('fault_tolerant', False)
                                ))
                            
                            constraints = BusinessConstraints(
                                max_budget=max_budget if 'max_budget' in locals() else None,
                                min_availability=availability if 'availability' in locals() else "99.9%",
                                risk_tolerance=risk_tolerance if 'risk_tolerance' in locals() else "medium"
                            )
                            
                            goals = [OptimizationGoal(g) for g in (goals if 'goals' in locals() else ["cost_reduction"])]
                            
                            request = RationalizationRequest(
                                current_infrastructure=resources,
                                business_constraints=constraints,
                                optimization_goals=goals,
                                time_horizon="1 year"
                            )
                            
                            # Run analysis
                            result = run_async_safely(st.session_state.agent.analyze(request))
                            
                            if result:
                                st.session_state.analysis_result = {
                                    "text": result.analysis if hasattr(result, 'analysis') else str(result),
                                    "recommendations": result.recommendations if hasattr(result, 'recommendations') else []
                                }
                                st.success("Analysis complete!")
                            
                        except Exception as e:
                            st.error(f"Analysis failed: {e}")
                            st.code(traceback.format_exc())
                else:
                    # Demo mode - simulated analysis
                    with st.spinner("Generating simulated analysis..."):
                        total = sum(r['monthly_cost'] for r in st.session_state.resources)
                        st.session_state.analysis_result = {
                            "text": f"""
## Cloud Cost Optimization Analysis

### Current State
- Total Monthly Spend: ${total:,.2f}
- Number of Resources: {len(st.session_state.resources)}

### Recommendations
1. **Right-size over-provisioned instances**: Save ~${total*0.15:,.0f}/month
2. **Purchase Reserved Instances**: Save ~${total*0.25:,.0f}/month
3. **Use Spot Instances**: Save ~${total*0.10:,.0f}/month

### Estimated Total Savings
- Monthly: ${total*0.3:,.0f} (30% reduction)
- Annual: ${total*0.3*12:,.0f}
""",
                            "recommendations": [
                                {"title": "Right-sizing", "savings": total*0.15, "risk": "low"},
                                {"title": "Reserved Instances", "savings": total*0.25, "risk": "medium"},
                                {"title": "Spot Instances", "savings": total*0.10, "risk": "high"}
                            ]
                        }
                        st.success("Demo analysis complete!")

# Tab 3: Recommendations
with tab3:
    if not st.session_state.analysis_result:
        st.info("Run an analysis first in the Analysis tab")
    else:
        st.subheader("💡 Optimization Recommendations")
        
        # Display analysis text
        if 'text' in st.session_state.analysis_result:
            st.markdown(st.session_state.analysis_result['text'])
        
        # Display structured recommendations if available
        if st.session_state.analysis_result.get('recommendations'):
            st.subheader("📊 Savings Opportunities")
            
            total = sum(r['monthly_cost'] for r in st.session_state.resources)
            cols = st.columns(3)
            
            for i, rec in enumerate(st.session_state.analysis_result['recommendations'][:3]):
                with cols[i]:
                    risk_color = {"low": "green", "medium": "orange", "high": "red"}.get(rec.get('risk', 'medium'), "blue")
                    st.markdown(f"""
                    <div class='recommendation-card'>
                        <h4>{rec.get('title', 'Recommendation')}</h4>
                        <p class='savings-positive'>💰 Savings: ${rec.get('savings', 0):,.0f}/month</p>
                        <p>Risk: <span style='color: {risk_color}'>{rec.get('risk', 'medium').upper()}</span></p>
                    </div>
                    """, unsafe_allow_html=True)
        
        # Export button
        st.subheader("📥 Export Report")
        if st.download_button(
            "Download JSON Report",
            data=json.dumps({
                "resources": st.session_state.resources,
                "analysis": st.session_state.analysis_result,
                "timestamp": str(datetime.now())
            }, indent=2, default=str),
            file_name=f"cloud_analysis_{datetime.now().strftime('%Y%m%d')}.json",
            mime="application/json"
        ):
            st.success("Report downloaded!")

# Footer
st.markdown("---")
st.markdown("Made with ❤️ using LangChain and Streamlit")