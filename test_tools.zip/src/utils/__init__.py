"""
Utilities package for Cloud Rationalization Agent
"""
import json
import yaml
from typing import Dict, Any, Optional, List
from datetime import datetime
from enum import Enum
import logging

logger = logging.getLogger(__name__)

# ===== SERIALIZATION =====

def safe_serialize(obj: Any) -> Any:
    """
    Safely serialize objects to JSON-compatible format
    
    Handles Pydantic models, datetimes, enums, and custom objects
    """
    if obj is None:
        return None
    
    # Handle Pydantic models
    if hasattr(obj, 'dict'):
        return {k: safe_serialize(v) for k, v in obj.dict().items()}
    
    # Handle datetimes
    if isinstance(obj, datetime):
        return obj.isoformat()
    
    # Handle enums
    if isinstance(obj, Enum):
        return obj.value
    
    # Handle dictionaries
    if isinstance(obj, dict):
        return {k: safe_serialize(v) for k, v in obj.items()}
    
    # Handle lists/tuples
    if isinstance(obj, (list, tuple)):
        return [safe_serialize(item) for item in obj]
    
    # Handle basic types
    if isinstance(obj, (str, int, float, bool)):
        return obj
    
    # Fallback to string
    return str(obj)

def safe_json_dumps(obj: Any, indent: int = 2) -> str:
    """
    Safely convert any object to JSON string
    """
    try:
        serializable = safe_serialize(obj)
        return json.dumps(serializable, indent=indent)
    except Exception as e:
        logger.error(f"JSON serialization error: {e}")
        return json.dumps({"error": str(e), "data": str(obj)}, indent=indent)

# ===== CONFIGURATION =====

def load_config(config_file: str) -> Dict[str, Any]:
    """
    Load configuration from JSON or YAML file
    """
    with open(config_file, 'r') as f:
        if config_file.endswith(('.yaml', '.yml')):
            return yaml.safe_load(f)
        else:
            return json.load(f)

# ===== FORMATTING =====

def format_currency(amount: float, currency: str = "USD") -> str:
    """
    Format amount as currency string
    """
    if amount is None:
        return "-"
    
    symbols = {
        "USD": "$",
        "EUR": "€",
        "GBP": "£",
        "JPY": "¥",
        "INR": "₹"
    }
    
    symbol = symbols.get(currency, "$")
    
    if amount >= 1_000_000:
        return f"{symbol}{amount/1_000_000:.2f}M"
    elif amount >= 1_000:
        return f"{symbol}{amount/1_000:.2f}K"
    else:
        return f"{symbol}{amount:.2f}"

def calculate_savings_percentage(original: float, optimized: float) -> float:
    """
    Calculate savings percentage
    """
    if original <= 0:
        return 0.0
    return ((original - optimized) / original) * 100

# ===== LIST UTILITIES (Safe versions) =====

def chunk_list(lst: List, chunk_size: int) -> List[List]:
    """
    Split a list into chunks of specified size
    Safe version that handles empty lists
    """
    if not lst or chunk_size <= 0:
        return []
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]

def merge_dicts(dict1: Dict, dict2: Dict) -> Dict:
    """
    Deep merge two dictionaries
    Safe version that handles None values
    """
    if not dict1:
        return dict2.copy() if dict2 else {}
    if not dict2:
        return dict1.copy() if dict1 else {}
    
    result = dict1.copy()
    
    for key, value in dict2.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_dicts(result[key], value)
        else:
            result[key] = value
    
    return result

# ===== RETRY DECORATOR =====

def retry_on_error(max_retries: int = 3, delay: float = 1.0):
    """
    Decorator to retry function on error
    """
    import time
    from functools import wraps
    
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_error = None
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_error = e
                    if attempt < max_retries - 1:
                        time.sleep(delay * (attempt + 1))
            raise last_error
        return wrapper
    return decorator

# ===== SSL FIX =====

def apply_ssl_fix():
    """
    Apply SSL certificate fixes for corporate networks
    """
    try:
        import certifi
        import os
        os.environ['SSL_CERT_FILE'] = certifi.where()
        os.environ['REQUESTS_CA_BUNDLE'] = certifi.where()
        logger.info(f"✅ SSL fix applied using certificates from: {certifi.where()}")
        return True
    except Exception as e:
        logger.warning(f"SSL fix not applied: {e}")
        return False

# Export all functions
__all__ = [
    'safe_serialize',
    'safe_json_dumps',
    'load_config',
    'format_currency',
    'calculate_savings_percentage',
    'chunk_list',
    'merge_dicts',
    'retry_on_error',
    'apply_ssl_fix'
]
