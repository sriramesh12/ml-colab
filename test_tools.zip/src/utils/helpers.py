"""
Utility helper functions for Cloud Rationalization Agent
Includes SSL fixes and serialization helpers
"""
import json
import yaml
import os
import certifi
import ssl
from typing import Dict, Any, Optional, Union
from datetime import datetime
from enum import Enum
import logging

logger = logging.getLogger(__name__)

# ===== SSL FIX UTILITIES =====

def apply_ssl_fix():
    """
    Apply SSL certificate fixes for corporate networks
    Call this at the beginning of your application
    """
    # Set environment variables for SSL certificates
    os.environ['SSL_CERT_FILE'] = certifi.where()
    os.environ['REQUESTS_CA_BUNDLE'] = certifi.where()
    
    # Create default SSL context with certifi
    ssl_context = ssl.create_default_context(cafile=certifi.where())
    
    logger.info(f"✅ SSL fix applied using certificates from: {certifi.where()}")
    return ssl_context

def create_ssl_context():
    """Create SSL context with proper certificates"""
    return ssl.create_default_context(cafile=certifi.where())

# ===== SERIALIZATION UTILITIES =====

def safe_serialize(obj: Any) -> Any:
    """
    Safely serialize objects to JSON-compatible format
    
    Handles Pydantic models, datetimes, enums, and custom objects
    This is the key function that fixes BusinessConstraints serialization errors
    """
    if obj is None:
        return None
    
    # Handle Pydantic models (like BusinessConstraints, CloudResource)
    if hasattr(obj, 'dict'):
        return {k: safe_serialize(v) for k, v in obj.dict().items()}
    
    # Handle datetimes
    if isinstance(obj, datetime):
        return obj.isoformat()
    
    # Handle enums
    if isinstance(obj, Enum):
        return obj.value
    
    # Handle dictionaries
    if isinstance(obj, dict):
        return {k: safe_serialize(v) for k, v in obj.items()}
    
    # Handle lists/tuples
    if isinstance(obj, (list, tuple)):
        return [safe_serialize(item) for item in obj]
    
    # Handle basic types
    if isinstance(obj, (str, int, float, bool)):
        return obj
    
    # Fallback to string
    return str(obj)

def safe_json_dumps(obj: Any, indent: int = 2) -> str:
    """
    Safely convert any object to JSON string
    Uses safe_serialize to handle complex objects
    """
    try:
        serializable = safe_serialize(obj)
        return json.dumps(serializable, indent=indent)
    except Exception as e:
        logger.error(f"JSON serialization error: {e}")
        return json.dumps({"error": str(e), "data": str(obj)}, indent=indent)

# ===== CONFIGURATION LOADING =====

def load_config(config_file: str) -> Dict[str, Any]:
    """
    Load configuration from JSON or YAML file
    
    Args:
        config_file: Path to config file (.json, .yaml, or .yml)
        
    Returns:
        Dictionary with configuration
    """
    with open(config_file, 'r') as f:
        if config_file.endswith(('.yaml', '.yml')):
            return yaml.safe_load(f)
        else:
            return json.load(f)

# ===== FORMATTING UTILITIES =====

def format_currency(amount: float, currency: str = "USD") -> str:
    """
    Format amount as currency string
    
    Args:
        amount: Numeric amount
        currency: Currency code (USD, EUR, etc.)
        
    Returns:
        Formatted currency string
    """
    symbols = {
        "USD": "$",
        "EUR": "€",
        "GBP": "£",
        "JPY": "¥",
        "INR": "₹"
    }
    
    symbol = symbols.get(currency, "$")
    
    if amount >= 1_000_000:
        return f"{symbol}{amount/1_000_000:.2f}M"
    elif amount >= 1_000:
        return f"{symbol}{amount/1_000:.2f}K"
    else:
        return f"{symbol}{amount:.2f}"

def calculate_savings_percentage(original: float, optimized: float) -> float:
    """
    Calculate savings percentage
    
    Args:
        original: Original cost
        optimized: Optimized cost
        
    Returns:
        Savings percentage (0-100)
    """
    if original <= 0:
        return 0.0
    
    savings = original - optimized
    return (savings / original) * 100

# ===== REGION UTILITIES =====

def get_region_display_name(provider: str, region_code: str) -> str:
    """
    Get display name for cloud region
    
    Args:
        provider: Cloud provider (aws, azure, gcp)
        region_code: Region code
        
    Returns:
        Human-readable region name
    """
    region_names = {
        "aws": {
            "us-east-1": "US East (N. Virginia)",
            "us-east-2": "US East (Ohio)",
            "us-west-1": "US West (N. California)",
            "us-west-2": "US West (Oregon)",
            "eu-west-1": "EU (Ireland)",
            "eu-central-1": "EU (Frankfurt)",
            "ap-southeast-1": "Asia Pacific (Singapore)",
            "ap-northeast-1": "Asia Pacific (Tokyo)"
        },
        "azure": {
            "eastus": "US East",
            "eastus2": "US East 2",
            "westus": "US West",
            "westus2": "US West 2",
            "westeurope": "West Europe",
            "northeurope": "North Europe",
            "southeastasia": "Southeast Asia",
            "japaneast": "Japan East"
        },
        "gcp": {
            "us-central1": "Iowa",
            "us-east1": "South Carolina",
            "us-west1": "Oregon",
            "europe-west1": "Belgium",
            "europe-west2": "London",
            "asia-east1": "Taiwan",
            "asia-southeast1": "Singapore"
        }
    }
    
    provider_names = region_names.get(provider.lower(), {})
    return provider_names.get(region_code, region_code)

# ===== TOOL HELPERS =====

def safe_call_tool(tool, resource_type: str, region_input: Union[str, list], 
                   specifications: Union[Dict, str], quantity: int = 1) -> Dict:
    """
    Safely call a pricing tool with proper parameter handling
    
    Handles:
    - Region as string or list
    - Specifications as dict or JSON string
    - Tool errors gracefully
    """
    # Handle region (convert list to string)
    if isinstance(region_input, list):
        region = region_input[0] if region_input else "us-east-1"
    else:
        region = region_input
    
    # Handle specifications (convert string to dict)
    if isinstance(specifications, str):
        try:
            specifications = json.loads(specifications)
        except json.JSONDecodeError:
            specifications = {"instance_type": "t3.medium", "os": "Linux"}
    
    try:
        # Call tool
        result = tool._run(
            resource_type=resource_type,
            region=region,
            specifications=specifications,
            quantity=quantity
        )
        
        # Parse result if it's a string
        if isinstance(result, str):
            return json.loads(result)
        return result
        
    except Exception as e:
        logger.error(f"Tool call failed: {e}")
        return {
            "error": str(e),
            "provider": getattr(tool, 'name', 'unknown'),
            "fallback": True
        }
