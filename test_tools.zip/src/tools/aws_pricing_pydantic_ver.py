"""
AWS Pricing Tool for Cloud Rationalization Agent
"""
from langchain.tools import BaseTool
from typing import Dict, List, Optional, Type
from pydantic import BaseModel, Field
import boto3
import json
import logging
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

class AWSPricingInput(BaseModel):
    """Input schema for AWS pricing tool"""
    resource_type: str = Field(description="Type of resource (EC2, S3, RDS, etc.)")
    region: str = Field(description="AWS region code (us-east-1, eu-west-1, etc.)")
    specifications: Dict = Field(description="Resource specifications")
    quantity: int = Field(default=1, description="Number of instances")

class AWSPricingTool(BaseTool):
    """Tool for getting AWS pricing information"""
    
    name = "aws_pricing_tool"
    description = """
    Get real-time AWS pricing for EC2, RDS, S3, and other services.
    Input should include resource type, region, and specifications.
    Returns pricing in USD with hourly and monthly rates.
    """
    args_schema: Type[BaseModel] = AWSPricingInput
    
    def __init__(self, credentials: Optional[Dict] = None):
        super().__init__()
        self.credentials = credentials or {}
        self._initialize_client()
    
    def _initialize_client(self):
        """Initialize AWS Pricing API client"""
        try:
            self.client = boto3.client(
                'pricing',
                region_name='us-east-1',
                aws_access_key_id=self.credentials.get('aws_access_key_id'),
                aws_secret_access_key=self.credentials.get('aws_secret_access_key')
            )
            logger.info("AWS Pricing client initialized")
        except Exception as e:
            logger.error(f"Failed to initialize AWS client: {e}")
            self.client = None
    
    def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
        """Run the tool"""
        try:
            if not self.client:
                return "AWS Pricing API not configured. Please provide valid credentials."
            
            # Map resource types to AWS service codes
            service_map = {
                "ec2": "AmazonEC2",
                "rds": "AmazonRDS",
                "s3": "AmazonS3",
                "lambda": "AWSLambda",
                "eks": "AmazonEKS"
            }
            
            service_code = service_map.get(resource_type.lower(), "AmazonEC2")
            
            # Build filters based on specifications
            filters = [
                {'Type': 'TERM_MATCH', 'Field': 'regionCode', 'Value': region},
            ]
            
            # Add specification-based filters
            if resource_type.lower() == 'ec2':
                filters.extend([
                    {'Type': 'TERM_MATCH', 'Field': 'instanceType', 'Value': specifications.get('instance_type', 't3.micro')},
                    {'Type': 'TERM_MATCH', 'Field': 'operatingSystem', 'Value': specifications.get('os', 'Linux')},
                    {'Type': 'TERM_MATCH', 'Field': 'tenancy', 'Value': specifications.get('tenancy', 'Shared')},
                    {'Type': 'TERM_MATCH', 'Field': 'capacitystatus', 'Value': 'Used'}
                ])
            
            # Query AWS Pricing API
            response = self.client.get_products(
                ServiceCode=service_code,
                Filters=filters,
                MaxResults=1
            )
            
            # Parse response
            prices = self._parse_pricing_response(response, resource_type)
            
            # Calculate costs
            hourly_rate = prices.get('hourly_rate', 0)
            monthly_rate = hourly_rate * 730 * quantity  # 730 hours per month
            
            result = {
                "provider": "AWS",
                "service": service_code,
                "region": region,
                "specifications": specifications,
                "quantity": quantity,
                "hourly_rate": round(hourly_rate, 4),
                "monthly_rate": round(monthly_rate, 2),
                "currency": "USD",
                "pricing_model": "On-Demand",
                "notes": "Price may vary based on commitment terms and volume discounts"
            }
            
            return json.dumps(result, indent=2)
            
        except ClientError as e:
            logger.error(f"AWS API error: {e}")
            return json.dumps({
                "error": "AWS API error",
                "details": str(e)
            })
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return json.dumps({
                "error": "Unexpected error",
                "details": str(e)
            })
    
    def _parse_pricing_response(self, response: Dict, resource_type: str) -> Dict:
        """Parse AWS pricing API response"""
        prices = {}
        
        try:
            if 'PriceList' in response and response['PriceList']:
                price_item = json.loads(response['PriceList'][0])
                
                # Extract price dimensions
                terms = price_item.get('terms', {})
                on_demand = terms.get('OnDemand', {})
                
                for term_key in on_demand:
                    term = on_demand[term_key]
                    for dimension_key in term.get('priceDimensions', {}):
                        dimension = term['priceDimensions'][dimension_key]
                        if 'pricePerUnit' in dimension:
                            prices['hourly_rate'] = float(dimension['pricePerUnit'].get('USD', 0))
                            prices['unit'] = dimension.get('unit', 'Hrs')
                            break
                            
        except Exception as e:
            logger.error(f"Error parsing pricing response: {e}")
            prices['hourly_rate'] = 0
            
        return prices
    
    async def _arun(self, *args, **kwargs):
        """Async version (not implemented)"""
        raise NotImplementedError("Async not implemented")