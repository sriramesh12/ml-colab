# """
# AWS Pricing Tool for Cloud Rationalization Agent
# Pydantic v2 compatible version
# """
# from langchain.tools import BaseTool
# from typing import Dict, Optional, Type, Any
# from pydantic import BaseModel, Field, ConfigDict, PrivateAttr
# import json
# import logging

# logger = logging.getLogger(__name__)

# class AWSPricingInput(BaseModel):
#     """Input schema for AWS pricing tool"""
#     resource_type: str = Field(description="Type of resource (EC2, S3, RDS, etc.)")
#     region: str = Field(description="AWS region code (us-east-1, eu-west-1, etc.)")
#     specifications: Dict = Field(description="Resource specifications")
#     quantity: int = Field(default=1, description="Number of instances")

# class AWSPricingTool(BaseTool):
#     """Tool for getting AWS pricing information"""
    
#     name: str = "aws_pricing_tool"
#     description: str = "Get real-time AWS pricing for EC2, RDS, S3, and other services."
#     args_schema: Type[BaseModel] = AWSPricingInput
    
#     # Define fields properly for Pydantic v2
#     aws_access_key: Optional[str] = Field(default=None, description="AWS Access Key ID")
#     aws_secret_key: Optional[str] = Field(default=None, description="AWS Secret Access Key")
#     region_name: str = Field(default="us-east-1", description="AWS region")
    
#     # Use PrivateAttr for non-field attributes
#     _client: Any = PrivateAttr(default=None)
    
#     # Add model_config for Pydantic v2
#     model_config = ConfigDict(arbitrary_types_allowed=True)
    
#     def __init__(self, credentials: Optional[Dict] = None, **kwargs):
#         # Extract credentials
#         aws_access_key = None
#         aws_secret_key = None
#         region = "us-east-1"
        
#         if credentials:
#             aws_access_key = credentials.get('aws_access_key_id')
#             aws_secret_key = credentials.get('aws_secret_access_key')
#             region = credentials.get('region_name', 'us-east-1')
        
#         # Call super with fields
#         super().__init__(
#             aws_access_key=aws_access_key,
#             aws_secret_key=aws_secret_key,
#             region_name=region,
#             **kwargs
#         )
        
#         # Initialize client as private attribute
#         object.__setattr__(self, '_client', self._initialize_client())
    
#     def _initialize_client(self):
#         """Initialize AWS Pricing API client"""
#         if self.aws_access_key and self.aws_secret_key:
#             try:
#                 import boto3
#                 client = boto3.client(
#                     'pricing',
#                     region_name=self.region_name,
#                     aws_access_key_id=self.aws_access_key,
#                     aws_secret_access_key=self.aws_secret_key
#                 )
#                 logger.info("AWS Pricing client initialized")
#                 return client
#             except Exception as e:
#                 logger.error(f"Failed to initialize AWS client: {e}")
#                 return None
#         else:
#             logger.info("AWS credentials not provided, using demo mode")
#             return None
    
#     def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
#         """Run the tool"""
#         try:
#             # If no client, return demo data
#             if not self._client:
#                 return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
#             # For now, return demo data (implement actual API call as needed)
#             return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
#         except Exception as e:
#             logger.error(f"Error in AWS pricing: {e}")
#             return json.dumps({
#                 "error": str(e),
#                 "provider": "AWS",
#                 "message": "Falling back to demo data"
#             })
    
#     def _get_demo_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
#         """Return demo pricing data"""
#         instance_type = specifications.get('instance_type', 't3.medium')
        
#         # Demo pricing map
#         demo_prices = {
#             't3.nano': 0.0052,
#             't3.micro': 0.0104,
#             't3.small': 0.0208,
#             't3.medium': 0.0416,
#             't3.large': 0.0832,
#             't3.xlarge': 0.1664,
#             'm5.large': 0.096,
#             'm5.xlarge': 0.192,
#             'c5.large': 0.085,
#             'c5.xlarge': 0.17,
#         }
        
#         hourly_rate = demo_prices.get(instance_type, 0.0416)
#         monthly_rate = hourly_rate * 730 * quantity
        
#         result = {
#             "provider": "AWS",
#             "service": "AmazonEC2",
#             "region": region,
#             "instance_type": instance_type,
#             "hourly_rate": round(hourly_rate, 4),
#             "monthly_rate": round(monthly_rate, 2),
#             "currency": "USD",
#             "pricing_model": "On-Demand",
#             "notes": "Demo pricing data. Set AWS credentials for real prices.",
#             "mode": "demo"
#         }
        
#         return json.dumps(result, indent=2)
    
#     async def _arun(self, *args, **kwargs):
#         """Async version not implemented"""
#         return self._run(*args, **kwargs)
"""
AWS Pricing Tool for Cloud Rationalization Agent
Fixed version - Actually calls AWS Pricing API
"""
from langchain.tools import BaseTool
from typing import Dict, Optional, Type, Any
from pydantic import BaseModel, Field, ConfigDict, PrivateAttr
import json
import logging
import boto3
from botocore.exceptions import ClientError, NoCredentialsError

logger = logging.getLogger(__name__)

class AWSPricingInput(BaseModel):
    """Input schema for AWS pricing tool"""
    resource_type: str = Field(description="Type of resource (EC2, S3, RDS, etc.)")
    region: str = Field(description="AWS region code (us-east-1, eu-west-1, etc.)")
    specifications: Dict = Field(description="Resource specifications")
    quantity: int = Field(default=1, description="Number of instances")

class AWSPricingTool(BaseTool):
    """Tool for getting AWS pricing information"""
    
    name: str = "aws_pricing_tool"
    description: str = "Get real-time AWS pricing for EC2, RDS, S3, and other services."
    args_schema: Type[BaseModel] = AWSPricingInput
    
    # Define fields properly for Pydantic v2
    aws_access_key: Optional[str] = Field(default=None, description="AWS Access Key ID")
    aws_secret_key: Optional[str] = Field(default=None, description="AWS Secret Access Key")
    region_name: str = Field(default="us-east-1", description="AWS region")
    
    # Use PrivateAttr for non-field attributes
    _client: Any = PrivateAttr(default=None)
    
    # Add model_config for Pydantic v2
    model_config = ConfigDict(arbitrary_types_allowed=True)
    
    def __init__(self, credentials: Optional[Dict] = None, **kwargs):
        # Extract credentials
        aws_access_key = None
        aws_secret_key = None
        region = "us-east-1"
        
        if credentials:
            aws_access_key = credentials.get('aws_access_key_id')
            aws_secret_key = credentials.get('aws_secret_access_key')
            region = credentials.get('region_name', 'us-east-1')
        
        # Call super with fields
        super().__init__(
            aws_access_key=aws_access_key,
            aws_secret_key=aws_secret_key,
            region_name=region,
            **kwargs
        )
        
        # Initialize client as private attribute
        object.__setattr__(self, '_client', self._initialize_client())
    
    def _initialize_client(self):
        """Initialize AWS Pricing API client"""
        if self.aws_access_key and self.aws_secret_key:
            try:
                # Create boto3 client with credentials
                session = boto3.Session(
                    aws_access_key_id=self.aws_access_key,
                    aws_secret_access_key=self.aws_secret_key,
                    region_name=self.region_name
                )
                client = session.client('pricing', region_name='us-east-1')  # Pricing API is only in us-east-1
                logger.info("✅ AWS Pricing client initialized with real credentials")
                
                # Test the client with a simple call
                try:
                    client.describe_services(ServiceCode='AmazonEC2', MaxResults=1)
                    logger.info("✅ AWS Pricing client test successful")
                except Exception as e:
                    logger.error(f"⚠️ AWS Pricing client test failed: {e}")
                
                return client
            except NoCredentialsError:
                logger.error("❌ AWS credentials not found")
                return None
            except Exception as e:
                logger.error(f"❌ Failed to initialize AWS client: {e}")
                return None
        else:
            logger.info("ℹ️ AWS credentials not provided, using demo mode")
            return None
    
    def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
        """Run the tool - makes REAL AWS API call if credentials available"""
        try:
            # If we have a client with credentials, make REAL API call
            if self._client:
                logger.info(f"🔵 Making REAL AWS API call for {specifications.get('instance_type')}")
                return self._get_real_pricing(resource_type, region, specifications, quantity)
            else:
                # No credentials, return demo data
                logger.info("ℹ️ No AWS credentials, using demo data")
                return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
        except Exception as e:
            logger.error(f"❌ Error in AWS pricing: {e}")
            return json.dumps({
                "error": str(e),
                "provider": "AWS",
                "message": "Error calling AWS API, falling back to demo data",
                "mode": "demo_fallback"
            })
    
    def _get_real_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
        """Get REAL pricing from AWS API"""
        try:
            instance_type = specifications.get('instance_type', 't3.medium')
            
            # Map region to AWS region code
            region_map = {
                'us-east-1': 'US East (N. Virginia)',
                'us-west-2': 'US West (Oregon)',
                'eu-west-1': 'EU (Ireland)',
                'ap-southeast-1': 'Asia Pacific (Singapore)'
            }
            location = region_map.get(region, region)
            
            # Query AWS Pricing API
            response = self._client.get_products(
                ServiceCode='AmazonEC2',
                Filters=[
                    {'Type': 'TERM_MATCH', 'Field': 'instanceType', 'Value': instance_type},
                    {'Type': 'TERM_MATCH', 'Field': 'location', 'Value': location},
                    {'Type': 'TERM_MATCH', 'Field': 'operatingSystem', 'Value': specifications.get('os', 'Linux')},
                    {'Type': 'TERM_MATCH', 'Field': 'tenancy', 'Value': 'Shared'},
                    {'Type': 'TERM_MATCH', 'Field': 'capacitystatus', 'Value': 'Used'},
                    {'Type': 'TERM_MATCH', 'Field': 'preInstalledSw', 'Value': 'NA'}
                ],
                MaxResults=100
            )
            
            # Parse the response to extract price
            if 'PriceList' in response and response['PriceList']:
                for price_item_str in response['PriceList']:
                    price_item = json.loads(price_item_str)
                    
                    # Extract On-Demand price
                    terms = price_item.get('terms', {})
                    on_demand = terms.get('OnDemand', {})
                    
                    for term_key in on_demand:
                        term = on_demand[term_key]
                        for dimension_key in term.get('priceDimensions', {}):
                            dimension = term['priceDimensions'][dimension_key]
                            if 'pricePerUnit' in dimension:
                                hourly_rate = float(dimension['pricePerUnit'].get('USD', 0))
                                if hourly_rate > 0:
                                    monthly_rate = hourly_rate * 730 * quantity
                                    
                                    result = {
                                        "provider": "AWS",
                                        "service": "AmazonEC2",
                                        "region": region,
                                        "instance_type": instance_type,
                                        "hourly_rate": round(hourly_rate, 4),
                                        "monthly_rate": round(monthly_rate, 2),
                                        "currency": "USD",
                                        "pricing_model": "On-Demand",
                                        "data_source": "live_aws_api",
                                        "notes": "Real-time pricing from AWS API"
                                    }
                                    
                                    logger.info(f"✅ AWS live price found: ${monthly_rate:.2f}/month")
                                    return json.dumps(result, indent=2)
            
            # If we get here, no price found
            logger.warning(f"⚠️ No AWS price found for {instance_type}, using demo fallback")
            return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
        except ClientError as e:
            logger.error(f"❌ AWS API ClientError: {e}")
            if "AccessDenied" in str(e):
                logger.error("❌ AWS access denied - check your credentials and permissions")
                return json.dumps({
                    "error": "AWS access denied",
                    "provider": "AWS",
                    "message": "Check AWS credentials and permissions",
                    "mode": "error"
                })
            raise
        except Exception as e:
            logger.error(f"❌ Error in AWS real pricing: {e}")
            raise
    
    def _get_demo_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
        """Return demo pricing data"""
        instance_type = specifications.get('instance_type', 't3.medium')
        
        # Demo pricing map
        demo_prices = {
            't3.nano': 0.0052,
            't3.micro': 0.0104,
            't3.small': 0.0208,
            't3.medium': 0.0416,
            't3.large': 0.0832,
            't3.xlarge': 0.1664,
            'm5.large': 0.096,
            'm5.xlarge': 0.192,
            'c5.large': 0.085,
            'c5.xlarge': 0.17,
        }
        
        hourly_rate = demo_prices.get(instance_type, 0.0416)
        monthly_rate = hourly_rate * 730 * quantity
        
        result = {
            "provider": "AWS",
            "service": "AmazonEC2",
            "region": region,
            "instance_type": instance_type,
            "hourly_rate": round(hourly_rate, 4),
            "monthly_rate": round(monthly_rate, 2),
            "currency": "USD",
            "pricing_model": "On-Demand",
            "notes": "DEMO pricing data - Set AWS credentials for real prices",
            "mode": "demo"
        }
        
        logger.info(f"ℹ️ AWS demo price: ${monthly_rate:.2f}/month")
        return json.dumps(result, indent=2)
    
    async def _arun(self, *args, **kwargs):
        """Async version not implemented"""
        return self._run(*args, **kwargs)
