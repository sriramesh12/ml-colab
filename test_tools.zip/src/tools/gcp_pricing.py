# # """
# # GCP Pricing Tool for Cloud Rationalization Agent
# # Pydantic v2 compatible version
# # """
# # from langchain.tools import BaseTool
# # from typing import Dict, Optional, Type
# # from pydantic import BaseModel, Field, ConfigDict
# # import json
# # import logging

# # logger = logging.getLogger(__name__)

# # class GCPPricingInput(BaseModel):
# #     """Input schema for GCP pricing tool"""
# #     resource_type: str = Field(description="Type of resource (compute, sql, storage, etc.)")
# #     region: str = Field(description="GCP region (us-central1, europe-west1, etc.)")
# #     specifications: Dict = Field(description="Resource specifications")
# #     quantity: int = Field(default=1, description="Number of instances")

# # class GCPPricingTool(BaseTool):
# #     """Tool for getting GCP pricing information"""
    
# #     name: str = "gcp_pricing_tool"
# #     description: str = "Get real-time GCP pricing for Compute Engine, Cloud SQL, and other services."
# #     args_schema: Type[BaseModel] = GCPPricingInput
    
# #     # Define fields properly
# #     project_id: Optional[str] = Field(default=None, description="GCP Project ID")
# #     credentials_path: Optional[str] = Field(default=None, description="Path to GCP credentials file")
    
# #     model_config = ConfigDict(arbitrary_types_allowed=True)
    
# #     def __init__(self, credentials: Optional[Dict] = None, **kwargs):
# #         project_id = None
# #         credentials_path = None
        
# #         if credentials:
# #             project_id = credentials.get('project_id')
# #             credentials_path = credentials.get('credentials_path')
        
# #         super().__init__(
# #             project_id=project_id,
# #             credentials_path=credentials_path,
# #             **kwargs
# #         )
    
# #     def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
# #         """Run the tool"""
# #         try:
# #             # If no credentials, return demo data
# #             if not self.credentials_path:
# #                 return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
# #             # For now, return demo data
# #             return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
# #         except Exception as e:
# #             logger.error(f"Error in GCP pricing: {e}")
# #             return json.dumps({
# #                 "error": str(e),
# #                 "provider": "GCP",
# #                 "message": "Falling back to demo data"
# #             })
    
# #     def _get_demo_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
# #         """Return demo pricing data"""
# #         instance_type = specifications.get('instance_type', 'n1-standard-1')
        
# #         # Demo pricing map
# #         demo_prices = {
# #             'n1-standard-1': 0.0475,
# #             'n1-standard-2': 0.0950,
# #             'n1-standard-4': 0.1900,
# #             'n1-standard-8': 0.3800,
# #             'n2-standard-2': 0.0971,
# #             'n2-standard-4': 0.1942,
# #             'n2-standard-8': 0.3884,
# #             'e2-standard-2': 0.0670,
# #             'e2-standard-4': 0.1340,
# #         }
        
# #         hourly_rate = demo_prices.get(instance_type, 0.0475)
# #         monthly_rate = hourly_rate * 730 * quantity
        
# #         result = {
# #             "provider": "GCP",
# #             "service": "Compute Engine",
# #             "region": region,
# #             "instance_type": instance_type,
# #             "hourly_rate": round(hourly_rate, 4),
# #             "monthly_rate": round(monthly_rate, 2),
# #             "currency": "USD",
# #             "pricing_model": "On-Demand",
# #             "notes": "Demo pricing data. Set GCP credentials for real prices.",
# #             "mode": "demo"
# #         }
        
# #         return json.dumps(result, indent=2)
    
# #     async def _arun(self, *args, **kwargs):
# #         """Async version not implemented"""
# #         return self._run(*args, **kwargs)

# """
# GCP Pricing Tool for Cloud Rationalization Agent
# Fixed version - Actually calls GCP Cloud Billing API
# """
# from langchain.tools import BaseTool
# from typing import Dict, Optional, Type, Any
# from pydantic import BaseModel, Field, ConfigDict, PrivateAttr
# import json
# import logging
# import os

# logger = logging.getLogger(__name__)

# class GCPPricingInput(BaseModel):
#     """Input schema for GCP pricing tool"""
#     resource_type: str = Field(description="Type of resource (compute, sql, storage, etc.)")
#     region: str = Field(description="GCP region (us-central1, europe-west1, etc.)")
#     specifications: Dict = Field(description="Resource specifications")
#     quantity: int = Field(default=1, description="Number of instances")

# class GCPPricingTool(BaseTool):
#     """Tool for getting GCP pricing information"""
    
#     name: str = "gcp_pricing_tool"
#     description: str = "Get real-time GCP pricing for Compute Engine, Cloud SQL, and other services."
#     args_schema: Type[BaseModel] = GCPPricingInput
    
#     # Define fields properly
#     project_id: Optional[str] = Field(default=None, description="GCP Project ID")
#     credentials_path: Optional[str] = Field(default=None, description="Path to GCP credentials file")
    
#     # Private attribute for GCP client
#     _client: Any = PrivateAttr(default=None)
#     _service: Any = PrivateAttr(default=None)
    
#     model_config = ConfigDict(arbitrary_types_allowed=True)
    
#     def __init__(self, credentials: Optional[Dict] = None, **kwargs):
#         project_id = None
#         credentials_path = None
        
#         if credentials:
#             project_id = credentials.get('project_id')
#             credentials_path = credentials.get('credentials_path')
        
#         super().__init__(
#             project_id=project_id,
#             credentials_path=credentials_path,
#             **kwargs
#         )
        
#         # Initialize GCP client
#         object.__setattr__(self, '_client', self._initialize_client())
    
#     def _initialize_client(self):
#         """Initialize GCP Cloud Billing client"""
#         if self.credentials_path and os.path.exists(self.credentials_path):
#             try:
#                 from google.cloud import billing_v1
#                 from google.oauth2 import service_account
                
#                 # Load credentials from file
#                 credentials = service_account.Credentials.from_service_account_file(
#                     self.credentials_path,
#                     scopes=['https://www.googleapis.com/auth/cloud-platform']
#                 )
                
#                 # Create billing client
#                 client = billing_v1.CloudCatalogClient(credentials=credentials)
                
#                 logger.info("✅ GCP client initialized with real credentials")
                
#                 # Test the connection
#                 try:
#                     # List some services to test
#                     services = client.list_services()
#                     service_count = 0
#                     for _ in services:
#                         service_count += 1
#                         if service_count > 5:  # Just get a few
#                             break
#                     logger.info(f"✅ GCP connection test successful - found services")
#                 except Exception as e:
#                     logger.error(f"⚠️ GCP connection test failed: {e}")
                
#                 return client
                
#             except ImportError:
#                 logger.error("❌ google-cloud-billing not installed. Run: pip install google-cloud-billing")
#                 return None
#             except Exception as e:
#                 logger.error(f"❌ Failed to initialize GCP client: {e}")
#                 return None
#         else:
#             if self.credentials_path:
#                 logger.warning(f"⚠️ GCP credentials path not found: {self.credentials_path}")
#             else:
#                 logger.info("ℹ️ No GCP credentials provided, using demo mode")
#             return None
    
#     def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
#         """Run the tool - makes REAL GCP API call if credentials available"""
#         try:
#             # If we have a client with credentials, make REAL API call
#             if self._client:
#                 logger.info(f"🟢 Making REAL GCP API call for {specifications.get('instance_type')}")
#                 return self._get_real_pricing(resource_type, region, specifications, quantity)
#             else:
#                 # No credentials, return demo data
#                 logger.info("ℹ️ No GCP credentials, using demo data")
#                 return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
#         except Exception as e:
#             logger.error(f"Error in GCP pricing: {e}")
#             return json.dumps({
#                 "error": str(e),
#                 "provider": "GCP",
#                 "message": "Falling back to demo data",
#                 "mode": "demo_fallback"
#             })
    
#     def _get_real_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
#         """Get REAL pricing from GCP Cloud Billing API"""
#         try:
#             from google.cloud import billing_v1
#             from google.api_core import exceptions
            
#             instance_type = specifications.get('instance_type', 'n1-standard-1')
            
#             # Map GCP machine types to their specifications
#             machine_families = {
#                 'n1-standard': 'N1 Standard',
#                 'n2-standard': 'N2 Standard',
#                 'e2-standard': 'E2 Standard',
#                 'c2-standard': 'C2 Standard',
#                 'n2-highmem': 'N2 High Memory',
#                 'n2-highcpu': 'N2 High CPU'
#             }
            
#             # Extract family from instance type
#             family = None
#             for key in machine_families:
#                 if key in instance_type:
#                     family = key
#                     break
            
#             if not family:
#                 family = 'n1-standard'
            
#             # Get the service name for compute
#             service_name = f"services/6F81-5844-456A"  # Compute Engine service ID
            
#             # List SKUs for compute
#             request = billing_v1.ListSkusRequest(
#                 parent=service_name,
#             )
            
#             skus = self._client.list_skus(request=request)
            
#             # Find matching SKU
#             matching_skus = []
#             for sku in skus:
#                 sku_info = {
#                     'name': sku.name,
#                     'description': sku.description,
#                     'category': sku.category,
#                     'pricing_info': sku.pricing_info
#                 }
                
#                 # Check if this SKU matches our instance type and region
#                 if instance_type in sku.description.lower():
#                     # Check region
#                     if region in sku.service_regions:
#                         # Check if it's a compute SKU
#                         if 'compute' in sku.category.resource_family.lower():
#                             matching_skus.append(sku)
            
#             if matching_skus:
#                 # Use the first matching SKU
#                 sku = matching_skus[0]
                
#                 # Extract pricing
#                 for pricing_info in sku.pricing_info:
#                     for tiered_rate in pricing_info.pricing_expression.tiered_rates:
#                         if tiered_rate.unit_price:
#                             # Price is in nanos (billionths of a dollar)
#                             nanos = tiered_rate.unit_price.nanos
#                             units = tiered_rate.unit_price.units
                            
#                             # Convert to dollars
#                             hourly_rate = units + (nanos / 1_000_000_000)
                            
#                             # Get usage unit
#                             usage_unit = pricing_info.pricing_expression.usage_unit
                            
#                             # Calculate monthly based on usage unit
#                             if usage_unit == 'h':
#                                 monthly_rate = hourly_rate * 730 * quantity
#                             elif usage_unit == 'mo':
#                                 monthly_rate = hourly_rate * quantity
#                             else:
#                                 monthly_rate = hourly_rate * 730 * quantity
                            
#                             # Get commitment discounts if applicable
#                             commitment_1yr = hourly_rate * 0.7  # 30% discount
#                             commitment_3yr = hourly_rate * 0.5  # 50% discount
                            
#                             result = {
#                                 "provider": "GCP",
#                                 "service": "Compute Engine",
#                                 "region": region,
#                                 "instance_type": instance_type,
#                                 "hourly_rate": round(hourly_rate, 4),
#                                 "monthly_rate": round(monthly_rate, 2),
#                                 "annual_rate": round(monthly_rate * 12, 2),
#                                 "currency": "USD",
#                                 "pricing_model": "On-Demand",
#                                 "data_source": "live_gcp_api",
#                                 "savings_options": {
#                                     "committed_use_1yr": round(commitment_1yr, 4),
#                                     "committed_use_3yr": round(commitment_3yr, 4),
#                                     "preemptible": round(hourly_rate * 0.2, 4)  # 80% discount for preemptible
#                                 },
#                                 "notes": "Real-time pricing from GCP Cloud Billing API",
#                                 "sku_name": sku.name,
#                                 "sku_description": sku.description
#                             }
                            
#                             logger.info(f"✅ GCP live price found: ${monthly_rate:.2f}/month")
#                             return json.dumps(result, indent=2)
            
#             # If no match found, try alternate approach with filters
#             logger.warning(f"⚠️ No exact GCP price match found for {instance_type}, trying alternate method")
            
#             # Create filter for SKU search
#             # This is a simplified approach - in production you'd want more sophisticated matching
#             filter_str = f'serviceRegion="{region}" AND resourceGroup="CPU"'
            
#             try:
#                 # Use billing API to get SKUs with filter
#                 # Note: This is a simplified example - actual implementation may vary
#                 from google.cloud.billing_v1.types import ListSkusRequest
                
#                 request = ListSkusRequest(
#                     parent=service_name,
#                 )
                
#                 skus = self._client.list_skus(request=request)
                
#                 # Filter manually
#                 for sku in skus:
#                     if region in sku.service_regions:
#                         if instance_type.split('-')[0] in sku.description.lower():
#                             # Found potential match
#                             for pricing_info in sku.pricing_info:
#                                 for tiered_rate in pricing_info.pricing_expression.tiered_rates:
#                                     if tiered_rate.unit_price:
#                                         nanos = tiered_rate.unit_price.nanos
#                                         units = tiered_rate.unit_price.units
#                                         hourly_rate = units + (nanos / 1_000_000_000)
#                                         monthly_rate = hourly_rate * 730 * quantity
                                        
#                                         result = {
#                                             "provider": "GCP",
#                                             "service": "Compute Engine",
#                                             "region": region,
#                                             "instance_type": instance_type,
#                                             "hourly_rate": round(hourly_rate, 4),
#                                             "monthly_rate": round(monthly_rate, 2),
#                                             "currency": "USD",
#                                             "pricing_model": "On-Demand",
#                                             "data_source": "live_gcp_api_approx",
#                                             "notes": "Approximate pricing from GCP API"
#                                         }
                                        
#                                         logger.info(f"✅ GCP approx price found: ${monthly_rate:.2f}/month")
#                                         return json.dumps(result, indent=2)
#             except Exception as e:
#                 logger.error(f"Error in alternate GCP pricing: {e}")
            
#             # Fallback to demo
#             logger.warning("⚠️ No GCP price found, using demo data")
#             return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
#         except ImportError as e:
#             logger.error(f"❌ GCP import error: {e}")
#             logger.error("Run: pip install google-cloud-billing google-auth")
#             return self._get_demo_pricing(resource_type, region, specifications, quantity)
#         except exceptions.PermissionDenied:
#             logger.error("❌ GCP permission denied - check your service account permissions")
#             return json.dumps({
#                 "error": "GCP permission denied",
#                 "provider": "GCP",
#                 "message": "Check service account permissions",
#                 "mode": "error"
#             })
#         except Exception as e:
#             logger.error(f"❌ Error in GCP real pricing: {e}")
#             return self._get_demo_pricing(resource_type, region, specifications, quantity)
    
#     def _get_demo_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
#         """Return demo pricing data"""
#         instance_type = specifications.get('instance_type', 'n1-standard-1')
        
#         # Demo pricing map for GCP
#         demo_prices = {
#             # General purpose N1
#             'n1-standard-1': 0.0475,
#             'n1-standard-2': 0.0950,
#             'n1-standard-4': 0.1900,
#             'n1-standard-8': 0.3800,
#             'n1-standard-16': 0.7600,
#             'n1-standard-32': 1.5200,
            
#             # General purpose N2
#             'n2-standard-2': 0.0971,
#             'n2-standard-4': 0.1942,
#             'n2-standard-8': 0.3884,
#             'n2-standard-16': 0.7768,
#             'n2-standard-32': 1.5536,
            
#             # General purpose E2
#             'e2-standard-2': 0.0670,
#             'e2-standard-4': 0.1340,
#             'e2-standard-8': 0.2680,
#             'e2-standard-16': 0.5360,
            
#             # Compute optimized
#             'c2-standard-4': 0.1488,
#             'c2-standard-8': 0.2976,
#             'c2-standard-16': 0.5952,
#             'c2-standard-30': 1.1160,
            
#             # Memory optimized
#             'n1-highmem-2': 0.1184,
#             'n1-highmem-4': 0.2368,
#             'n1-highmem-8': 0.4736,
#             'n1-highmem-16': 0.9472,
            
#             # Preemptible (spot) pricing
#             'n1-standard-1-preemptible': 0.0067,
#             'n1-standard-2-preemptible': 0.0134,
#             'n1-standard-4-preemptible': 0.0268,
#         }
        
#         # Check if preemptible requested
#         is_preemptible = specifications.get('preemptible', False) or 'preemptible' in instance_type
        
#         # Get base price
#         base_price = demo_prices.get(instance_type, 0.0475)
        
#         # Apply preemptible discount if applicable
#         if is_preemptible and 'preemptible' not in instance_type:
#             hourly_rate = base_price * 0.2  # 80% discount for preemptible
#         else:
#             hourly_rate = base_price
        
#         monthly_rate = hourly_rate * 730 * quantity
        
#         # Add commitment discounts info
#         commitment_1yr = hourly_rate * 0.7  # 30% discount
#         commitment_3yr = hourly_rate * 0.5  # 50% discount
        
#         result = {
#             "provider": "GCP",
#             "service": "Compute Engine",
#             "region": region,
#             "instance_type": instance_type,
#             "hourly_rate": round(hourly_rate, 4),
#             "monthly_rate": round(monthly_rate, 2),
#             "annual_rate": round(monthly_rate * 12, 2),
#             "currency": "USD",
#             "pricing_model": "Preemptible" if is_preemptible else "On-Demand",
#             "savings_options": {
#                 "committed_use_1yr": round(commitment_1yr, 4),
#                 "committed_use_3yr": round(commitment_3yr, 4),
#                 "preemptible": round(hourly_rate * 0.2, 4) if not is_preemptible else None
#             },
#             "notes": "DEMO pricing data - Set GCP credentials for real prices",
#             "mode": "demo"
#         }
        
#         logger.info(f"ℹ️ GCP demo price: ${monthly_rate:.2f}/month")
#         return json.dumps(result, indent=2)
    
#     def _get_committed_use_discount(self, instance_type: str, region: str, duration: str = "1yr") -> Dict:
#         """
#         Get committed use discount pricing (can be used with real or demo data)
#         """
#         base_prices = {
#             'n1-standard-1': 0.0475,
#             'n1-standard-2': 0.0950,
#             'n1-standard-4': 0.1900,
#         }
        
#         base = base_prices.get(instance_type, 0.0475)
        
#         if duration == "1yr":
#             discounted = base * 0.7  # 30% off
#         else:  # 3yr
#             discounted = base * 0.5  # 50% off
        
#         return {
#             "instance_type": instance_type,
#             "region": region,
#             "duration": duration,
#             "original_hourly": base,
#             "discounted_hourly": round(discounted, 4),
#             "savings_percentage": 30 if duration == "1yr" else 50,
#             "monthly_savings": round((base - discounted) * 730, 2)
#         }
    
#     def _get_sustained_use_discount(self, usage_hours: int = 730) -> Dict:
#         """
#         Calculate sustained use discounts (automatic for running full month)
#         """
#         if usage_hours >= 730:  # Full month
#             discount = 0.3  # 30% for full month usage
#         elif usage_hours >= 365:  # Half month
#             discount = 0.2  # 20% for half month
#         else:
#             discount = 0
        
#         return {
#             "usage_hours": usage_hours,
#             "discount_percentage": discount * 100,
#             "qualifies_for_sustained_use": discount > 0
#         }
    
#     async def _arun(self, *args, **kwargs):
#         """Async version not implemented"""
#         return self._run(*args, **kwargs)
"""
GCP Pricing Tool for Cloud Rationalization Agent
Enhanced version with automatic AWS to GCP instance mapping
"""
from langchain.tools import BaseTool
from typing import Dict, Optional, Type, Any
from pydantic import BaseModel, Field, ConfigDict, PrivateAttr
import json
import logging
import os

logger = logging.getLogger(__name__)

class GCPPricingInput(BaseModel):
    """Input schema for GCP pricing tool"""
    resource_type: str = Field(description="Type of resource (compute, sql, storage, etc.)")
    region: str = Field(description="GCP region (us-central1, europe-west1, etc.)")
    specifications: Dict = Field(description="Resource specifications")
    quantity: int = Field(default=1, description="Number of instances")

class GCPPricingTool(BaseTool):
    """Tool for getting GCP pricing information with automatic AWS to GCP mapping"""
    
    name: str = "gcp_pricing_tool"
    description: str = """
    Get real-time GCP pricing for Compute Engine.
    Automatically maps AWS instance types to equivalent GCP instances.
    Supports: t3.micro -> e2-micro, t3.medium -> e2-medium, m5.large -> n2-standard-2, etc.
    """
    args_schema: Type[BaseModel] = GCPPricingInput
    
    # Define fields properly
    project_id: Optional[str] = Field(default=None, description="GCP Project ID")
    credentials_path: Optional[str] = Field(default=None, description="Path to GCP credentials file")
    
    # Private attribute for GCP client
    _client: Any = PrivateAttr(default=None)
    
    model_config = ConfigDict(arbitrary_types_allowed=True)
    
    # ===== AWS TO GCP INSTANCE MAPPING =====
    # Based on vCPU, memory, and use case
    AWS_TO_GCP_MAP = {
        # General purpose - AWS T3 series (burstable) -> GCP E2 series (also burstable)
        "t3.nano": {"family": "E2", "size": "e2-micro", "vcpu": "2 (burstable)", "memory": 0.5, "equivalent": "e2-micro"},
        "t3.micro": {"family": "E2", "size": "e2-micro", "vcpu": "2 (burstable)", "memory": 1, "equivalent": "e2-micro"},
        "t3.small": {"family": "E2", "size": "e2-small", "vcpu": "2 (burstable)", "memory": 2, "equivalent": "e2-small"},
        "t3.medium": {"family": "E2", "size": "e2-medium", "vcpu": "2 (burstable)", "memory": 4, "equivalent": "e2-medium"},
        "t3.large": {"family": "E2", "size": "e2-standard-2", "vcpu": 2, "memory": 8, "equivalent": "e2-standard-2"},
        "t3.xlarge": {"family": "E2", "size": "e2-standard-4", "vcpu": 4, "memory": 16, "equivalent": "e2-standard-4"},
        "t3.2xlarge": {"family": "E2", "size": "e2-standard-8", "vcpu": 8, "memory": 32, "equivalent": "e2-standard-8"},
        
        # General purpose - AWS M5 series (balanced) -> GCP N2 series
        "m5.large": {"family": "N2", "size": "n2-standard-2", "vcpu": 2, "memory": 8, "equivalent": "n2-standard-2"},
        "m5.xlarge": {"family": "N2", "size": "n2-standard-4", "vcpu": 4, "memory": 16, "equivalent": "n2-standard-4"},
        "m5.2xlarge": {"family": "N2", "size": "n2-standard-8", "vcpu": 8, "memory": 32, "equivalent": "n2-standard-8"},
        "m5.4xlarge": {"family": "N2", "size": "n2-standard-16", "vcpu": 16, "memory": 64, "equivalent": "n2-standard-16"},
        "m5.8xlarge": {"family": "N2", "size": "n2-standard-32", "vcpu": 32, "memory": 128, "equivalent": "n2-standard-32"},
        "m5.12xlarge": {"family": "N2", "size": "n2-standard-48", "vcpu": 48, "memory": 192, "equivalent": "n2-standard-48"},
        "m5.16xlarge": {"family": "N2", "size": "n2-standard-64", "vcpu": 64, "memory": 256, "equivalent": "n2-standard-64"},
        "m5.24xlarge": {"family": "N2", "size": "n2-standard-80", "vcpu": 80, "memory": 320, "equivalent": "n2-standard-80"},
        
        # Compute optimized - AWS C5 series -> GCP C2 series
        "c5.large": {"family": "C2", "size": "c2-standard-4", "vcpu": 4, "memory": 8, "equivalent": "c2-standard-4"},
        "c5.xlarge": {"family": "C2", "size": "c2-standard-8", "vcpu": 8, "memory": 16, "equivalent": "c2-standard-8"},
        "c5.2xlarge": {"family": "C2", "size": "c2-standard-16", "vcpu": 16, "memory": 32, "equivalent": "c2-standard-16"},
        "c5.4xlarge": {"family": "C2", "size": "c2-standard-30", "vcpu": 30, "memory": 60, "equivalent": "c2-standard-30"},
        "c5.9xlarge": {"family": "C2", "size": "c2-standard-60", "vcpu": 60, "memory": 120, "equivalent": "c2-standard-60"},
        "c5.12xlarge": {"family": "C2", "size": "c2-standard-60", "vcpu": 60, "memory": 120, "equivalent": "c2-standard-60"},
        "c5.18xlarge": {"family": "C2", "size": "c2-standard-60", "vcpu": 60, "memory": 120, "equivalent": "c2-standard-60"},
        
        # Memory optimized - AWS R5 series -> GCP N2 high-memory
        "r5.large": {"family": "N2", "size": "n2-highmem-2", "vcpu": 2, "memory": 16, "equivalent": "n2-highmem-2"},
        "r5.xlarge": {"family": "N2", "size": "n2-highmem-4", "vcpu": 4, "memory": 32, "equivalent": "n2-highmem-4"},
        "r5.2xlarge": {"family": "N2", "size": "n2-highmem-8", "vcpu": 8, "memory": 64, "equivalent": "n2-highmem-8"},
        "r5.4xlarge": {"family": "N2", "size": "n2-highmem-16", "vcpu": 16, "memory": 128, "equivalent": "n2-highmem-16"},
        "r5.8xlarge": {"family": "N2", "size": "n2-highmem-32", "vcpu": 32, "memory": 256, "equivalent": "n2-highmem-32"},
        "r5.12xlarge": {"family": "N2", "size": "n2-highmem-48", "vcpu": 48, "memory": 384, "equivalent": "n2-highmem-48"},
        "r5.16xlarge": {"family": "N2", "size": "n2-highmem-64", "vcpu": 64, "memory": 512, "equivalent": "n2-highmem-64"},
        "r5.24xlarge": {"family": "N2", "size": "n2-highmem-80", "vcpu": 80, "memory": 640, "equivalent": "n2-highmem-80"},
        
        # Memory optimized with higher memory ratios - AWS R5a series -> GCP N2D high-memory
        "r5a.large": {"family": "N2D", "size": "n2d-highmem-2", "vcpu": 2, "memory": 16, "equivalent": "n2d-highmem-2"},
        "r5a.xlarge": {"family": "N2D", "size": "n2d-highmem-4", "vcpu": 4, "memory": 32, "equivalent": "n2d-highmem-4"},
        "r5a.2xlarge": {"family": "N2D", "size": "n2d-highmem-8", "vcpu": 8, "memory": 64, "equivalent": "n2d-highmem-8"},
        "r5a.4xlarge": {"family": "N2D", "size": "n2d-highmem-16", "vcpu": 16, "memory": 128, "equivalent": "n2d-highmem-16"},
        "r5a.8xlarge": {"family": "N2D", "size": "n2d-highmem-32", "vcpu": 32, "memory": 256, "equivalent": "n2d-highmem-32"},
        "r5a.12xlarge": {"family": "N2D", "size": "n2d-highmem-48", "vcpu": 48, "memory": 384, "equivalent": "n2d-highmem-48"},
        "r5a.16xlarge": {"family": "N2D", "size": "n2d-highmem-64", "vcpu": 64, "memory": 512, "equivalent": "n2d-highmem-64"},
        "r5a.24xlarge": {"family": "N2D", "size": "n2d-highmem-80", "vcpu": 80, "memory": 640, "equivalent": "n2d-highmem-80"},
        
        # GPU instances - AWS G4 series -> GCP with NVIDIA T4
        "g4dn.xlarge": {"family": "GPU", "size": "n1-standard-4-with-t4", "vcpu": 4, "memory": 16, "gpu": "T4", "equivalent": "n1-standard-4 + T4"},
        "g4dn.2xlarge": {"family": "GPU", "size": "n1-standard-8-with-t4", "vcpu": 8, "memory": 32, "gpu": "T4", "equivalent": "n1-standard-8 + T4"},
        "g4dn.4xlarge": {"family": "GPU", "size": "n1-standard-16-with-t4", "vcpu": 16, "memory": 64, "gpu": "T4", "equivalent": "n1-standard-16 + T4"},
        "g4dn.8xlarge": {"family": "GPU", "size": "n1-standard-32-with-t4", "vcpu": 32, "memory": 128, "gpu": "T4", "equivalent": "n1-standard-32 + T4"},
        "g4dn.12xlarge": {"family": "GPU", "size": "n1-standard-48-with-t4", "vcpu": 48, "memory": 192, "gpu": "T4", "equivalent": "n1-standard-48 + T4"},
        "g4dn.16xlarge": {"family": "GPU", "size": "n1-standard-64-with-t4", "vcpu": 64, "memory": 256, "gpu": "T4", "equivalent": "n1-standard-64 + T4"},
        
        # High CPU - AWS C5n series -> GCP C2 high-cpu
        "c5n.large": {"family": "C2", "size": "c2-standard-4", "vcpu": 4, "memory": 5.25, "equivalent": "c2-standard-4"},
        "c5n.xlarge": {"family": "C2", "size": "c2-standard-8", "vcpu": 8, "memory": 10.5, "equivalent": "c2-standard-8"},
        "c5n.2xlarge": {"family": "C2", "size": "c2-standard-16", "vcpu": 16, "memory": 21, "equivalent": "c2-standard-16"},
        "c5n.4xlarge": {"family": "C2", "size": "c2-standard-30", "vcpu": 30, "memory": 40, "equivalent": "c2-standard-30"},
        "c5n.9xlarge": {"family": "C2", "size": "c2-standard-60", "vcpu": 60, "memory": 80, "equivalent": "c2-standard-60"},
        "c5n.18xlarge": {"family": "C2", "size": "c2-standard-60", "vcpu": 60, "memory": 80, "equivalent": "c2-standard-60"},
        
        # Storage optimized - AWS I3 series -> GCP with local SSD
        "i3.large": {"family": "N2", "size": "n2-standard-2-with-local-ssd", "vcpu": 2, "memory": 8, "storage": "1x475GB NVMe", "equivalent": "n2-standard-2 + local SSD"},
        "i3.xlarge": {"family": "N2", "size": "n2-standard-4-with-local-ssd", "vcpu": 4, "memory": 16, "storage": "1x950GB NVMe", "equivalent": "n2-standard-4 + local SSD"},
        "i3.2xlarge": {"family": "N2", "size": "n2-standard-8-with-local-ssd", "vcpu": 8, "memory": 32, "storage": "1x1.9TB NVMe", "equivalent": "n2-standard-8 + local SSD"},
        "i3.4xlarge": {"family": "N2", "size": "n2-standard-16-with-local-ssd", "vcpu": 16, "memory": 64, "storage": "2x1.9TB NVMe", "equivalent": "n2-standard-16 + local SSD"},
        "i3.8xlarge": {"family": "N2", "size": "n2-standard-32-with-local-ssd", "vcpu": 32, "memory": 128, "storage": "4x1.9TB NVMe", "equivalent": "n2-standard-32 + local SSD"},
        "i3.16xlarge": {"family": "N2", "size": "n2-standard-64-with-local-ssd", "vcpu": 64, "memory": 256, "storage": "8x1.9TB NVMe", "equivalent": "n2-standard-64 + local SSD"},
    }
    
    # ===== REGION MAPPING =====
    AWS_TO_GCP_REGION_MAP = {
        "us-east-1": "us-east1",          # US East (South Carolina)
        "us-east-2": "us-east4",           # US East (Ohio) -> GCP US East (North Virginia)
        "us-west-1": "us-west2",           # US West (N. California) -> GCP US West (Los Angeles)
        "us-west-2": "us-west1",           # US West (Oregon) -> GCP US West (Oregon)
        "eu-west-1": "europe-west1",       # EU (Ireland) -> GCP Europe West (Belgium)
        "eu-west-2": "europe-west2",       # EU (London) -> GCP Europe West (London)
        "eu-central-1": "europe-west3",    # EU (Frankfurt) -> GCP Europe West (Frankfurt)
        "ap-southeast-1": "asia-southeast1", # Singapore -> GCP Asia Southeast (Singapore)
        "ap-southeast-2": "australia-southeast1", # Sydney -> GCP Australia (Sydney)
        "ap-northeast-1": "asia-northeast1", # Tokyo -> GCP Asia Northeast (Tokyo)
        "ap-northeast-2": "asia-northeast2", # Seoul -> GCP Asia Northeast (Osaka)
        "ap-south-1": "asia-south1",       # Mumbai -> GCP Asia South (Mumbai)
        "sa-east-1": "southamerica-east1", # Sao Paulo -> GCP South America (Sao Paulo)
        "ca-central-1": "northamerica-northeast1", # Canada -> GCP North America (Montreal)
    }
    
    GCP_TO_AWS_REGION_MAP = {v: k for k, v in AWS_TO_GCP_REGION_MAP.items()}
    
    def __init__(self, credentials: Optional[Dict] = None, **kwargs):
        project_id = None
        credentials_path = None
        
        if credentials:
            project_id = credentials.get('project_id')
            credentials_path = credentials.get('credentials_path')
        
        super().__init__(
            project_id=project_id,
            credentials_path=credentials_path,
            **kwargs
        )
        
        # Initialize GCP client
        object.__setattr__(self, '_client', self._initialize_client())
    
    def _initialize_client(self):
        """Initialize GCP Cloud Billing client"""
        if self.credentials_path and os.path.exists(self.credentials_path):
            try:
                from google.cloud import billing_v1
                from google.oauth2 import service_account
                
                credentials = service_account.Credentials.from_service_account_file(
                    self.credentials_path,
                    scopes=['https://www.googleapis.com/auth/cloud-platform']
                )
                
                client = billing_v1.CloudCatalogClient(credentials=credentials)
                logger.info("✅ GCP client initialized with real credentials")
                return client
            except Exception as e:
                logger.error(f"❌ Failed to initialize GCP client: {e}")
                return None
        else:
            if self.credentials_path:
                logger.warning(f"⚠️ GCP credentials path not found: {self.credentials_path}")
            else:
                logger.info("ℹ️ No GCP credentials, using demo mode")
            return None
    
    def _map_aws_instance_to_gcp(self, aws_instance: str) -> Dict:
        """
        Map AWS instance type to equivalent GCP instance
        Returns dict with mapping info
        """
        if aws_instance in self.AWS_TO_GCP_MAP:
            mapping = self.AWS_TO_GCP_MAP[aws_instance]
            logger.info(f"🔄 Mapped AWS {aws_instance} -> GCP {mapping['equivalent']} ({mapping['family']} family)")
            return mapping
        else:
            # Try to find by family match
            family = aws_instance.split('.')[0]
            for key, value in self.AWS_TO_GCP_MAP.items():
                if key.split('.')[0] == family:
                    logger.info(f"🔄 Family match: AWS {aws_instance} -> GCP {value['equivalent']} (based on {key})")
                    return value
            
            # Check for partial matches
            for key, value in self.AWS_TO_GCP_MAP.items():
                if key.split('.')[0] in aws_instance:
                    logger.info(f"🔄 Partial match: AWS {aws_instance} -> GCP {value['equivalent']} (based on {key})")
                    return value
            
            # Default fallback based on size
            if 'large' in aws_instance:
                default = {"family": "N2", "size": "n2-standard-4", "equivalent": "n2-standard-4"}
            elif 'xlarge' in aws_instance:
                default = {"family": "N2", "size": "n2-standard-8", "equivalent": "n2-standard-8"}
            else:
                default = {"family": "E2", "size": "e2-medium", "equivalent": "e2-medium"}
            
            logger.warning(f"⚠️ No mapping found for {aws_instance}, using default {default['equivalent']}")
            return default
    
    def _map_aws_region_to_gcp(self, aws_region: str) -> str:
        """Map AWS region to equivalent GCP region"""
        if aws_region in self.AWS_TO_GCP_REGION_MAP:
            gcp_region = self.AWS_TO_GCP_REGION_MAP[aws_region]
            logger.info(f"🔄 Mapped AWS region {aws_region} -> GCP {gcp_region}")
            return gcp_region
        else:
            # If no mapping, return as-is
            logger.info(f"Using region {aws_region} as-is")
            return aws_region
    
    def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
        """Run the tool with automatic instance mapping"""
        try:
            # Check if the instance type looks like AWS (contains dot)
            instance_input = specifications.get('instance_type', 'n1-standard-1')
            
            # Auto-detect and map if it's an AWS instance
            if '.' in instance_input and not any(x in instance_input for x in ['n1-', 'n2-', 'e2-', 'c2-']):
                logger.info(f"🔍 Detected AWS instance type: {instance_input}")
                mapping = self._map_aws_instance_to_gcp(instance_input)
                gcp_instance = mapping['equivalent']
                
                # Also map region if it looks like AWS region
                if '.' in region or '-' in region:
                    gcp_region = self._map_aws_region_to_gcp(region)
                else:
                    gcp_region = region
                
                # Update specifications with mapped instance
                specifications = specifications.copy()
                specifications['instance_type'] = gcp_instance
                specifications['mapped_from_aws'] = instance_input
                specifications['mapping_details'] = mapping
                
                logger.info(f"✅ Using GCP equivalent: {gcp_instance} in {gcp_region}")
            else:
                gcp_instance = instance_input
                gcp_region = region
            
            # If we have a client with credentials, make REAL API call
            if self._client:
                logger.info(f"🟢 Making REAL GCP API call for {gcp_instance}")
                result = self._get_real_pricing(resource_type, gcp_region, specifications, quantity)
                
                # Add mapping info to result if applicable
                if 'mapped_from_aws' in specifications:
                    result_dict = json.loads(result)
                    result_dict['mapped_from'] = specifications['mapped_from_aws']
                    result_dict['mapping_note'] = f"AWS {specifications['mapped_from_aws']} is equivalent to GCP {gcp_instance}"
                    return json.dumps(result_dict, indent=2)
                return result
            else:
                # No credentials, return demo data with mapping info
                result = self._get_demo_pricing(resource_type, gcp_region, specifications, quantity)
                if 'mapped_from_aws' in specifications:
                    result_dict = json.loads(result)
                    result_dict['mapped_from'] = specifications['mapped_from_aws']
                    result_dict['mapping_note'] = f"AWS {specifications['mapped_from_aws']} is equivalent to GCP {gcp_instance}"
                    return json.dumps(result_dict, indent=2)
                return result
            
        except Exception as e:
            logger.error(f"Error in GCP pricing: {e}")
            return json.dumps({
                "error": str(e),
                "provider": "GCP",
                "message": "Falling back to demo data",
                "mode": "demo_fallback"
            })
    
    def _get_real_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
        """Get REAL pricing from GCP Cloud Billing API"""
        try:
            from google.cloud import billing_v1
            
            instance_type = specifications.get('instance_type', 'n1-standard-1')
            
            logger.info(f"Looking for GCP instance: {instance_type} in region: {region}")
            
            # Get the service name for compute
            service_name = f"services/6F81-5844-456A"  # Compute Engine service ID
            
            # List SKUs for compute
            request = billing_v1.ListSkusRequest(parent=service_name)
            skus = self._client.list_skus(request=request)
            
            # Find matching SKU
            matching_skus = []
            for sku in skus:
                # Check region
                if region not in sku.service_regions:
                    continue
                
                # Check if it's a compute SKU
                if 'compute' not in sku.category.resource_family.lower():
                    continue
                
                # Check for instance type in description
                if instance_type.lower() in sku.description.lower():
                    matching_skus.append(sku)
            
            if matching_skus:
                # Use the first matching SKU
                sku = matching_skus[0]
                
                # Extract pricing
                for pricing_info in sku.pricing_info:
                    for tiered_rate in pricing_info.pricing_expression.tiered_rates:
                        if tiered_rate.unit_price:
                            nanos = tiered_rate.unit_price.nanos
                            units = tiered_rate.unit_price.units
                            hourly_rate = units + (nanos / 1_000_000_000)
                            
                            usage_unit = pricing_info.pricing_expression.usage_unit
                            
                            if usage_unit == 'h':
                                monthly_rate = hourly_rate * 730 * quantity
                            elif usage_unit == 'mo':
                                monthly_rate = hourly_rate * quantity
                            else:
                                monthly_rate = hourly_rate * 730 * quantity
                            
                            # Get commitment discounts
                            commitment_1yr = hourly_rate * 0.7
                            commitment_3yr = hourly_rate * 0.5
                            
                            result = {
                                "provider": "GCP",
                                "service": "Compute Engine",
                                "region": region,
                                "instance_type": instance_type,
                                "hourly_rate": round(hourly_rate, 4),
                                "monthly_rate": round(monthly_rate, 2),
                                "currency": "USD",
                                "pricing_model": "On-Demand",
                                "data_source": "live_gcp_api",
                                "savings_options": {
                                    "committed_use_1yr": round(commitment_1yr, 4),
                                    "committed_use_3yr": round(commitment_3yr, 4),
                                    "preemptible": round(hourly_rate * 0.2, 4)
                                },
                                "sku_name": sku.name,
                                "sku_description": sku.description
                            }
                            
                            logger.info(f"✅ GCP live price found: ${monthly_rate:.2f}/month")
                            return json.dumps(result, indent=2)
            
            logger.warning(f"⚠️ No GCP price found for {instance_type}, using demo data")
            return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
        except Exception as e:
            logger.error(f"❌ Error in GCP real pricing: {e}")
            return self._get_demo_pricing(resource_type, region, specifications, quantity)
    
    def _get_demo_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
        """Return demo pricing data"""
        instance_type = specifications.get('instance_type', 'n1-standard-1')
        
        # Demo pricing map
        demo_prices = {
            # E2 series
            'e2-micro': 0.0130,
            'e2-small': 0.0260,
            'e2-medium': 0.0520,
            'e2-standard-2': 0.0670,
            'e2-standard-4': 0.1340,
            'e2-standard-8': 0.2680,
            'e2-standard-16': 0.5360,
            
            # N2 series
            'n2-standard-2': 0.0971,
            'n2-standard-4': 0.1942,
            'n2-standard-8': 0.3884,
            'n2-standard-16': 0.7768,
            'n2-standard-32': 1.5536,
            'n2-standard-48': 2.3304,
            'n2-standard-64': 3.1072,
            'n2-standard-80': 3.8840,
            
            # N2 high-memory
            'n2-highmem-2': 0.1184,
            'n2-highmem-4': 0.2368,
            'n2-highmem-8': 0.4736,
            'n2-highmem-16': 0.9472,
            'n2-highmem-32': 1.8944,
            'n2-highmem-48': 2.8416,
            'n2-highmem-64': 3.7888,
            'n2-highmem-80': 4.7360,
            
            # C2 series
            'c2-standard-4': 0.1488,
            'c2-standard-8': 0.2976,
            'c2-standard-16': 0.5952,
            'c2-standard-30': 1.1160,
            'c2-standard-60': 2.2320,
        }
        
        hourly_rate = demo_prices.get(instance_type, 0.0520)
        monthly_rate = hourly_rate * 730 * quantity
        
        result = {
            "provider": "GCP",
            "service": "Compute Engine",
            "region": region,
            "instance_type": instance_type,
            "hourly_rate": round(hourly_rate, 4),
            "monthly_rate": round(monthly_rate, 2),
            "currency": "USD",
            "pricing_model": "On-Demand",
            "savings_options": {
                "committed_use_1yr": round(hourly_rate * 0.7, 4),
                "committed_use_3yr": round(hourly_rate * 0.5, 4),
                "preemptible": round(hourly_rate * 0.2, 4)
            },
            "notes": "DEMO pricing data - Set GCP credentials for real prices",
            "mode": "demo"
        }
        
        logger.info(f"ℹ️ GCP demo price: ${monthly_rate:.2f}/month")
        return json.dumps(result, indent=2)
    
    async def _arun(self, *args, **kwargs):
        """Async version not implemented"""
        return self._run(*args, **kwargs)
