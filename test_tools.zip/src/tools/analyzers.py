"""
Analysis tools for Cloud Rationalization Agent
"""
from langchain.tools import BaseTool
from typing import Dict, List, Optional, Type
from pydantic import BaseModel, Field
import json
import logging
from datetime import datetime, timedelta
import numpy as np

logger = logging.getLogger(__name__)

class WorkloadAnalysisInput(BaseModel):
    """Input schema for workload analyzer"""
    resources: List[Dict] = Field(description="List of cloud resources to analyze")
    time_period_days: int = Field(default=30, description="Analysis time period in days")

class WorkloadAnalyzer(BaseTool):
    """Tool for analyzing workload patterns and optimization opportunities"""
    
    name = "workload_analyzer"
    description = """
    Analyze workload patterns to identify optimization opportunities.
    Provides right-sizing recommendations, identifies steady vs variable workloads,
    and suggests appropriate pricing models.
    """
    args_schema: Type[BaseModel] = WorkloadAnalysisInput
    
    def _run(self, resources: List[Dict], time_period_days: int = 30) -> str:
        """Run workload analysis"""
        try:
            analysis_results = {
                "workload_classification": {},
                "right_sizing_recommendations": [],
                "reserved_instance_candidates": [],
                "spot_instance_candidates": [],
                "optimization_summary": {}
            }
            
            total_potential_savings = 0
            
            for resource in resources:
                # Classify workload pattern
                pattern = self._classify_workload_pattern(resource)
                analysis_results["workload_classification"][resource.get('name', 'Unknown')] = pattern
                
                # Check for right-sizing opportunities
                right_sizing = self._analyze_right_sizing(resource)
                if right_sizing:
                    analysis_results["right_sizing_recommendations"].append(right_sizing)
                    total_potential_savings += right_sizing.get('potential_savings', 0)
                
                # Check for reserved instance eligibility
                if pattern in ['steady', 'predictable']:
                    ri_recommendation = self._evaluate_reserved_instances(resource)
                    if ri_recommendation:
                        analysis_results["reserved_instance_candidates"].append(ri_recommendation)
                        total_potential_savings += ri_recommendation.get('potential_savings', 0)
                
                # Check for spot instance eligibility
                if resource.get('fault_tolerant', False) or pattern == 'batch':
                    spot_recommendation = self._evaluate_spot_instances(resource)
                    if spot_recommendation:
                        analysis_results["spot_instance_candidates"].append(spot_recommendation)
                        total_potential_savings += spot_recommendation.get('potential_savings', 0)
            
            # Calculate summary statistics
            current_cost = sum(r.get('monthly_cost', 0) for r in resources)
            analysis_results["optimization_summary"] = {
                "total_resources_analyzed": len(resources),
                "current_monthly_cost": round(current_cost, 2),
                "potential_monthly_savings": round(total_potential_savings, 2),
                "savings_percentage": round((total_potential_savings / current_cost * 100), 1) if current_cost > 0 else 0,
                "analysis_period_days": time_period_days
            }
            
            return json.dumps(analysis_results, indent=2)
            
        except Exception as e:
            logger.error(f"Error in workload analysis: {e}")
            return json.dumps({"error": str(e)})
    
    def _classify_workload_pattern(self, resource: Dict) -> str:
        """Classify workload pattern based on resource attributes"""
        # This would use actual utilization data in production
        # For now, use provided pattern or infer from other attributes
        usage_pattern = resource.get('usage_pattern', 'unknown')
        
        if usage_pattern != 'unknown':
            return usage_pattern
        
        # Simple inference logic
        if resource.get('resource_type') == 'database':
            return 'steady'
        elif resource.get('environment') == 'production':
            return 'steady'
        elif resource.get('fault_tolerant'):
            return 'batch'
        else:
            return 'variable'
    
    def _analyze_right_sizing(self, resource: Dict) -> Optional[Dict]:
        """Analyze right-sizing opportunities"""
        # This would use actual utilization metrics in production
        current_size = resource.get('specifications', {}).get('instance_type', 'unknown')
        cpu_utilization = resource.get('metrics', {}).get('avg_cpu', 50)
        memory_utilization = resource.get('metrics', {}).get('avg_memory', 60)
        
        recommendation = None
        
        if cpu_utilization < 20 and memory_utilization < 30:
            # Over-provisioned
            recommendation = {
                "resource_name": resource.get('name'),
                "current_size": current_size,
                "recommended_size": self._get_smaller_instance(current_size),
                "reason": "Low utilization (CPU: {}%, Memory: {}%)".format(cpu_utilization, memory_utilization),
                "potential_savings": resource.get('monthly_cost', 0) * 0.4,  # 40% savings estimate
                "risk_level": "low",
                "implementation": "Simple resize during maintenance window"
            }
        elif cpu_utilization > 80 or memory_utilization > 85:
            # Under-provisioned
            recommendation = {
                "resource_name": resource.get('name'),
                "current_size": current_size,
                "recommended_size": self._get_larger_instance(current_size),
                "reason": "High utilization, risk of performance issues",
                "potential_savings": 0,  # No savings, but prevents performance issues
                "risk_level": "medium",
                "implementation": "Plan upgrade during off-peak hours"
            }
        
        return recommendation
    
    def _evaluate_reserved_instances(self, resource: Dict) -> Optional[Dict]:
        """Evaluate reserved instance potential"""
        current_cost = resource.get('monthly_cost', 0)
        
        # RI typically saves 40-60% compared to on-demand
        savings_estimate = current_cost * 0.5
        
        return {
            "resource_name": resource.get('name'),
            "current_model": "On-Demand",
            "recommended_term": "1 year",
            "recommended_payment": "Partial upfront",
            "potential_savings": savings_estimate,
            "confidence": "high" if resource.get('usage_pattern') == 'steady' else "medium",
            "notes": "Steady workload makes this a good candidate for Reserved Instances"
        }
    
    def _evaluate_spot_instances(self, resource: Dict) -> Optional[Dict]:
        """Evaluate spot instance potential"""
        current_cost = resource.get('monthly_cost', 0)
        
        # Spot instances typically save 60-90%
        savings_estimate = current_cost * 0.7
        
        return {
            "resource_name": resource.get('name'),
            "current_model": "On-Demand",
            "recommended_model": "Spot Instance",
            "potential_savings": savings_estimate,
            "interruption_risk": "medium",
            "suitable_workloads": ["Batch processing", "Stateless apps", "CI/CD runners"],
            "notes": "Fault-tolerant workload can leverage spot pricing"
        }
    
    def _get_smaller_instance(self, instance_type: str) -> str:
        """Get next smaller instance size"""
        # Simplified mapping - in production, use actual instance family mappings
        size_map = {
            't3.large': 't3.medium',
            't3.xlarge': 't3.large',
            'm5.large': 'm5.medium',
            'c5.large': 'c5.medium',
            'r5.large': 'r5.medium'
        }
        return size_map.get(instance_type, f"{instance_type} (smaller)")
    
    def _get_larger_instance(self, instance_type: str) -> str:
        """Get next larger instance size"""
        size_map = {
            't3.medium': 't3.large',
            't3.large': 't3.xlarge',
            'm5.medium': 'm5.large',
            'c5.medium': 'c5.large',
            'r5.medium': 'r5.large'
        }
        return size_map.get(instance_type, f"{instance_type} (larger)")
    
    async def _arun(self, *args, **kwargs):
        """Async version"""
        return self._run(*args, **kwargs)

class CostOptimizer(BaseTool):
    """Tool for cost optimization calculations"""
    
    name = "cost_optimizer"
    description = """
    Calculate cost savings from various optimization strategies.
    Provides detailed cost comparisons and ROI calculations.
    """
    
    def _run(self, current_costs: Dict, optimization_strategy: str, time_period_months: int = 12) -> str:
        """Run cost optimization calculations"""
        try:
            # Savings multipliers by strategy
            savings_multipliers = {
                "reserved_instances_1year": {
                    "no_upfront": 0.76,  # 24% savings
                    "partial_upfront": 0.71,  # 29% savings
                    "all_upfront": 0.67,  # 33% savings
                    "convertible": 0.55  # 45% savings (but flexible)
                },
                "reserved_instances_3year": {
                    "no_upfront": 0.60,  # 40% savings
                    "partial_upfront": 0.57,  # 43% savings
                    "all_upfront": 0.54,  # 46% savings
                    "convertible": 0.62  # 38% savings
                },
                "savings_plans": {
                    "1year": 0.72,  # 28% savings
                    "3year": 0.54  # 46% savings
                },
                "spot_instances": {
                    "standard": 0.30,  # 70% savings
                    "interruptible": 0.20  # 80% savings
                },
                "right_sizing": {
                    "over_provisioned": 0.50,  # 50% savings
                    "under_utilized": 0.30  # 30% savings (but performance improvement)
                },
                "storage_optimization": {
                    "lifecycle_policies": 0.60,  # 40% savings
                    "delete_unused": 0.80  # 20% savings (but cleanup)
                }
            }
            
            total_current = sum(current_costs.values()) if isinstance(current_costs, dict) else current_costs
            
            # Get multiplier for selected strategy
            strategy_parts = optimization_strategy.lower().split('_')
            main_strategy = strategy_parts[0]
            
            # Find best matching strategy
            if main_strategy in savings_multipliers:
                multipliers = savings_multipliers[main_strategy]
                # Get first multiplier if multiple options
                multiplier = list(multipliers.values())[0] if multipliers else 1.0
                
                optimized_cost = total_current * multiplier
                savings = total_current - optimized_cost
                
                # Calculate long-term savings
                total_savings_period = savings * time_period_months
                
                result = {
                    "current_monthly_cost": round(total_current, 2),
                    "optimized_monthly_cost": round(optimized_cost, 2),
                    "monthly_savings": round(savings, 2),
                    "savings_percentage": round((savings / total_current * 100), 1),
                    "time_period_months": time_period_months,
                    "total_savings_period": round(total_savings_period, 2),
                    "optimization_strategy": optimization_strategy,
                    "break_even_months": round(self._calculate_break_even(optimization_strategy, savings), 1),
                    "recommendations": self._get_strategy_recommendations(optimization_strategy)
                }
                
                return json.dumps(result, indent=2)
            else:
                return json.dumps({"error": f"Unknown strategy: {optimization_strategy}"})
                
        except Exception as e:
            logger.error(f"Error in cost optimization: {e}")
            return json.dumps({"error": str(e)})
    
    def _calculate_break_even(self, strategy: str, monthly_savings: float) -> float:
        """Calculate break-even period in months"""
        # Different strategies have different upfront costs
        upfront_costs = {
            "reserved_instances": total_current * 6,  # 6 months upfront
            "savings_plans": total_current * 0,  # No upfront for some plans
            "spot_instances": 0,
            "right_sizing": 500,  # Estimated engineering cost
        }
        
        strategy_key = strategy.split('_')[0]
        upfront = upfront_costs.get(strategy_key, 0)
        
        if monthly_savings > 0:
            return upfront / monthly_savings
        return float('inf')
    
    def _get_strategy_recommendations(self, strategy: str) -> List[str]:
        """Get recommendations for specific strategy"""
        recommendations = {
            "reserved": [
                "Start with 1-year terms for new workloads",
                "Use 3-year terms for stable, predictable workloads",
                "Consider convertible RIs for flexibility",
                "Combine with Savings Plans for comprehensive coverage"
            ],
            "spot": [
                "Use for stateless, fault-tolerant applications",
                "Implement graceful termination handling",
                "Diversify instance types for better availability",
                "Use Spot Fleet or Spot Instances with mixed types"
            ],
            "savings": [
                "Compute Savings Plans for EC2, Fargate, Lambda",
                "EC2 Instance Savings Plans for specific families",
                "Monitor utilization to optimize commitment",
                "Combine with RIs for maximum savings"
            ]
        }
        
        strategy_key = 'reserved' if 'reserved' in strategy else \
                      'spot' if 'spot' in strategy else \
                      'savings' if 'savings' in strategy else 'general'
        
        return recommendations.get(strategy_key, [
            "Analyze workload patterns first",
            "Start with low-risk optimizations",
            "Monitor after implementing changes",
            "Regularly review and adjust"
        ])
    
    async def _arun(self, *args, **kwargs):
        """Async version"""
        return self._run(*args, **kwargs)