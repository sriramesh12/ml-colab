"""
GCP Pricing Tool for Cloud Rationalization Agent
"""
from langchain.tools import BaseTool
from typing import Dict, Optional, Type
from pydantic import BaseModel, Field, ConfigDict
import json
import logging

logger = logging.getLogger(__name__)

class GCPPricingInput(BaseModel):
    """Input schema for GCP pricing tool"""
    resource_type: str = Field(description="Type of resource (compute, sql, storage, etc.)")
    region: str = Field(description="GCP region (us-central1, europe-west1, etc.)")
    specifications: Dict = Field(description="Resource specifications")
    quantity: int = Field(default=1, description="Number of instances")

class GCPPricingTool(BaseTool):
    """Tool for getting GCP pricing information"""
    
    name: str = "gcp_pricing_tool"
    description: str = """
    Get GCP pricing for Compute Engine, Cloud SQL, and other services.
    Returns prices in USD with hourly/monthly rates.
    Input should include resource type, region, and specifications.
    """
    args_schema: Type[BaseModel] = GCPPricingInput
    
    # Define fields
    credentials: Dict = Field(default_factory=dict)
    project_id: Optional[str] = Field(default=None)
    credentials_path: Optional[str] = Field(default=None)
    
    model_config = ConfigDict(arbitrary_types_allowed=True)
    
    def __init__(self, credentials: Optional[Dict] = None, **kwargs):
        """Initialize with credentials"""
        creds = credentials or {}
        project_id = creds.get('project_id')
        creds_path = creds.get('credentials_path')
        
        super().__init__(
            credentials=creds,
            project_id=project_id,
            credentials_path=creds_path,
            **kwargs
        )
        
        # Initialize client if credentials exist
        self.client = self._initialize_client()
    
    def _initialize_client(self):
        """Initialize GCP client if credentials exist"""
        if self.credentials_path:
            try:
                from google.cloud import billing_v1
                client = billing_v1.CloudCatalogClient.from_service_account_file(
                    self.credentials_path
                )
                logger.info("GCP client initialized")
                return client
            except Exception as e:
                logger.error(f"Failed to initialize GCP client: {e}")
                return None
        else:
            logger.info("GCP credentials not provided, using demo mode")
            return None
    
    def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
        """Run the tool"""
        try:
            # If no client, return demo data
            if not self.client:
                return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
            # Real GCP API call would go here
            # For now, return demo data
            return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
        except Exception as e:
            logger.error(f"Error in GCP pricing: {e}")
            return json.dumps({
                "error": str(e),
                "provider": "GCP",
                "message": "Falling back to demo data"
            })
    
    def _get_demo_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
        """Return demo pricing data"""
        instance_type = specifications.get('instance_type', 'n1-standard-1')
        
        # Demo pricing map for GCP
        demo_prices = {
            # General purpose N1
            'n1-standard-1': 0.0475,
            'n1-standard-2': 0.0950,
            'n1-standard-4': 0.1900,
            'n1-standard-8': 0.3800,
            'n1-standard-16': 0.7600,
            'n1-standard-32': 1.5200,
            
            # General purpose N2
            'n2-standard-2': 0.0971,
            'n2-standard-4': 0.1942,
            'n2-standard-8': 0.3884,
            'n2-standard-16': 0.7768,
            'n2-standard-32': 1.5536,
            
            # General purpose E2
            'e2-standard-2': 0.0670,
            'e2-standard-4': 0.1340,
            'e2-standard-8': 0.2680,
            'e2-standard-16': 0.5360,
            
            # Compute optimized
            'c2-standard-4': 0.1488,
            'c2-standard-8': 0.2976,
            'c2-standard-16': 0.5952,
            'c2-standard-30': 1.1160,
            
            # Memory optimized
            'n1-highmem-2': 0.1184,
            'n1-highmem-4': 0.2368,
            'n1-highmem-8': 0.4736,
            'n1-highmem-16': 0.9472,
            
            # Preemptible (spot) pricing
            'n1-standard-1-preemptible': 0.0067,
            'n1-standard-2-preemptible': 0.0134,
            'n1-standard-4-preemptible': 0.0268,
        }
        
        # Check if preemptible requested
        is_preemptible = specifications.get('preemptible', False) or 'preemptible' in instance_type
        
        # Get base price
        base_price = demo_prices.get(instance_type, 0.0475)
        
        # Apply preemptible discount if applicable
        if is_preemptible and 'preemptible' not in instance_type:
            hourly_rate = base_price * 0.2  # 80% discount for preemptible
        else:
            hourly_rate = base_price
        
        monthly_rate = hourly_rate * 730 * quantity
        
        # Add commitment discounts info
        commitment_1yr = hourly_rate * 0.7  # 30% discount
        commitment_3yr = hourly_rate * 0.5  # 50% discount
        
        result = {
            "provider": "GCP",
            "service": "Compute Engine",
            "region": region,
            "instance_type": instance_type,
            "hourly_rate": round(hourly_rate, 4),
            "monthly_rate": round(monthly_rate, 2),
            "annual_rate": round(monthly_rate * 12, 2),
            "currency": "USD",
            "pricing_model": "Preemptible" if is_preemptible else "On-Demand",
            "savings_options": {
                "committed_use_1yr": round(commitment_1yr, 4),
                "committed_use_3yr": round(commitment_3yr, 4),
                "preemptible": round(hourly_rate * 0.2, 4) if not is_preemptible else None
            },
            "notes": "Demo pricing data. Set GCP credentials for real prices.",
            "data_source": "demo"
        }
        
        return json.dumps(result, indent=2)
    
    def _get_committed_use_discount(self, instance_type: str, region: str, duration: str = "1yr") -> Dict:
        """
        Get committed use discount pricing
        """
        base_prices = {
            'n1-standard-1': 0.0475,
            'n1-standard-2': 0.0950,
            'n1-standard-4': 0.1900,
        }
        
        base = base_prices.get(instance_type, 0.0475)
        
        if duration == "1yr":
            discounted = base * 0.7  # 30% off
        else:  # 3yr
            discounted = base * 0.5  # 50% off
        
        return {
            "instance_type": instance_type,
            "region": region,
            "duration": duration,
            "original_hourly": base,
            "discounted_hourly": round(discounted, 4),
            "savings_percentage": 30 if duration == "1yr" else 50,
            "monthly_savings": round((base - discounted) * 730, 2)
        }
    
    def _get_sustained_use_discount(self, usage_hours: int = 730) -> Dict:
        """
        Calculate sustained use discounts (automatic for running full month)
        """
        if usage_hours >= 730:  # Full month
            discount = 0.3  # 30% for full month usage
        elif usage_hours >= 365:  # Half month
            discount = 0.2  # 20% for half month
        else:
            discount = 0
        
        return {
            "usage_hours": usage_hours,
            "discount_percentage": discount * 100,
            "qualifies_for_sustained_use": discount > 0
        }
    
    async def _arun(self, *args, **kwargs):
        """Async version not implemented"""
        return self._run(*args, **kwargs)
