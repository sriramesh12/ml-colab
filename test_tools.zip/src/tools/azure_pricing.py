# # # # # # """
# # # # # # Azure Pricing Tool for Cloud Rationalization Agent
# # # # # # Pydantic v2 compatible version
# # # # # # """
# # # # # # from langchain.tools import BaseTool
# # # # # # from typing import Dict, Optional, Type
# # # # # # from pydantic import BaseModel, Field, ConfigDict
# # # # # # import json
# # # # # # import logging

# # # # # # logger = logging.getLogger(__name__)

# # # # # # class AzurePricingInput(BaseModel):
# # # # # #     """Input schema for Azure pricing tool"""
# # # # # #     resource_type: str = Field(description="Type of resource (VM, Storage, SQL, etc.)")
# # # # # #     region: str = Field(description="Azure region (eastus, westeurope, etc.)")
# # # # # #     specifications: Dict = Field(description="Resource specifications")
# # # # # #     quantity: int = Field(default=1, description="Number of instances")

# # # # # # class AzurePricingTool(BaseTool):
# # # # # #     """Tool for getting Azure pricing information"""
    
# # # # # #     name: str = "azure_pricing_tool"
# # # # # #     description: str = "Get real-time Azure pricing for VMs, Storage, SQL, and other services."
# # # # # #     args_schema: Type[BaseModel] = AzurePricingInput
    
# # # # # #     # Define fields properly
# # # # # #     subscription_key: Optional[str] = Field(default=None, description="Azure Subscription Key")
# # # # # #     base_url: str = Field(default="https://prices.azure.com/api/retail/prices", description="Azure Retail Prices API URL")
    
# # # # # #     model_config = ConfigDict(arbitrary_types_allowed=True)
    
# # # # # #     def __init__(self, credentials: Optional[Dict] = None, **kwargs):
# # # # # #         subscription_key = None
# # # # # #         if credentials:
# # # # # #             subscription_key = credentials.get('subscription_key')
        
# # # # # #         super().__init__(
# # # # # #             subscription_key=subscription_key,
# # # # # #             base_url="https://prices.azure.com/api/retail/prices",
# # # # # #             **kwargs
# # # # # #         )
    
# # # # # #     def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
# # # # # #         """Run the tool"""
# # # # # #         try:
# # # # # #             # If no subscription key, return demo data
# # # # # #             if not self.subscription_key:
# # # # # #                 return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
# # # # # #             # For now, return demo data
# # # # # #             return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
# # # # # #         except Exception as e:
# # # # # #             logger.error(f"Error in Azure pricing: {e}")
# # # # # #             return json.dumps({
# # # # # #                 "error": str(e),
# # # # # #                 "provider": "Azure",
# # # # # #                 "message": "Falling back to demo data"
# # # # # #             })
    
# # # # # #     def _get_demo_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
# # # # # #         """Return demo pricing data"""
# # # # # #         instance_type = specifications.get('instance_type', 'D2s v3')
        
# # # # # #         # Demo pricing map
# # # # # #         demo_prices = {
# # # # # #             'B2s': 0.0416,
# # # # # #             'B4ms': 0.166,
# # # # # #             'D2s v3': 0.096,
# # # # # #             'D4s v3': 0.192,
# # # # # #             'D8s v3': 0.384,
# # # # # #             'F2s v2': 0.084,
# # # # # #             'F4s v2': 0.168,
# # # # # #             'E2s v3': 0.146,
# # # # # #             'E4s v3': 0.292,
# # # # # #         }
        
# # # # # #         hourly_rate = demo_prices.get(instance_type, 0.096)
# # # # # #         monthly_rate = hourly_rate * 730 * quantity
        
# # # # # #         result = {
# # # # # #             "provider": "Azure",
# # # # # #             "service": "Virtual Machines",
# # # # # #             "region": region,
# # # # # #             "instance_type": instance_type,
# # # # # #             "hourly_rate": round(hourly_rate, 4),
# # # # # #             "monthly_rate": round(monthly_rate, 2),
# # # # # #             "currency": "USD",
# # # # # #             "pricing_model": "Pay-As-You-Go",
# # # # # #             "notes": "Demo pricing data. Set Azure subscription key for real prices.",
# # # # # #             "mode": "demo"
# # # # # #         }
        
# # # # # #         return json.dumps(result, indent=2)
    
# # # # # #     async def _arun(self, *args, **kwargs):
# # # # # #         """Async version not implemented"""
# # # # # #         return self._run(*args, **kwargs)
# # # # # """
# # # # # Azure Pricing Tool for Cloud Rationalization Agent
# # # # # Fixed version - Actually calls Azure Retail Prices API
# # # # # """
# # # # # from langchain.tools import BaseTool
# # # # # from typing import Dict, Optional, Type
# # # # # from pydantic import BaseModel, Field, ConfigDict
# # # # # import requests
# # # # # import json
# # # # # import logging

# # # # # logger = logging.getLogger(__name__)

# # # # # class AzurePricingInput(BaseModel):
# # # # #     """Input schema for Azure pricing tool"""
# # # # #     resource_type: str = Field(description="Type of resource (VM, Storage, SQL, etc.)")
# # # # #     region: str = Field(description="Azure region (eastus, westeurope, etc.)")
# # # # #     specifications: Dict = Field(description="Resource specifications")
# # # # #     quantity: int = Field(default=1, description="Number of instances")

# # # # # class AzurePricingTool(BaseTool):
# # # # #     """Tool for getting Azure pricing information"""
    
# # # # #     name: str = "azure_pricing_tool"
# # # # #     description: str = "Get real-time Azure pricing for VMs, Storage, SQL, and other services."
# # # # #     args_schema: Type[BaseModel] = AzurePricingInput
    
# # # # #     # Define fields properly
# # # # #     subscription_key: Optional[str] = Field(default=None, description="Azure Subscription Key")
# # # # #     base_url: str = Field(default="https://prices.azure.com/api/retail/prices", description="Azure Retail Prices API URL")
    
# # # # #     model_config = ConfigDict(arbitrary_types_allowed=True)
    
# # # # #     def __init__(self, credentials: Optional[Dict] = None, **kwargs):
# # # # #         subscription_key = None
# # # # #         if credentials:
# # # # #             subscription_key = credentials.get('subscription_key')
        
# # # # #         super().__init__(
# # # # #             subscription_key=subscription_key,
# # # # #             base_url="https://prices.azure.com/api/retail/prices",
# # # # #             **kwargs
# # # # #         )
        
# # # # #         if self.subscription_key:
# # # # #             logger.info("✅ Azure credentials configured for real API calls")
# # # # #         else:
# # # # #             logger.info("ℹ️ No Azure credentials, using demo mode")
    
# # # # #     def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
# # # # #         """Run the tool - makes REAL Azure API call if credentials available"""
# # # # #         try:
# # # # #             # If we have subscription key, make REAL API call
# # # # #             if self.subscription_key:
# # # # #                 logger.info(f"🔴 Making REAL Azure API call for {specifications.get('instance_type')}")
# # # # #                 return self._get_real_pricing(resource_type, region, specifications, quantity)
# # # # #             else:
# # # # #                 # No credentials, return demo data
# # # # #                 logger.info("ℹ️ No Azure credentials, using demo data")
# # # # #                 return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
# # # # #         except Exception as e:
# # # # #             logger.error(f"Error in Azure pricing: {e}")
# # # # #             return json.dumps({
# # # # #                 "error": str(e),
# # # # #                 "provider": "Azure",
# # # # #                 "message": "Falling back to demo data",
# # # # #                 "mode": "demo_fallback"
# # # # #             })
    
# # # # #     def _get_real_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
# # # # #         """Get REAL pricing from Azure Retail Prices API"""
# # # # #         try:
# # # # #             instance_type = specifications.get('instance_type', 'D2s v3')
            
# # # # #             # Map Azure region codes
# # # # #             region_map = {
# # # # #                 'eastus': 'US East',
# # # # #                 'westus': 'US West',
# # # # #                 'westeurope': 'West Europe',
# # # # #                 'southeastasia': 'Southeast Asia'
# # # # #             }
# # # # #             azure_region = region_map.get(region, region)
            
# # # # #             # Build filter for Azure API
# # # # #             filters = []
# # # # #             filters.append(f"serviceName eq 'Virtual Machines'")
# # # # #             filters.append(f"armRegionName eq '{region}'")
# # # # #             filters.append(f"skuName eq '{instance_type}'")
            
# # # # #             filter_string = " and ".join(filters)
            
# # # # #             # Call Azure Retail Prices API
# # # # #             params = {
# # # # #                 "$filter": filter_string,
# # # # #                 "api-version": "2023-01-01"
# # # # #             }
            
# # # # #             headers = {}
# # # # #             if self.subscription_key:
# # # # #                 headers["Authorization"] = f"Bearer {self.subscription_key}"
            
# # # # #             response = requests.get(
# # # # #                 self.base_url, 
# # # # #                 params=params, 
# # # # #                 headers=headers,
# # # # #                 timeout=10
# # # # #             )
            
# # # # #             if response.status_code == 200:
# # # # #                 data = response.json()
# # # # #                 items = data.get('Items', [])
                
# # # # #                 if items:
# # # # #                     # Get the first item (most relevant)
# # # # #                     item = items[0]
# # # # #                     retail_price = item.get('retailPrice', 0)
# # # # #                     unit_of_measure = item.get('unitOfMeasure', '1 Hour')
                    
# # # # #                     # Calculate rates based on unit
# # # # #                     if 'Hour' in unit_of_measure:
# # # # #                         hourly_rate = retail_price
# # # # #                     elif 'Month' in unit_of_measure:
# # # # #                         hourly_rate = retail_price / 730
# # # # #                     else:
# # # # #                         hourly_rate = retail_price
                    
# # # # #                     monthly_rate = hourly_rate * 730 * quantity
                    
# # # # #                     result = {
# # # # #                         "provider": "Azure",
# # # # #                         "service": "Virtual Machines",
# # # # #                         "region": region,
# # # # #                         "instance_type": instance_type,
# # # # #                         "hourly_rate": round(hourly_rate, 4),
# # # # #                         "monthly_rate": round(monthly_rate, 2),
# # # # #                         "currency": "USD",
# # # # #                         "pricing_model": "Pay-As-You-Go",
# # # # #                         "data_source": "live_azure_api",
# # # # #                         "notes": "Real-time pricing from Azure Retail Prices API",
# # # # #                         "sku": item.get('armSkuName', ''),
# # # # #                         "product_name": item.get('productName', '')
# # # # #                     }
                    
# # # # #                     logger.info(f"✅ Azure live price found: ${monthly_rate:.2f}/month")
# # # # #                     return json.dumps(result, indent=2)
# # # # #                 else:
# # # # #                     logger.warning(f"⚠️ No Azure price found for {instance_type}")
# # # # #             else:
# # # # #                 logger.error(f"❌ Azure API error: {response.status_code}")
            
# # # # #             # Fallback to demo if API fails
# # # # #             logger.info("ℹ️ Falling back to Azure demo data")
# # # # #             return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
# # # # #         except Exception as e:
# # # # #             logger.error(f"❌ Error in Azure real pricing: {e}")
# # # # #             return self._get_demo_pricing(resource_type, region, specifications, quantity)
    
# # # # #     def _get_demo_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
# # # # #         """Return demo pricing data"""
# # # # #         instance_type = specifications.get('instance_type', 'D2s v3')
        
# # # # #         # Demo pricing map
# # # # #         demo_prices = {
# # # # #             'B2s': 0.0416,
# # # # #             'B4ms': 0.166,
# # # # #             'D2s v3': 0.096,
# # # # #             'D4s v3': 0.192,
# # # # #             'D8s v3': 0.384,
# # # # #             'F2s v2': 0.084,
# # # # #             'F4s v2': 0.168,
# # # # #             'E2s v3': 0.146,
# # # # #             'E4s v3': 0.292,
# # # # #         }
        
# # # # #         hourly_rate = demo_prices.get(instance_type, 0.096)
# # # # #         monthly_rate = hourly_rate * 730 * quantity
        
# # # # #         result = {
# # # # #             "provider": "Azure",
# # # # #             "service": "Virtual Machines",
# # # # #             "region": region,
# # # # #             "instance_type": instance_type,
# # # # #             "hourly_rate": round(hourly_rate, 4),
# # # # #             "monthly_rate": round(monthly_rate, 2),
# # # # #             "currency": "USD",
# # # # #             "pricing_model": "Pay-As-You-Go",
# # # # #             "notes": "DEMO pricing data - Set Azure subscription key for real prices",
# # # # #             "mode": "demo"
# # # # #         }
        
# # # # #         logger.info(f"ℹ️ Azure demo price: ${monthly_rate:.2f}/month")
# # # # #         return json.dumps(result, indent=2)
    
# # # # #     async def _arun(self, *args, **kwargs):
# # # # #         """Async version not implemented"""
# # # # #         return self._run(*args, **kwargs)
# # # # """
# # # # Azure Pricing Tool for Cloud Rationalization Agent
# # # # Enhanced version with automatic AWS to Azure instance mapping
# # # # """
# # # # from langchain.tools import BaseTool
# # # # from typing import Dict, Optional, Type, List
# # # # from pydantic import BaseModel, Field, ConfigDict
# # # # import requests
# # # # import json
# # # # import logging

# # # # logger = logging.getLogger(__name__)

# # # # class AzurePricingInput(BaseModel):
# # # #     """Input schema for Azure pricing tool"""
# # # #     resource_type: str = Field(description="Type of resource (VM, Storage, SQL, etc.)")
# # # #     region: str = Field(description="Azure region (eastus, westeurope, etc.)")
# # # #     specifications: Dict = Field(description="Resource specifications")
# # # #     quantity: int = Field(default=1, description="Number of instances")

# # # # class AzurePricingTool(BaseTool):
# # # #     """Tool for getting Azure pricing information with automatic instance mapping"""
    
# # # #     name: str = "azure_pricing_tool"
# # # #     description: str = """
# # # #     Get real-time Azure pricing for VMs. 
# # # #     Automatically maps AWS instance types to equivalent Azure instances.
# # # #     Supports: t3.micro -> B2s, t3.medium -> B2s, m5.large -> D2s v3, etc.
# # # #     """
# # # #     args_schema: Type[BaseModel] = AzurePricingInput
    
# # # #     # Define fields properly
# # # #     subscription_key: Optional[str] = Field(default=None, description="Azure Subscription Key")
# # # #     base_url: str = Field(default="https://prices.azure.com/api/retail/prices", description="Azure Retail Prices API URL")
    
# # # #     model_config = ConfigDict(arbitrary_types_allowed=True)
    
# # # #     # ===== AWS TO AZURE INSTANCE MAPPING =====
# # # #     # Based on vCPU, memory, and use case
# # # #     AWS_TO_AZURE_MAP = {
# # # #         # General purpose - similar to AWS T3 series (burstable)
# # # #         "t3.nano": {"family": "Bs", "size": "B2s", "vcpu": 1, "memory": 0.5, "equivalent": "B2s"},
# # # #         "t3.micro": {"family": "Bs", "size": "B2s", "vcpu": 2, "memory": 1, "equivalent": "B2s"},
# # # #         "t3.small": {"family": "Bs", "size": "B2s", "vcpu": 2, "memory": 2, "equivalent": "B2s"},
# # # #         "t3.medium": {"family": "Bs", "size": "B4ms", "vcpu": 2, "memory": 4, "equivalent": "B4ms"},
# # # #         "t3.large": {"family": "Bs", "size": "B8ms", "vcpu": 2, "memory": 8, "equivalent": "B8ms"},
# # # #         "t3.xlarge": {"family": "Bs", "size": "B16ms", "vcpu": 4, "memory": 16, "equivalent": "B16ms"},
# # # #         "t3.2xlarge": {"family": "Bs", "size": "B32ms", "vcpu": 8, "memory": 32, "equivalent": "B32ms"},
        
# # # #         # General purpose - AWS M5 series (balanced)
# # # #         "m5.large": {"family": "D", "size": "D2s v3", "vcpu": 2, "memory": 8, "equivalent": "D2s v3"},
# # # #         "m5.xlarge": {"family": "D", "size": "D4s v3", "vcpu": 4, "memory": 16, "equivalent": "D4s v3"},
# # # #         "m5.2xlarge": {"family": "D", "size": "D8s v3", "vcpu": 8, "memory": 32, "equivalent": "D8s v3"},
# # # #         "m5.4xlarge": {"family": "D", "size": "D16s v3", "vcpu": 16, "memory": 64, "equivalent": "D16s v3"},
# # # #         "m5.8xlarge": {"family": "D", "size": "D32s v3", "vcpu": 32, "memory": 128, "equivalent": "D32s v3"},
# # # #         "m5.12xlarge": {"family": "D", "size": "D48s v3", "vcpu": 48, "memory": 192, "equivalent": "D48s v3"},
# # # #         "m5.16xlarge": {"family": "D", "size": "D64s v3", "vcpu": 64, "memory": 256, "equivalent": "D64s v3"},
        
# # # #         # Compute optimized - AWS C5 series
# # # #         "c5.large": {"family": "F", "size": "F2s v2", "vcpu": 2, "memory": 4, "equivalent": "F2s v2"},
# # # #         "c5.xlarge": {"family": "F", "size": "F4s v2", "vcpu": 4, "memory": 8, "equivalent": "F4s v2"},
# # # #         "c5.2xlarge": {"family": "F", "size": "F8s v2", "vcpu": 8, "memory": 16, "equivalent": "F8s v2"},
# # # #         "c5.4xlarge": {"family": "F", "size": "F16s v2", "vcpu": 16, "memory": 32, "equivalent": "F16s v2"},
# # # #         "c5.9xlarge": {"family": "F", "size": "F36s v2", "vcpu": 36, "memory": 72, "equivalent": "F36s v2"},
# # # #         "c5.12xlarge": {"family": "F", "size": "F48s v2", "vcpu": 48, "memory": 96, "equivalent": "F48s v2"},
# # # #         "c5.18xlarge": {"family": "F", "size": "F72s v2", "vcpu": 72, "memory": 144, "equivalent": "F72s v2"},
        
# # # #         # Memory optimized - AWS R5 series
# # # #         "r5.large": {"family": "E", "size": "E2s v3", "vcpu": 2, "memory": 16, "equivalent": "E2s v3"},
# # # #         "r5.xlarge": {"family": "E", "size": "E4s v3", "vcpu": 4, "memory": 32, "equivalent": "E4s v3"},
# # # #         "r5.2xlarge": {"family": "E", "size": "E8s v3", "vcpu": 8, "memory": 64, "equivalent": "E8s v3"},
# # # #         "r5.4xlarge": {"family": "E", "size": "E16s v3", "vcpu": 16, "memory": 128, "equivalent": "E16s v3"},
# # # #         "r5.8xlarge": {"family": "E", "size": "E32s v3", "vcpu": 32, "memory": 256, "equivalent": "E32s v3"},
# # # #         "r5.12xlarge": {"family": "E", "size": "E48s v3", "vcpu": 48, "memory": 384, "equivalent": "E48s v3"},
# # # #         "r5.16xlarge": {"family": "E", "size": "E64s v3", "vcpu": 64, "memory": 512, "equivalent": "E64s v3"},
        
# # # #         # Storage optimized - AWS I3 series
# # # #         "i3.large": {"family": "L", "size": "L4s", "vcpu": 2, "memory": 16, "equivalent": "L4s"},
# # # #         "i3.xlarge": {"family": "L", "size": "L8s", "vcpu": 4, "memory": 32, "equivalent": "L8s"},
# # # #         "i3.2xlarge": {"family": "L", "size": "L16s", "vcpu": 8, "memory": 64, "equivalent": "L16s"},
# # # #         "i3.4xlarge": {"family": "L", "size": "L32s", "vcpu": 16, "memory": 128, "equivalent": "L32s"},
# # # #         "i3.8xlarge": {"family": "L", "size": "L64s", "vcpu": 32, "memory": 256, "equivalent": "L64s"},
# # # #         "i3.16xlarge": {"family": "L", "size": "L80s", "vcpu": 64, "memory": 512, "equivalent": "L80s"},
        
# # # #         # GPU instances - AWS G4 series
# # # #         "g4dn.xlarge": {"family": "NC", "size": "NC6s v3", "vcpu": 4, "memory": 16, "gpu": "T4", "equivalent": "NC6s v3"},
# # # #         "g4dn.2xlarge": {"family": "NC", "size": "NC12s v3", "vcpu": 8, "memory": 32, "gpu": "T4", "equivalent": "NC12s v3"},
# # # #         "g4dn.4xlarge": {"family": "NC", "size": "NC24s v3", "vcpu": 16, "memory": 64, "gpu": "T4", "equivalent": "NC24s v3"},
# # # #     }
    
# # # #     # ===== REGION MAPPING =====
# # # #     AWS_TO_AZURE_REGION_MAP = {
# # # #         "us-east-1": "eastus",
# # # #         "us-east-2": "eastus2",
# # # #         "us-west-1": "westus",
# # # #         "us-west-2": "westus2",
# # # #         "eu-west-1": "westeurope",
# # # #         "eu-central-1": "germanywestcentral",
# # # #         "ap-southeast-1": "southeastasia",
# # # #         "ap-northeast-1": "japaneast",
# # # #         "ap-south-1": "centralindia",
# # # #         "sa-east-1": "brazilsouth",
# # # #         "ca-central-1": "canadacentral",
# # # #         "eu-west-2": "uksouth",
# # # #     }
    
# # # #     AZURE_TO_AWS_REGION_MAP = {v: k for k, v in AWS_TO_AZURE_REGION_MAP.items()}
    
# # # #     def __init__(self, credentials: Optional[Dict] = None, **kwargs):
# # # #         subscription_key = None
# # # #         if credentials:
# # # #             subscription_key = credentials.get('subscription_key')
        
# # # #         super().__init__(
# # # #             subscription_key=subscription_key,
# # # #             base_url="https://prices.azure.com/api/retail/prices",
# # # #             **kwargs
# # # #         )
        
# # # #         if self.subscription_key:
# # # #             logger.info("✅ Azure credentials configured for real API calls")
# # # #         else:
# # # #             logger.info("ℹ️ No Azure credentials, using demo mode")
    
# # # #     def _map_aws_instance_to_azure(self, aws_instance: str) -> Dict:
# # # #         """
# # # #         Map AWS instance type to equivalent Azure instance
# # # #         Returns dict with mapping info
# # # #         """
# # # #         if aws_instance in self.AWS_TO_AZURE_MAP:
# # # #             mapping = self.AWS_TO_AZURE_MAP[aws_instance]
# # # #             logger.info(f"🔄 Mapped AWS {aws_instance} -> Azure {mapping['equivalent']} ({mapping['family']} family)")
# # # #             return mapping
# # # #         else:
# # # #             # Try to find by partial match
# # # #             for key, value in self.AWS_TO_AZURE_MAP.items():
# # # #                 if key.split('.')[0] in aws_instance:  # Match family
# # # #                     logger.info(f"🔄 Partial match: AWS {aws_instance} -> Azure {value['equivalent']} (based on {key})")
# # # #                     return value
            
# # # #             # Default fallback
# # # #             logger.warning(f"⚠️ No mapping found for {aws_instance}, using default B2s")
# # # #             return {"family": "Bs", "size": "B2s", "equivalent": "B2s", "vcpu": 2, "memory": 4}
    
# # # #     def _map_aws_region_to_azure(self, aws_region: str) -> str:
# # # #         """Map AWS region to equivalent Azure region"""
# # # #         if aws_region in self.AWS_TO_AZURE_REGION_MAP:
# # # #             azure_region = self.AWS_TO_AZURE_REGION_MAP[aws_region]
# # # #             logger.info(f"🔄 Mapped AWS region {aws_region} -> Azure {azure_region}")
# # # #             return azure_region
# # # #         else:
# # # #             # If no mapping, return as-is (might already be Azure region)
# # # #             logger.info(f"Using region {aws_region} as-is")
# # # #             return aws_region
    
# # # #     def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
# # # #         """Run the tool with automatic instance mapping"""
# # # #         try:
# # # #             # Check if the instance type looks like AWS (contains dot)
# # # #             instance_input = specifications.get('instance_type', 'D2s v3')
            
# # # #             # Auto-detect and map if it's an AWS instance
# # # #             if '.' in instance_input and not any(x in instance_input for x in ['D', 'E', 'F', 'B', 'NC']):
# # # #                 logger.info(f"🔍 Detected AWS instance type: {instance_input}")
# # # #                 mapping = self._map_aws_instance_to_azure(instance_input)
# # # #                 azure_instance = mapping['equivalent']
                
# # # #                 # Also map region if it looks like AWS region
# # # #                 if '.' in region or '-' in region:
# # # #                     azure_region = self._map_aws_region_to_azure(region)
# # # #                 else:
# # # #                     azure_region = region
                
# # # #                 # Update specifications with mapped instance
# # # #                 specifications = specifications.copy()
# # # #                 specifications['instance_type'] = azure_instance
# # # #                 specifications['mapped_from_aws'] = instance_input
# # # #                 specifications['mapping_details'] = mapping
                
# # # #                 logger.info(f"✅ Using Azure equivalent: {azure_instance} in {azure_region}")
# # # #             else:
# # # #                 azure_instance = instance_input
# # # #                 azure_region = region
            
# # # #             # If we have subscription key, make REAL API call
# # # #             if self.subscription_key:
# # # #                 logger.info(f"🔴 Making REAL Azure API call for {azure_instance}")
# # # #                 result = self._get_real_pricing(resource_type, azure_region, specifications, quantity)
                
# # # #                 # Add mapping info to result if applicable
# # # #                 if 'mapped_from_aws' in specifications:
# # # #                     result_dict = json.loads(result)
# # # #                     result_dict['mapped_from'] = specifications['mapped_from_aws']
# # # #                     result_dict['mapping_note'] = f"AWS {specifications['mapped_from_aws']} is equivalent to Azure {azure_instance}"
# # # #                     return json.dumps(result_dict, indent=2)
# # # #                 return result
# # # #             else:
# # # #                 # No credentials, return demo data with mapping info
# # # #                 result = self._get_demo_pricing(resource_type, azure_region, specifications, quantity)
# # # #                 if 'mapped_from_aws' in specifications:
# # # #                     result_dict = json.loads(result)
# # # #                     result_dict['mapped_from'] = specifications['mapped_from_aws']
# # # #                     result_dict['mapping_note'] = f"AWS {specifications['mapped_from_aws']} is equivalent to Azure {azure_instance}"
# # # #                     return json.dumps(result_dict, indent=2)
# # # #                 return result
            
# # # #         except Exception as e:
# # # #             logger.error(f"Error in Azure pricing: {e}")
# # # #             return json.dumps({
# # # #                 "error": str(e),
# # # #                 "provider": "Azure",
# # # #                 "message": "Falling back to demo data",
# # # #                 "mode": "demo_fallback"
# # # #             })
    
# # # #     def _get_real_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
# # # #         """Get REAL pricing from Azure Retail Prices API"""
# # # #         try:
# # # #             instance_type = specifications.get('instance_type', 'D2s v3')
            
# # # #             logger.info(f"Looking for Azure VM: {instance_type} in region: {region}")
            
# # # #             # Build filter for Azure API
# # # #             filters = []
# # # #             filters.append(f"serviceName eq 'Virtual Machines'")
# # # #             filters.append(f"armRegionName eq '{region}'")
            
# # # #             filter_string = " and ".join(filters)
            
# # # #             logger.info(f"Filter: {filter_string}")
            
# # # #             # Call Azure Retail Prices API
# # # #             params = {
# # # #                 "$filter": filter_string,
# # # #                 "api-version": "2023-01-01"
# # # #             }
            
# # # #             response = requests.get(self.base_url, params=params, timeout=10)
# # # #             logger.info(f"Azure API Response Status: {response.status_code}")
            
# # # #             if response.status_code == 200:
# # # #                 data = response.json()
# # # #                 items = data.get('Items', [])
                
# # # #                 logger.info(f"Found {len(items)} VM SKUs in {region}")
                
# # # #                 # Try to find exact match
# # # #                 for item in items:
# # # #                     sku_name = item.get('armSkuName', '')
# # # #                     if instance_type.lower() in sku_name.lower():
# # # #                         retail_price = item.get('retailPrice', 0)
# # # #                         unit_of_measure = item.get('unitOfMeasure', '1 Hour')
                        
# # # #                         if 'Hour' in unit_of_measure:
# # # #                             hourly_rate = retail_price
# # # #                         elif 'Month' in unit_of_measure:
# # # #                             hourly_rate = retail_price / 730
# # # #                         else:
# # # #                             hourly_rate = retail_price
                        
# # # #                         monthly_rate = hourly_rate * 730 * quantity
                        
# # # #                         result = {
# # # #                             "provider": "Azure",
# # # #                             "service": "Virtual Machines",
# # # #                             "region": region,
# # # #                             "instance_type": instance_type,
# # # #                             "hourly_rate": round(hourly_rate, 4),
# # # #                             "monthly_rate": round(monthly_rate, 2),
# # # #                             "currency": "USD",
# # # #                             "pricing_model": "Pay-As-You-Go",
# # # #                             "data_source": "live_azure_api",
# # # #                             "sku": sku_name,
# # # #                             "unit_of_measure": unit_of_measure
# # # #                         }
                        
# # # #                         logger.info(f"✅ Azure live price found: ${monthly_rate:.2f}/month")
# # # #                         return json.dumps(result, indent=2)
                
# # # #                 logger.warning(f"⚠️ No exact match for {instance_type}")
# # # #                 return self._get_demo_pricing(resource_type, region, specifications, quantity)
# # # #             else:
# # # #                 logger.error(f"❌ Azure API error: {response.status_code}")
# # # #                 return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
# # # #         except Exception as e:
# # # #             logger.error(f"❌ Error in Azure real pricing: {e}")
# # # #             return self._get_demo_pricing(resource_type, region, specifications, quantity)
    
# # # #     def _get_demo_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
# # # #         """Return demo pricing data"""
# # # #         instance_type = specifications.get('instance_type', 'D2s v3')
        
# # # #         # Demo pricing map
# # # #         demo_prices = {
# # # #             'B2s': 0.0416,
# # # #             'B4ms': 0.166,
# # # #             'D2s v3': 0.096,
# # # #             'D4s v3': 0.192,
# # # #             'D8s v3': 0.384,
# # # #             'F2s v2': 0.084,
# # # #             'F4s v2': 0.168,
# # # #             'E2s v3': 0.146,
# # # #             'E4s v3': 0.292,
# # # #         }
        
# # # #         hourly_rate = demo_prices.get(instance_type, 0.096)
# # # #         monthly_rate = hourly_rate * 730 * quantity
        
# # # #         result = {
# # # #             "provider": "Azure",
# # # #             "service": "Virtual Machines",
# # # #             "region": region,
# # # #             "instance_type": instance_type,
# # # #             "hourly_rate": round(hourly_rate, 4),
# # # #             "monthly_rate": round(monthly_rate, 2),
# # # #             "currency": "USD",
# # # #             "pricing_model": "Pay-As-You-Go",
# # # #             "notes": "DEMO pricing data",
# # # #             "mode": "demo"
# # # #         }
        
# # # #         logger.info(f"ℹ️ Azure demo price: ${monthly_rate:.2f}/month")
# # # #         return json.dumps(result, indent=2)
    
# # # #     async def _arun(self, *args, **kwargs):
# # # #         """Async version not implemented"""
# # # #         return self._run(*args, **kwargs)
# # # """
# # # Azure Pricing Tool for Cloud Rationalization Agent
# # # Fixed version - Corrected filter syntax and better error handling
# # # """
# # # from langchain.tools import BaseTool
# # # from typing import Dict, Optional, Type, List
# # # from pydantic import BaseModel, Field, ConfigDict
# # # import requests
# # # import json
# # # import logging
# # # import urllib.parse

# # # logger = logging.getLogger(__name__)

# # # class AzurePricingInput(BaseModel):
# # #     """Input schema for Azure pricing tool"""
# # #     resource_type: str = Field(description="Type of resource (VM, Storage, SQL, etc.)")
# # #     region: str = Field(description="Azure region (eastus, westeurope, etc.)")
# # #     specifications: Dict = Field(description="Resource specifications")
# # #     quantity: int = Field(default=1, description="Number of instances")

# # # class AzurePricingTool(BaseTool):
# # #     """Tool for getting Azure pricing information with automatic instance mapping"""
    
# # #     name: str = "azure_pricing_tool"
# # #     description: str = """
# # #     Get real-time Azure pricing for VMs. 
# # #     Automatically maps AWS instance types to equivalent Azure instances.
# # #     """
# # #     args_schema: Type[BaseModel] = AzurePricingInput
    
# # #     # Define fields properly
# # #     subscription_key: Optional[str] = Field(default=None, description="Azure Subscription Key")
# # #     base_url: str = Field(default="https://prices.azure.com/api/retail/prices", description="Azure Retail Prices API URL")
    
# # #     model_config = ConfigDict(arbitrary_types_allowed=True)
    
# # #     # ===== AWS TO AZURE INSTANCE MAPPING =====
# # #     AWS_TO_AZURE_MAP = {
# # #         # General purpose - AWS T3 series
# # #         "t3.nano": {"family": "Bs", "size": "B2s", "vcpu": 1, "memory": 0.5, "equivalent": "B2s"},
# # #         "t3.micro": {"family": "Bs", "size": "B2s", "vcpu": 2, "memory": 1, "equivalent": "B2s"},
# # #         "t3.small": {"family": "Bs", "size": "B2s", "vcpu": 2, "memory": 2, "equivalent": "B2s"},
# # #         "t3.medium": {"family": "Bs", "size": "B4ms", "vcpu": 2, "memory": 4, "equivalent": "B4ms"},
# # #         "t3.large": {"family": "Bs", "size": "B8ms", "vcpu": 2, "memory": 8, "equivalent": "B8ms"},
# # #         "t3.xlarge": {"family": "Bs", "size": "B16ms", "vcpu": 4, "memory": 16, "equivalent": "B16ms"},
# # #         "t3.2xlarge": {"family": "Bs", "size": "B32ms", "vcpu": 8, "memory": 32, "equivalent": "B32ms"},
        
# # #         # General purpose - AWS M5 series
# # #         "m5.large": {"family": "D", "size": "D2s v3", "vcpu": 2, "memory": 8, "equivalent": "D2s v3"},
# # #         "m5.xlarge": {"family": "D", "size": "D4s v3", "vcpu": 4, "memory": 16, "equivalent": "D4s v3"},
# # #         "m5.2xlarge": {"family": "D", "size": "D8s v3", "vcpu": 8, "memory": 32, "equivalent": "D8s v3"},
# # #         "m5.4xlarge": {"family": "D", "size": "D16s v3", "vcpu": 16, "memory": 64, "equivalent": "D16s v3"},
# # #         "m5.8xlarge": {"family": "D", "size": "D32s v3", "vcpu": 32, "memory": 128, "equivalent": "D32s v3"},
        
# # #         # Compute optimized - AWS C5 series
# # #         "c5.large": {"family": "F", "size": "F2s v2", "vcpu": 2, "memory": 4, "equivalent": "F2s v2"},
# # #         "c5.xlarge": {"family": "F", "size": "F4s v2", "vcpu": 4, "memory": 8, "equivalent": "F4s v2"},
# # #         "c5.2xlarge": {"family": "F", "size": "F8s v2", "vcpu": 8, "memory": 16, "equivalent": "F8s v2"},
# # #         "c5.4xlarge": {"family": "F", "size": "F16s v2", "vcpu": 16, "memory": 32, "equivalent": "F16s v2"},
        
# # #         # Memory optimized - AWS R5 series
# # #         "r5.large": {"family": "E", "size": "E2s v3", "vcpu": 2, "memory": 16, "equivalent": "E2s v3"},
# # #         "r5.xlarge": {"family": "E", "size": "E4s v3", "vcpu": 4, "memory": 32, "equivalent": "E4s v3"},
# # #         "r5.2xlarge": {"family": "E", "size": "E8s v3", "vcpu": 8, "memory": 64, "equivalent": "E8s v3"},
# # #         "r5.4xlarge": {"family": "E", "size": "E16s v3", "vcpu": 16, "memory": 128, "equivalent": "E16s v3"},
# # #     }
    
# # #     # ===== REGION MAPPING =====
# # #     AWS_TO_AZURE_REGION_MAP = {
# # #         "us-east-1": "eastus",
# # #         "us-east-2": "eastus2",
# # #         "us-west-1": "westus",
# # #         "us-west-2": "westus2",
# # #         "eu-west-1": "westeurope",
# # #         "eu-central-1": "germanywestcentral",
# # #         "ap-southeast-1": "southeastasia",
# # #         "ap-northeast-1": "japaneast",
# # #         "ap-south-1": "centralindia",
# # #         "sa-east-1": "brazilsouth",
# # #     }
    
# # #     def __init__(self, credentials: Optional[Dict] = None, **kwargs):
# # #         subscription_key = None
# # #         if credentials:
# # #             subscription_key = credentials.get('subscription_key')
        
# # #         super().__init__(
# # #             subscription_key=subscription_key,
# # #             base_url="https://prices.azure.com/api/retail/prices",
# # #             **kwargs
# # #         )
        
# # #         if self.subscription_key:
# # #             logger.info("✅ Azure credentials configured for real API calls")
# # #         else:
# # #             logger.info("ℹ️ No Azure credentials, using demo mode")
    
# # #     def _map_aws_instance_to_azure(self, aws_instance: str) -> Dict:
# # #         """Map AWS instance type to equivalent Azure instance"""
# # #         if aws_instance in self.AWS_TO_AZURE_MAP:
# # #             mapping = self.AWS_TO_AZURE_MAP[aws_instance]
# # #             logger.info(f"🔄 Mapped AWS {aws_instance} -> Azure {mapping['equivalent']}")
# # #             return mapping
# # #         else:
# # #             # Default fallback
# # #             logger.warning(f"⚠️ No mapping found for {aws_instance}, using default B2s")
# # #             return {"family": "Bs", "size": "B2s", "equivalent": "B2s"}
    
# # #     def _map_aws_region_to_azure(self, aws_region: str) -> str:
# # #         """Map AWS region to equivalent Azure region"""
# # #         if aws_region in self.AWS_TO_AZURE_REGION_MAP:
# # #             azure_region = self.AWS_TO_AZURE_REGION_MAP[aws_region]
# # #             logger.info(f"🔄 Mapped AWS region {aws_region} -> Azure {azure_region}")
# # #             return azure_region
# # #         return aws_region
    
# # #     def _build_azure_filter(self, service: str, region: str, sku: Optional[str] = None) -> str:
# # #         """
# # #         Build Azure API filter string correctly
# # #         Azure API expects: "serviceName eq 'Virtual Machines' and armRegionName eq 'eastus'"
# # #         """
# # #         filters = []
        
# # #         if service:
# # #             filters.append(f"serviceName eq '{service}'")
        
# # #         if region:
# # #             filters.append(f"armRegionName eq '{region}'")
        
# # #         if sku:
# # #             filters.append(f"armSkuName eq '{sku}'")
        
# # #         return " and ".join(filters)
    
# # #     def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
# # #         """Run the tool with automatic instance mapping"""
# # #         try:
# # #             # Get instance type
# # #             instance_input = specifications.get('instance_type', 'D2s v3')
            
# # #             # Check if it's an AWS instance (contains dot)
# # #             is_aws = '.' in instance_input and not any(x in instance_input for x in ['D', 'E', 'F', 'B'])
            
# # #             if is_aws:
# # #                 logger.info(f"🔍 Detected AWS instance type: {instance_input}")
# # #                 mapping = self._map_aws_instance_to_azure(instance_input)
# # #                 azure_instance = mapping['equivalent']
# # #                 azure_region = self._map_aws_region_to_azure(region)
                
# # #                 specifications = specifications.copy()
# # #                 specifications['instance_type'] = azure_instance
# # #                 specifications['mapped_from_aws'] = instance_input
# # #                 logger.info(f"✅ Using Azure equivalent: {azure_instance} in {azure_region}")
# # #             else:
# # #                 azure_instance = instance_input
# # #                 azure_region = region
            
# # #             # Try to get real pricing
# # #             if self.subscription_key:
# # #                 result = self._get_real_pricing(resource_type, azure_region, specifications, quantity)
# # #             else:
# # #                 result = self._get_demo_pricing(resource_type, azure_region, specifications, quantity)
            
# # #             # Add mapping info if applicable
# # #             if is_aws:
# # #                 result_dict = json.loads(result)
# # #                 result_dict['mapped_from'] = instance_input
# # #                 result_dict['mapping_note'] = f"AWS {instance_input} is equivalent to Azure {azure_instance}"
# # #                 return json.dumps(result_dict, indent=2)
            
# # #             return result
            
# # #         except Exception as e:
# # #             logger.error(f"Error in Azure pricing: {e}")
# # #             return self._get_demo_pricing(resource_type, region, specifications, quantity)
    
# # #     def _get_real_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
# # #         """Get REAL pricing from Azure Retail Prices API"""
# # #         try:
# # #             instance_type = specifications.get('instance_type', 'D2s v3')
            
# # #             logger.info(f"🔍 Looking for Azure VM: {instance_type} in region: {region}")
            
# # #             # Method 1: Try with specific SKU
# # #             filter_str = self._build_azure_filter(
# # #                 service="Virtual Machines",
# # #                 region=region,
# # #                 sku=instance_type
# # #             )
            
# # #             logger.info(f"Filter 1: {filter_str}")
            
# # #             params = {
# # #                 "$filter": filter_str,
# # #                 "api-version": "2023-01-01"
# # #             }
            
# # #             # URL encode the filter
# # #             encoded_params = {k: v for k, v in params.items()}
            
# # #             response = requests.get(
# # #                 self.base_url, 
# # #                 params=encoded_params,
# # #                 timeout=10,
# # #                 headers={
# # #                     "Accept": "application/json",
# # #                     "Content-Type": "application/json"
# # #                 }
# # #             )
            
# # #             logger.info(f"Azure API Response Status: {response.status_code}")
            
# # #             if response.status_code == 200:
# # #                 data = response.json()
# # #                 items = data.get('Items', [])
                
# # #                 if items:
# # #                     logger.info(f"✅ Found {len(items)} matching SKUs")
                    
# # #                     # Get the first matching item
# # #                     item = items[0]
# # #                     retail_price = item.get('retailPrice', 0)
# # #                     unit = item.get('unitOfMeasure', '1 Hour')
                    
# # #                     # Calculate hourly rate
# # #                     if 'Hour' in unit:
# # #                         hourly_rate = retail_price
# # #                     elif 'Month' in unit:
# # #                         hourly_rate = retail_price / 730
# # #                     else:
# # #                         hourly_rate = retail_price
                    
# # #                     monthly_rate = hourly_rate * 730 * quantity
                    
# # #                     result = {
# # #                         "provider": "Azure",
# # #                         "service": "Virtual Machines",
# # #                         "region": region,
# # #                         "instance_type": instance_type,
# # #                         "hourly_rate": round(hourly_rate, 4),
# # #                         "monthly_rate": round(monthly_rate, 2),
# # #                         "currency": "USD",
# # #                         "pricing_model": "Pay-As-You-Go",
# # #                         "data_source": "live_azure_api",
# # #                         "sku": item.get('armSkuName', ''),
# # #                         "product_name": item.get('productName', ''),
# # #                         "meter_name": item.get('meterName', ''),
# # #                         "unit": unit
# # #                     }
                    
# # #                     logger.info(f"✅ Azure live price: ${monthly_rate:.2f}/month")
# # #                     return json.dumps(result, indent=2)
            
# # #             # Method 2: Broader search without SKU
# # #             logger.info("No exact match found, trying broader search...")
            
# # #             filter_str = self._build_azure_filter(
# # #                 service="Virtual Machines",
# # #                 region=region
# # #             )
            
# # #             params = {
# # #                 "$filter": filter_str,
# # #                 "api-version": "2023-01-01"
# # #             }
            
# # #             response = requests.get(self.base_url, params=params, timeout=10)
            
# # #             if response.status_code == 200:
# # #                 data = response.json()
# # #                 items = data.get('Items', [])
                
# # #                 logger.info(f"Found {len(items)} VM SKUs in {region}")
                
# # #                 # Look for partial match
# # #                 for item in items[:20]:  # Check first 20
# # #                     sku_name = item.get('armSkuName', '')
# # #                     product_name = item.get('productName', '')
                    
# # #                     # Check if instance type appears in SKU or product name
# # #                     search_terms = instance_type.lower().split()
# # #                     sku_lower = sku_name.lower()
# # #                     product_lower = product_name.lower()
                    
# # #                     if any(term in sku_lower for term in search_terms) or any(term in product_lower for term in search_terms):
# # #                         retail_price = item.get('retailPrice', 0)
# # #                         unit = item.get('unitOfMeasure', '1 Hour')
                        
# # #                         if 'Hour' in unit:
# # #                             hourly_rate = retail_price
# # #                         elif 'Month' in unit:
# # #                             hourly_rate = retail_price / 730
# # #                         else:
# # #                             hourly_rate = retail_price
                        
# # #                         monthly_rate = hourly_rate * 730 * quantity
                        
# # #                         result = {
# # #                             "provider": "Azure",
# # #                             "service": "Virtual Machines",
# # #                             "region": region,
# # #                             "instance_type": instance_type,
# # #                             "hourly_rate": round(hourly_rate, 4),
# # #                             "monthly_rate": round(monthly_rate, 2),
# # #                             "currency": "USD",
# # #                             "pricing_model": "Pay-As-You-Go",
# # #                             "data_source": "live_azure_api",
# # #                             "sku": sku_name,
# # #                             "notes": f"Matched based on {sku_name}"
# # #                         }
                        
# # #                         logger.info(f"✅ Found via partial match: ${monthly_rate:.2f}/month")
# # #                         return json.dumps(result, indent=2)
            
# # #             # If all else fails, return demo data
# # #             logger.warning("⚠️ No Azure price found, using demo data")
# # #             return self._get_demo_pricing(resource_type, region, specifications, quantity)
            
# # #         except requests.exceptions.RequestException as e:
# # #             logger.error(f"❌ Azure API request failed: {e}")
# # #             return self._get_demo_pricing(resource_type, region, specifications, quantity)
# # #         except Exception as e:
# # #             logger.error(f"❌ Error in Azure real pricing: {e}")
# # #             return self._get_demo_pricing(resource_type, region, specifications, quantity)
    
# # #     def _get_demo_pricing(self, resource_type: str, region: str, specifications: Dict, quantity: int) -> str:
# # #         """Return demo pricing data"""
# # #         instance_type = specifications.get('instance_type', 'D2s v3')
        
# # #         # Demo pricing map
# # #         demo_prices = {
# # #             'B2s': 0.0416,
# # #             'B4ms': 0.166,
# # #             'D2s v3': 0.096,
# # #             'D4s v3': 0.192,
# # #             'D8s v3': 0.384,
# # #             'F2s v2': 0.084,
# # #             'F4s v2': 0.168,
# # #             'E2s v3': 0.146,
# # #             'E4s v3': 0.292,
# # #         }
        
# # #         hourly_rate = demo_prices.get(instance_type, 0.096)
# # #         monthly_rate = hourly_rate * 730 * quantity
        
# # #         result = {
# # #             "provider": "Azure",
# # #             "service": "Virtual Machines",
# # #             "region": region,
# # #             "instance_type": instance_type,
# # #             "hourly_rate": round(hourly_rate, 4),
# # #             "monthly_rate": round(monthly_rate, 2),
# # #             "currency": "USD",
# # #             "pricing_model": "Pay-As-You-Go",
# # #             "notes": "DEMO pricing data - Set Azure subscription key for real prices",
# # #             "mode": "demo"
# # #         }
        
# # #         logger.info(f"ℹ️ Azure demo price: ${monthly_rate:.2f}/month")
# # #         return json.dumps(result, indent=2)
    
# # #     async def _arun(self, *args, **kwargs):
# # #         """Async version not implemented"""
# # #         return self._run(*args, **kwargs)

# # """
# # Azure Pricing Tool for Cloud Rationalization Agent
# # Simplest working version - no API version needed
# # """
# # from langchain.tools import BaseTool
# # from typing import Dict, Optional, Type
# # from pydantic import BaseModel, Field, ConfigDict
# # import requests
# # import json
# # import logging

# # logger = logging.getLogger(__name__)

# # class AzurePricingInput(BaseModel):
# #     """Input schema for Azure pricing tool"""
# #     resource_type: str = Field(description="Type of resource (VM, Storage, SQL, etc.)")
# #     region: str = Field(description="Azure region (eastus, westeurope, etc.)")
# #     specifications: Dict = Field(description="Resource specifications")
# #     quantity: int = Field(default=1, description="Number of instances")

# # class AzurePricingTool(BaseTool):
# #     """Tool for getting Azure pricing information"""
    
# #     name: str = "azure_pricing_tool"
# #     description: str = "Get real-time Azure pricing for VMs"
# #     args_schema: Type[BaseModel] = AzurePricingInput
    
# #     base_url: str = Field(default="https://prices.azure.com/api/retail/prices")
    
# #     model_config = ConfigDict(arbitrary_types_allowed=True)
    
# #     # AWS to Azure instance mapping
# #     AWS_TO_AZURE_MAP = {
# #         "t3.micro": "B2s",
# #         "t3.small": "B2s",
# #         "t3.medium": "B4ms",
# #         "t3.large": "B8ms",
# #         "m5.large": "D2s v3",
# #         "m5.xlarge": "D4s v3",
# #         "c5.large": "F2s v2",
# #         "c5.xlarge": "F4s v2",
# #         "r5.large": "E2s v3",
# #     }
    
# #     AWS_TO_AZURE_REGION = {
# #         "us-east-1": "eastus",
# #         "us-west-2": "westus2",
# #         "eu-west-1": "westeurope",
# #     }
    
# #     def __init__(self, credentials: Optional[Dict] = None, **kwargs):
# #         super().__init__(**kwargs)
    
# #     def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
# #         """Run the tool"""
# #         try:
# #             instance_input = specifications.get('instance_type', 'D2s v3')
            
# #             # Map AWS instance to Azure if needed
# #             if '.' in instance_input and instance_input in self.AWS_TO_AZURE_MAP:
# #                 azure_instance = self.AWS_TO_AZURE_MAP[instance_input]
# #                 logger.info(f"Mapped AWS {instance_input} -> Azure {azure_instance}")
# #             else:
# #                 azure_instance = instance_input
            
# #             # Map AWS region to Azure if needed
# #             if region in self.AWS_TO_AZURE_REGION:
# #                 azure_region = self.AWS_TO_AZURE_REGION[region]
# #             else:
# #                 azure_region = region
            
# #             # SIMPLE: Just get all prices (no filters, no API version)
# #             response = requests.get(
# #                 self.base_url,
# #                 timeout=10
# #             )
            
# #             if response.status_code == 200:
# #                 data = response.json()
# #                 items = data.get('Items', [])
                
# #                 # Filter for VMs in the right region
# #                 vm_prices = []
# #                 for item in items:
# #                     if (item.get('serviceName') == 'Virtual Machines' and 
# #                         item.get('armRegionName') == azure_region):
# #                         vm_prices.append(item)
                
# #                 # Find our instance
# #                 for item in vm_prices:
# #                     sku = item.get('armSkuName', '')
# #                     if azure_instance.lower() in sku.lower():
# #                         price = item.get('retailPrice', 0)
# #                         unit = item.get('unitOfMeasure', '1 Hour')
                        
# #                         # Calculate hourly rate
# #                         if 'Hour' in unit:
# #                             hourly = price
# #                         elif 'Month' in unit:
# #                             hourly = price / 730
# #                         else:
# #                             hourly = price
                        
# #                         monthly = hourly * 730 * quantity
                        
# #                         result = {
# #                             "provider": "Azure",
# #                             "region": azure_region,
# #                             "instance_type": azure_instance,
# #                             "hourly_rate": round(hourly, 4),
# #                             "monthly_rate": round(monthly, 2),
# #                             "currency": "USD",
# #                             "original_instance": instance_input if instance_input != azure_instance else None,
# #                             "data_source": "live"
# #                         }
                        
# #                         return json.dumps(result, indent=2)
                
# #                 # If instance not found, show available ones
# #                 if vm_prices:
# #                     available = [item.get('armSkuName') for item in vm_prices[:5]]
# #                     return json.dumps({
# #                         "provider": "Azure",
# #                         "region": azure_region,
# #                         "error": f"Instance {azure_instance} not found",
# #                         "available_instances": available,
# #                         "data_source": "live_but_no_match"
# #                     }, indent=2)
            
# #             # Fallback to demo
# #             return json.dumps({
# #                 "provider": "Azure",
# #                 "region": region,
# #                 "instance_type": azure_instance,
# #                 "hourly_rate": 0.096,
# #                 "monthly_rate": 70.08,
# #                 "currency": "USD",
# #                 "data_source": "demo",
# #                 "note": "Using demo data"
# #             }, indent=2)
            
# #         except Exception as e:
# #             logger.error(f"Error: {e}")
# #             return json.dumps({
# #                 "provider": "Azure",
# #                 "error": str(e),
# #                 "demo_price": 70.08
# #             }, indent=2)


# """
# Azure Pricing Tool for Cloud Rationalization Agent
# Complete version with all AWS mappings and ultra-simple working API
# """
# from langchain.tools import BaseTool
# from typing import Dict, Optional, Type
# from pydantic import BaseModel, Field, ConfigDict
# import requests
# import json
# import logging

# logger = logging.getLogger(__name__)

# class AzurePricingInput(BaseModel):
#     """Input schema for Azure pricing tool"""
#     resource_type: str = Field(description="Type of resource (VM, Storage, SQL, etc.)")
#     region: str = Field(description="Azure region (eastus, westeurope, etc.)")
#     specifications: Dict = Field(description="Resource specifications")
#     quantity: int = Field(default=1, description="Number of instances")

# class AzurePricingTool(BaseTool):
#     """Tool for getting Azure pricing information with complete AWS mapping"""
    
#     name: str = "azure_pricing_tool"
#     description: str = """
#     Get real-time Azure pricing for VMs.
#     Automatically maps AWS instance types to equivalent Azure instances.
#     Supports: t3.micro -> B2s, t3.medium -> B4ms, m5.large -> D2s v3, etc.
#     """
#     args_schema: Type[BaseModel] = AzurePricingInput
    
#     # FIX: Properly define base_url with type and default
#     base_url: str = Field(
#         default="https://prices.azure.com/api/retail/prices",
#         description="Azure Retail Prices API URL"
#     )
    
#     model_config = ConfigDict(arbitrary_types_allowed=True)
    
#     # ===== COMPLETE AWS TO AZURE INSTANCE MAPPING =====
#     AWS_TO_AZURE_MAP = {
#         # General purpose - AWS T3 series (burstable)
#         "t3.nano": "B2s",
#         "t3.micro": "B2s",
#         "t3.small": "B2s",
#         "t3.medium": "B4ms",
#         "t3.large": "B8ms",
#         "t3.xlarge": "B16ms",
#         "t3.2xlarge": "B32ms",
        
#         # General purpose - AWS T4g series (Graviton)
#         "t4g.nano": "B2s",
#         "t4g.micro": "B2s",
#         "t4g.small": "B2s",
#         "t4g.medium": "B4ms",
#         "t4g.large": "B8ms",
#         "t4g.xlarge": "B16ms",
#         "t4g.2xlarge": "B32ms",
        
#         # General purpose - AWS M5 series (balanced)
#         "m5.large": "D2s v3",
#         "m5.xlarge": "D4s v3",
#         "m5.2xlarge": "D8s v3",
#         "m5.4xlarge": "D16s v3",
#         "m5.8xlarge": "D32s v3",
#         "m5.12xlarge": "D48s v3",
#         "m5.16xlarge": "D64s v3",
#         "m5.24xlarge": "D64s v3",
        
#         # General purpose - AWS M6g series (Graviton)
#         "m6g.large": "D2s v3",
#         "m6g.xlarge": "D4s v3",
#         "m6g.2xlarge": "D8s v3",
#         "m6g.4xlarge": "D16s v3",
#         "m6g.8xlarge": "D32s v3",
#         "m6g.12xlarge": "D48s v3",
#         "m6g.16xlarge": "D64s v3",
        
#         # Compute optimized - AWS C5 series
#         "c5.large": "F2s v2",
#         "c5.xlarge": "F4s v2",
#         "c5.2xlarge": "F8s v2",
#         "c5.4xlarge": "F16s v2",
#         "c5.9xlarge": "F36s v2",
#         "c5.12xlarge": "F48s v2",
#         "c5.18xlarge": "F72s v2",
#         "c5.24xlarge": "F72s v2",
        
#         # Compute optimized - AWS C6g series (Graviton)
#         "c6g.medium": "F2s v2",
#         "c6g.large": "F4s v2",
#         "c6g.xlarge": "F8s v2",
#         "c6g.2xlarge": "F16s v2",
#         "c6g.4xlarge": "F32s v2",
#         "c6g.8xlarge": "F64s v2",
#         "c6g.12xlarge": "F72s v2",
#         "c6g.16xlarge": "F72s v2",
        
#         # Compute optimized - AWS C5n series (network optimized)
#         "c5n.large": "F4s v2",
#         "c5n.xlarge": "F8s v2",
#         "c5n.2xlarge": "F16s v2",
#         "c5n.4xlarge": "F32s v2",
#         "c5n.9xlarge": "F72s v2",
#         "c5n.18xlarge": "F72s v2",
        
#         # Memory optimized - AWS R5 series
#         "r5.large": "E2s v3",
#         "r5.xlarge": "E4s v3",
#         "r5.2xlarge": "E8s v3",
#         "r5.4xlarge": "E16s v3",
#         "r5.8xlarge": "E32s v3",
#         "r5.12xlarge": "E48s v3",
#         "r5.16xlarge": "E64s v3",
#         "r5.24xlarge": "E64s v3",
        
#         # Memory optimized - AWS R6g series (Graviton)
#         "r6g.medium": "E2s v3",
#         "r6g.large": "E4s v3",
#         "r6g.xlarge": "E8s v3",
#         "r6g.2xlarge": "E16s v3",
#         "r6g.4xlarge": "E32s v3",
#         "r6g.8xlarge": "E64s v3",
#         "r6g.12xlarge": "E64s v3",
#         "r6g.16xlarge": "E64s v3",
        
#         # Memory optimized - AWS X1 series (large memory)
#         "x1.16xlarge": "E64s v3",
#         "x1.32xlarge": "E64s v3",
#         "x1e.xlarge": "E20s v3",
#         "x1e.2xlarge": "E20s v3",
#         "x1e.4xlarge": "E20s v3",
#         "x1e.8xlarge": "E20s v3",
#         "x1e.16xlarge": "E64s v3",
#         "x1e.32xlarge": "E64s v3",
        
#         # Storage optimized - AWS I3 series
#         "i3.large": "L4s",
#         "i3.xlarge": "L8s",
#         "i3.2xlarge": "L16s",
#         "i3.4xlarge": "L32s",
#         "i3.8xlarge": "L64s",
#         "i3.16xlarge": "L80s",
        
#         # Storage optimized - AWS I3en series
#         "i3en.large": "L8s v2",
#         "i3en.xlarge": "L16s v2",
#         "i3en.2xlarge": "L32s v2",
#         "i3en.3xlarge": "L48s v2",
#         "i3en.4xlarge": "L64s v2",
#         "i3en.6xlarge": "L80s v2",
#         "i3en.8xlarge": "L80s v2",
#         "i3en.12xlarge": "L80s v2",
        
#         # GPU instances - AWS G4 series (T4 GPUs)
#         "g4dn.xlarge": "NC6s v3",
#         "g4dn.2xlarge": "NC12s v3",
#         "g4dn.4xlarge": "NC24s v3",
#         "g4dn.8xlarge": "NC48s v3",
#         "g4dn.12xlarge": "NC64s v3",
#         "g4dn.16xlarge": "NC64s v3",
        
#         # GPU instances - AWS G5 series (A10G GPUs)
#         "g5.xlarge": "NC24s v3",
#         "g5.2xlarge": "NC48s v3",
#         "g5.4xlarge": "NC64s v3",
#         "g5.8xlarge": "NC64s v3",
#         "g5.12xlarge": "NC64s v3",
#         "g5.16xlarge": "NC64s v3",
#         "g5.24xlarge": "NC64s v3",
#         "g5.48xlarge": "NC64s v3",
        
#         # GPU instances - AWS P3 series (V100 GPUs)
#         "p3.2xlarge": "NC24s v3",
#         "p3.8xlarge": "NC48s v3",
#         "p3.16xlarge": "NC96s v3",
        
#         # GPU instances - AWS P4 series (A100 GPUs)
#         "p4d.24xlarge": "NC96s v3",
        
#         # GPU instances - AWS Inf1 series (Inferentia)
#         "inf1.xlarge": "NC6s v3",
#         "inf1.2xlarge": "NC12s v3",
#         "inf1.6xlarge": "NC24s v3",
#         "inf1.24xlarge": "NC96s v3",
#     }
    
#     # ===== COMPLETE AWS TO AZURE REGION MAPPING =====
#     AWS_TO_AZURE_REGION_MAP = {
#         # US Regions
#         "us-east-1": "eastus",
#         "us-east-2": "eastus2",
#         "us-west-1": "westus",
#         "us-west-2": "westus2",
#         "us-gov-west-1": "usgovarizona",
#         "us-gov-east-1": "usgovvirginia",
        
#         # EU Regions
#         "eu-west-1": "westeurope",
#         "eu-west-2": "uksouth",
#         "eu-west-3": "francecentral",
#         "eu-central-1": "germanywestcentral",
#         "eu-north-1": "northeurope",
#         "eu-south-1": "italynorth",
        
#         # Asia Pacific Regions
#         "ap-southeast-1": "southeastasia",
#         "ap-southeast-2": "australiaeast",
#         "ap-southeast-3": "jioindiacentral",
#         "ap-northeast-1": "japaneast",
#         "ap-northeast-2": "koreacentral",
#         "ap-northeast-3": "japanwest",
#         "ap-south-1": "centralindia",
#         "ap-south-2": "southindia",
#         "ap-east-1": "eastasia",
        
#         # South America
#         "sa-east-1": "brazilsouth",
        
#         # Canada
#         "ca-central-1": "canadacentral",
        
#         # Africa
#         "af-south-1": "southafricanorth",
        
#         # Middle East
#         "me-south-1": "uaenorth",
#         "me-central-1": "qatarcentral",
#     }
    
#     def __init__(self, credentials: Optional[Dict] = None, **kwargs):
#         super().__init__(**kwargs)
#         logger.info(f"✅ Azure Pricing Tool initialized with {len(self.AWS_TO_AZURE_MAP)} instance mappings")
    
#     def _map_aws_instance_to_azure(self, aws_instance: str) -> str:
#         """Map AWS instance type to equivalent Azure instance"""
#         if aws_instance in self.AWS_TO_AZURE_MAP:
#             azure_instance = self.AWS_TO_AZURE_MAP[aws_instance]
#             logger.info(f"🔄 Mapped AWS {aws_instance} -> Azure {azure_instance}")
#             return azure_instance
        
#         # Try family-based matching (e.g., t3.medium -> t3 family)
#         family = aws_instance.split('.')[0]
#         for key, value in self.AWS_TO_AZURE_MAP.items():
#             if key.startswith(family):
#                 logger.info(f"🔄 Family match: AWS {aws_instance} -> Azure {value} (based on {key})")
#                 return value
        
#         logger.warning(f"⚠️ No mapping found for {aws_instance}, using default D2s v3")
#         return "D2s v3"
    
#     def _map_aws_region_to_azure(self, aws_region: str) -> str:
#         """Map AWS region to equivalent Azure region"""
#         if aws_region in self.AWS_TO_AZURE_REGION_MAP:
#             azure_region = self.AWS_TO_AZURE_REGION_MAP[aws_region]
#             logger.info(f"🔄 Mapped AWS region {aws_region} -> Azure {azure_region}")
#             return azure_region
#         logger.info(f"Using region {aws_region} as-is")
#         return aws_region
    
#     def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
#         """Run the tool with complete AWS mapping support"""
#         try:
#             instance_input = specifications.get('instance_type', 'D2s v3')
            
#             # Check if it's an AWS instance (contains dot)
#             is_aws = '.' in instance_input
            
#             # Apply mappings if it's an AWS instance
#             if is_aws:
#                 azure_instance = self._map_aws_instance_to_azure(instance_input)
#                 azure_region = self._map_aws_region_to_azure(region)
#                 logger.info(f"✅ Using Azure equivalent: {azure_instance} in {azure_region}")
#             else:
#                 azure_instance = instance_input
#                 azure_region = region
            
#             # Make simple API call - no filters, no API version
#             logger.info(f"Fetching Azure prices from {self.base_url}")
#             response = requests.get(self.base_url, timeout=10)
            
#             if response.status_code == 200:
#                 data = response.json()
#                 all_items = data.get('Items', [])
#                 logger.info(f"Retrieved {len(all_items)} total price items")
                
#                 # Filter for VMs in the target region
#                 vm_prices = []
#                 for item in all_items:
#                     service = item.get('serviceName', '')
#                     item_region = item.get('armRegionName', '')
#                     if service == 'Virtual Machines' and item_region == azure_region:
#                         vm_prices.append(item)
                
#                 logger.info(f"Found {len(vm_prices)} VM SKUs in {azure_region}")
                
#                 # Find exact match for our instance
#                 for item in vm_prices:
#                     sku = item.get('armSkuName', '')
#                     if azure_instance.lower() in sku.lower():
#                         price = item.get('retailPrice', 0)
#                         unit = item.get('unitOfMeasure', '1 Hour')
                        
#                         # Calculate hourly rate based on unit
#                         if 'Hour' in unit:
#                             hourly = price
#                         elif 'Month' in unit:
#                             hourly = price / 730
#                         else:
#                             hourly = price
                        
#                         monthly = hourly * 730 * quantity
                        
#                         result = {
#                             "provider": "Azure",
#                             "service": "Virtual Machines",
#                             "region": azure_region,
#                             "instance_type": azure_instance,
#                             "hourly_rate": round(hourly, 4),
#                             "monthly_rate": round(monthly, 2),
#                             "currency": "USD",
#                             "pricing_model": "Pay-As-You-Go",
#                             "data_source": "live_azure_api",
#                             "sku": sku,
#                             "unit": unit,
#                             "mapped_from": instance_input if is_aws else None
#                         }
                        
#                         logger.info(f"✅ Azure live price found: ${monthly:.2f}/month")
#                         return json.dumps(result, indent=2)
                
#                 # No exact match found - show available instances in region
#                 if vm_prices:
#                     available_instances = list(set([item.get('armSkuName', '') for item in vm_prices[:20]]))
#                     available_instances.sort()
                    
#                     logger.warning(f"⚠️ Instance {azure_instance} not found in {azure_region}")
#                     return json.dumps({
#                         "provider": "Azure",
#                         "region": azure_region,
#                         "instance_type": azure_instance,
#                         "error": f"Instance not found in {azure_region}",
#                         "available_instances": available_instances[:10],
#                         "mapped_from": instance_input if is_aws else None,
#                         "data_source": "live_but_no_match"
#                     }, indent=2)
#                 else:
#                     logger.warning(f"⚠️ No VM SKUs found in region {azure_region}")
            
#             # Fallback to demo data
#             logger.warning("Using demo data as fallback")
#             return self._get_demo_pricing(azure_region, azure_instance, quantity, instance_input if is_aws else None)
            
#         except requests.exceptions.RequestException as e:
#             logger.error(f"❌ Azure API request failed: {e}")
#             return self._get_demo_pricing(region, specifications.get('instance_type', 'D2s v3'), quantity, None)
#         except Exception as e:
#             logger.error(f"❌ Error in Azure pricing: {e}")
#             return self._get_demo_pricing(region, specifications.get('instance_type', 'D2s v3'), quantity, None)
    
#     def _get_demo_pricing(self, region: str, instance_type: str, quantity: int, original_instance: Optional[str] = None) -> str:
#         """Return demo pricing data with mapping info"""
#         # Demo pricing map for common Azure instances
#         demo_prices = {
#             'B2s': 0.0416,
#             'B4ms': 0.166,
#             'B8ms': 0.332,
#             'D2s v3': 0.096,
#             'D4s v3': 0.192,
#             'D8s v3': 0.384,
#             'D16s v3': 0.768,
#             'D32s v3': 1.536,
#             'D48s v3': 2.304,
#             'D64s v3': 3.072,
#             'F2s v2': 0.084,
#             'F4s v2': 0.168,
#             'F8s v2': 0.336,
#             'F16s v2': 0.672,
#             'F32s v2': 1.344,
#             'F48s v2': 2.016,
#             'F64s v2': 2.688,
#             'F72s v2': 3.024,
#             'E2s v3': 0.146,
#             'E4s v3': 0.292,
#             'E8s v3': 0.584,
#             'E16s v3': 1.168,
#             'E20s v3': 1.460,
#             'E32s v3': 2.336,
#             'E48s v3': 3.504,
#             'E64s v3': 4.672,
#             'NC6s v3': 3.06,
#             'NC12s v3': 6.12,
#             'NC24s v3': 12.24,
#             'NC48s v3': 24.48,
#             'NC64s v3': 32.64,
#             'NC96s v3': 48.96,
#         }
        
#         hourly = demo_prices.get(instance_type, 0.096)
#         monthly = hourly * 730 * quantity
        
#         result = {
#             "provider": "Azure",
#             "region": region,
#             "instance_type": instance_type,
#             "hourly_rate": round(hourly, 4),
#             "monthly_rate": round(monthly, 2),
#             "currency": "USD",
#             "pricing_model": "Pay-As-You-Go (Demo)",
#             "data_source": "demo",
#             "note": "Using demo pricing data - Azure API unavailable"
#         }
        
#         if original_instance:
#             result["mapped_from"] = original_instance
#             result["mapping_note"] = f"AWS {original_instance} → Azure {instance_type}"
        
#         logger.info(f"ℹ️ Azure demo price: ${monthly:.2f}/month")
#         logger.info(f"ℹ️ Azure demo price: ${monthly:.2f}/month")
#         return json.dumps(result, indent=2)
    
#     async def _arun(self, *args, **kwargs):
#         """Async version not implemented"""
#         return self._run(*args, **kwargs) 

# """
# Azure Pricing Tool for Cloud Rationalization Agent
# Complete version with all AWS mappings and working Pydantic v2 syntax
# """
# from langchain.tools import BaseTool
# from typing import Dict, Optional, Type, Any
# from pydantic import BaseModel, Field, ConfigDict
# import requests
# import json
# import logging

# logger = logging.getLogger(__name__)

# class AzurePricingInput(BaseModel):
#     """Input schema for Azure pricing tool"""
#     resource_type: str = Field(description="Type of resource")
#     region: str = Field(description="Azure region")
#     specifications: Dict[str, Any] = Field(default_factory=dict)
#     quantity: int = Field(default=1)

# class AzurePricingTool(BaseTool):
#     """Tool for getting Azure pricing information with complete AWS mapping"""
    
#     name: str = "azure_pricing_tool"
#     description: str = """
#     Get real-time Azure pricing for VMs.
#     Automatically maps AWS instance types to equivalent Azure instances.
#     Supports 100+ instance types across T3, M5, C5, R5, G4, etc.
#     """
#     args_schema: Type[BaseModel] = AzurePricingInput
    
#     # Simple field definition - works with Pydantic v2
#     base_url: str = "https://prices.azure.com/api/retail/prices"
    
#     model_config = ConfigDict(arbitrary_types_allowed=True)
    
#     # ===== COMPLETE AWS TO AZURE INSTANCE MAPPING =====
#     AWS_TO_AZURE_MAP = {
#         # General purpose - AWS T3 series (burstable)
#         "t3.nano": "B2s",
#         "t3.micro": "B2s",
#         "t3.small": "B2s",
#         "t3.medium": "B4ms",
#         "t3.large": "B8ms",
#         "t3.xlarge": "B16ms",
#         "t3.2xlarge": "B32ms",
        
#         # General purpose - AWS T4g series (Graviton)
#         "t4g.nano": "B2s",
#         "t4g.micro": "B2s",
#         "t4g.small": "B2s",
#         "t4g.medium": "B4ms",
#         "t4g.large": "B8ms",
#         "t4g.xlarge": "B16ms",
#         "t4g.2xlarge": "B32ms",
        
#         # General purpose - AWS M5 series (balanced)
#         "m5.large": "D2s v3",
#         "m5.xlarge": "D4s v3",
#         "m5.2xlarge": "D8s v3",
#         "m5.4xlarge": "D16s v3",
#         "m5.8xlarge": "D32s v3",
#         "m5.12xlarge": "D48s v3",
#         "m5.16xlarge": "D64s v3",
#         "m5.24xlarge": "D64s v3",
        
#         # General purpose - AWS M6g series (Graviton)
#         "m6g.large": "D2s v3",
#         "m6g.xlarge": "D4s v3",
#         "m6g.2xlarge": "D8s v3",
#         "m6g.4xlarge": "D16s v3",
#         "m6g.8xlarge": "D32s v3",
#         "m6g.12xlarge": "D48s v3",
#         "m6g.16xlarge": "D64s v3",
        
#         # Compute optimized - AWS C5 series
#         "c5.large": "F2s v2",
#         "c5.xlarge": "F4s v2",
#         "c5.2xlarge": "F8s v2",
#         "c5.4xlarge": "F16s v2",
#         "c5.9xlarge": "F36s v2",
#         "c5.12xlarge": "F48s v2",
#         "c5.18xlarge": "F72s v2",
#         "c5.24xlarge": "F72s v2",
        
#         # Compute optimized - AWS C6g series (Graviton)
#         "c6g.medium": "F2s v2",
#         "c6g.large": "F4s v2",
#         "c6g.xlarge": "F8s v2",
#         "c6g.2xlarge": "F16s v2",
#         "c6g.4xlarge": "F32s v2",
#         "c6g.8xlarge": "F64s v2",
#         "c6g.12xlarge": "F72s v2",
#         "c6g.16xlarge": "F72s v2",
        
#         # Compute optimized - AWS C5n series (network optimized)
#         "c5n.large": "F4s v2",
#         "c5n.xlarge": "F8s v2",
#         "c5n.2xlarge": "F16s v2",
#         "c5n.4xlarge": "F32s v2",
#         "c5n.9xlarge": "F72s v2",
#         "c5n.18xlarge": "F72s v2",
        
#         # Memory optimized - AWS R5 series
#         "r5.large": "E2s v3",
#         "r5.xlarge": "E4s v3",
#         "r5.2xlarge": "E8s v3",
#         "r5.4xlarge": "E16s v3",
#         "r5.8xlarge": "E32s v3",
#         "r5.12xlarge": "E48s v3",
#         "r5.16xlarge": "E64s v3",
#         "r5.24xlarge": "E64s v3",
        
#         # Memory optimized - AWS R6g series (Graviton)
#         "r6g.medium": "E2s v3",
#         "r6g.large": "E4s v3",
#         "r6g.xlarge": "E8s v3",
#         "r6g.2xlarge": "E16s v3",
#         "r6g.4xlarge": "E32s v3",
#         "r6g.8xlarge": "E64s v3",
#         "r6g.12xlarge": "E64s v3",
#         "r6g.16xlarge": "E64s v3",
        
#         # Memory optimized - AWS X1 series (large memory)
#         "x1.16xlarge": "E64s v3",
#         "x1.32xlarge": "E64s v3",
#         "x1e.xlarge": "E20s v3",
#         "x1e.2xlarge": "E20s v3",
#         "x1e.4xlarge": "E20s v3",
#         "x1e.8xlarge": "E20s v3",
#         "x1e.16xlarge": "E64s v3",
#         "x1e.32xlarge": "E64s v3",
        
#         # Storage optimized - AWS I3 series
#         "i3.large": "L4s",
#         "i3.xlarge": "L8s",
#         "i3.2xlarge": "L16s",
#         "i3.4xlarge": "L32s",
#         "i3.8xlarge": "L64s",
#         "i3.16xlarge": "L80s",
        
#         # Storage optimized - AWS I3en series
#         "i3en.large": "L8s v2",
#         "i3en.xlarge": "L16s v2",
#         "i3en.2xlarge": "L32s v2",
#         "i3en.3xlarge": "L48s v2",
#         "i3en.4xlarge": "L64s v2",
#         "i3en.6xlarge": "L80s v2",
#         "i3en.8xlarge": "L80s v2",
#         "i3en.12xlarge": "L80s v2",
        
#         # GPU instances - AWS G4 series (T4 GPUs)
#         "g4dn.xlarge": "NC6s v3",
#         "g4dn.2xlarge": "NC12s v3",
#         "g4dn.4xlarge": "NC24s v3",
#         "g4dn.8xlarge": "NC48s v3",
#         "g4dn.12xlarge": "NC64s v3",
#         "g4dn.16xlarge": "NC64s v3",
        
#         # GPU instances - AWS G5 series (A10G GPUs)
#         "g5.xlarge": "NC24s v3",
#         "g5.2xlarge": "NC48s v3",
#         "g5.4xlarge": "NC64s v3",
#         "g5.8xlarge": "NC64s v3",
#         "g5.12xlarge": "NC64s v3",
#         "g5.16xlarge": "NC64s v3",
#         "g5.24xlarge": "NC64s v3",
#         "g5.48xlarge": "NC64s v3",
        
#         # GPU instances - AWS P3 series (V100 GPUs)
#         "p3.2xlarge": "NC24s v3",
#         "p3.8xlarge": "NC48s v3",
#         "p3.16xlarge": "NC96s v3",
        
#         # GPU instances - AWS P4 series (A100 GPUs)
#         "p4d.24xlarge": "NC96s v3",
        
#         # GPU instances - AWS Inf1 series (Inferentia)
#         "inf1.xlarge": "NC6s v3",
#         "inf1.2xlarge": "NC12s v3",
#         "inf1.6xlarge": "NC24s v3",
#         "inf1.24xlarge": "NC96s v3",
#     }
    
#     # ===== COMPLETE AWS TO AZURE REGION MAPPING =====
#     AWS_TO_AZURE_REGION_MAP = {
#         # US Regions
#         "us-east-1": "eastus",
#         "us-east-2": "eastus2",
#         "us-west-1": "westus",
#         "us-west-2": "westus2",
#         "us-gov-west-1": "usgovarizona",
#         "us-gov-east-1": "usgovvirginia",
        
#         # EU Regions
#         "eu-west-1": "westeurope",
#         "eu-west-2": "uksouth",
#         "eu-west-3": "francecentral",
#         "eu-central-1": "germanywestcentral",
#         "eu-north-1": "northeurope",
#         "eu-south-1": "italynorth",
        
#         # Asia Pacific Regions
#         "ap-southeast-1": "southeastasia",
#         "ap-southeast-2": "australiaeast",
#         "ap-southeast-3": "jioindiacentral",
#         "ap-northeast-1": "japaneast",
#         "ap-northeast-2": "koreacentral",
#         "ap-northeast-3": "japanwest",
#         "ap-south-1": "centralindia",
#         "ap-south-2": "southindia",
#         "ap-east-1": "eastasia",
        
#         # South America
#         "sa-east-1": "brazilsouth",
        
#         # Canada
#         "ca-central-1": "canadacentral",
        
#         # Africa
#         "af-south-1": "southafricanorth",
        
#         # Middle East
#         "me-south-1": "uaenorth",
#         "me-central-1": "qatarcentral",
#     }
    
#     def __init__(self, credentials: Optional[Dict] = None, **kwargs):
#         super().__init__(**kwargs)
#         logger.info(f"✅ Azure Pricing Tool initialized with {len(self.AWS_TO_AZURE_MAP)} instance mappings")
    
#     def _map_aws_instance_to_azure(self, aws_instance: str) -> str:
#         """Map AWS instance type to equivalent Azure instance"""
#         if aws_instance in self.AWS_TO_AZURE_MAP:
#             azure_instance = self.AWS_TO_AZURE_MAP[aws_instance]
#             logger.info(f"🔄 Mapped AWS {aws_instance} -> Azure {azure_instance}")
#             return azure_instance
        
#         # Try family-based matching (e.g., t3.medium -> t3 family)
#         family = aws_instance.split('.')[0]
#         for key, value in self.AWS_TO_AZURE_MAP.items():
#             if key.startswith(family):
#                 logger.info(f"🔄 Family match: AWS {aws_instance} -> Azure {value} (based on {key})")
#                 return value
        
#         logger.warning(f"⚠️ No mapping found for {aws_instance}, using default D2s v3")
#         return "D2s v3"
    
#     def _map_aws_region_to_azure(self, aws_region: str) -> str:
#         """Map AWS region to equivalent Azure region"""
#         if aws_region in self.AWS_TO_AZURE_REGION_MAP:
#             azure_region = self.AWS_TO_AZURE_REGION_MAP[aws_region]
#             logger.info(f"🔄 Mapped AWS region {aws_region} -> Azure {azure_region}")
#             return azure_region
#         logger.info(f"Using region {aws_region} as-is")
#         return aws_region
    
#     def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
#         """Run the tool with complete AWS mapping support"""
#         try:
#             instance_input = specifications.get('instance_type', 'D2s v3')
            
#             # Check if it's an AWS instance (contains dot)
#             is_aws = '.' in instance_input
            
#             # Apply mappings if it's an AWS instance
#             if is_aws:
#                 azure_instance = self._map_aws_instance_to_azure(instance_input)
#                 azure_region = self._map_aws_region_to_azure(region)
#                 logger.info(f"✅ Using Azure equivalent: {azure_instance} in {azure_region}")
#             else:
#                 azure_instance = instance_input
#                 azure_region = region
            
#             # Make simple API call - no filters, no API version
#             logger.info(f"Fetching Azure prices from {self.base_url}")
#             response = requests.get(self.base_url, timeout=10)
            
#             if response.status_code == 200:
#                 data = response.json()
#                 all_items = data.get('Items', [])
#                 logger.info(f"Retrieved {len(all_items)} total price items")
                
#                 # Filter for VMs in the target region
#                 vm_prices = []
#                 for item in all_items:
#                     service = item.get('serviceName', '')
#                     item_region = item.get('armRegionName', '')
#                     if service == 'Virtual Machines' and item_region == azure_region:
#                         vm_prices.append(item)
                
#                 logger.info(f"Found {len(vm_prices)} VM SKUs in {azure_region}")
                
#                 # Find exact match for our instance
#                 for item in vm_prices:
#                     sku = item.get('armSkuName', '')
#                     if azure_instance.lower() in sku.lower():
#                         price = item.get('retailPrice', 0)
#                         unit = item.get('unitOfMeasure', '1 Hour')
                        
#                         # Calculate hourly rate based on unit
#                         if 'Hour' in unit:
#                             hourly = price
#                         elif 'Month' in unit:
#                             hourly = price / 730
#                         else:
#                             hourly = price
                        
#                         monthly = hourly * 730 * quantity
                        
#                         result = {
#                             "provider": "Azure",
#                             "service": "Virtual Machines",
#                             "region": azure_region,
#                             "instance_type": azure_instance,
#                             "hourly_rate": round(hourly, 4),
#                             "monthly_rate": round(monthly, 2),
#                             "currency": "USD",
#                             "pricing_model": "Pay-As-You-Go",
#                             "data_source": "live_azure_api",
#                             "sku": sku,
#                             "unit": unit,
#                             "mapped_from": instance_input if is_aws else None
#                         }
                        
#                         logger.info(f"✅ Azure live price found: ${monthly:.2f}/month")
#                         return json.dumps(result, indent=2)
                
#                 # No exact match found - show available instances in region
#                 if vm_prices:
#                     available_instances = list(set([item.get('armSkuName', '') for item in vm_prices[:20]]))
#                     available_instances.sort()
                    
#                     logger.warning(f"⚠️ Instance {azure_instance} not found in {azure_region}")
#                     return json.dumps({
#                         "provider": "Azure",
#                         "region": azure_region,
#                         "instance_type": azure_instance,
#                         "error": f"Instance not found in {azure_region}",
#                         "available_instances": available_instances[:10],
#                         "mapped_from": instance_input if is_aws else None,
#                         "data_source": "live_but_no_match"
#                     }, indent=2)
#                 else:
#                     logger.warning(f"⚠️ No VM SKUs found in region {azure_region}")
            
#             # Fallback to demo data
#             logger.warning("Using demo data as fallback")
#             return self._get_demo_pricing(azure_region, azure_instance, quantity, instance_input if is_aws else None)
            
#         except requests.exceptions.RequestException as e:
#             logger.error(f"❌ Azure API request failed: {e}")
#             return self._get_demo_pricing(region, specifications.get('instance_type', 'D2s v3'), quantity, None)
#         except Exception as e:
#             logger.error(f"❌ Error in Azure pricing: {e}")
#             return self._get_demo_pricing(region, specifications.get('instance_type', 'D2s v3'), quantity, None)
    
#     def _get_demo_pricing(self, region: str, instance_type: str, quantity: int, original_instance: Optional[str] = None) -> str:
#         """Return demo pricing data with mapping info"""
#         # Demo pricing map for common Azure instances
#         demo_prices = {
#             'B2s': 0.0416,
#             'B4ms': 0.166,
#             'B8ms': 0.332,
#             'D2s v3': 0.096,
#             'D4s v3': 0.192,
#             'D8s v3': 0.384,
#             'D16s v3': 0.768,
#             'D32s v3': 1.536,
#             'D48s v3': 2.304,
#             'D64s v3': 3.072,
#             'F2s v2': 0.084,
#             'F4s v2': 0.168,
#             'F8s v2': 0.336,
#             'F16s v2': 0.672,
#             'F32s v2': 1.344,
#             'F48s v2': 2.016,
#             'F64s v2': 2.688,
#             'F72s v2': 3.024,
#             'E2s v3': 0.146,
#             'E4s v3': 0.292,
#             'E8s v3': 0.584,
#             'E16s v3': 1.168,
#             'E20s v3': 1.460,
#             'E32s v3': 2.336,
#             'E48s v3': 3.504,
#             'E64s v3': 4.672,
#             'NC6s v3': 3.06,
#             'NC12s v3': 6.12,
#             'NC24s v3': 12.24,
#             'NC48s v3': 24.48,
#             'NC64s v3': 32.64,
#             'NC96s v3': 48.96,
#         }
        
#         hourly = demo_prices.get(instance_type, 0.096)
#         monthly = hourly * 730 * quantity
        
#         result = {
#             "provider": "Azure",
#             "region": region,
#             "instance_type": instance_type,
#             "hourly_rate": round(hourly, 4),
#             "monthly_rate": round(monthly, 2),
#             "currency": "USD",
#             "pricing_model": "Pay-As-You-Go (Demo)",
#             "data_source": "demo",
#             "note": "Using demo pricing data - Azure API unavailable"
#         }
        
#         if original_instance:
#             result["mapped_from"] = original_instance
#             result["mapping_note"] = f"AWS {original_instance} → Azure {instance_type}"
        
#         logger.info(f"ℹ️ Azure demo price: ${monthly:.2f}/month")
#         return json.dumps(result, indent=2)
    
#     async def _arun(self, *args, **kwargs):
#         """Async version not implemented"""
#         return self._run(*args, **kwargs)
"""
Azure Pricing Tool for Cloud Rationalization Agent
Complete version with all AWS mappings and working Pydantic v2 syntax
"""
from langchain.tools import BaseTool
from typing import Dict, Optional, Type, Any
from pydantic import BaseModel, Field, ConfigDict
import requests
import json
import logging

logger = logging.getLogger(__name__)

class AzurePricingInput(BaseModel):
    """Input schema for Azure pricing tool"""
    resource_type: str = Field(description="Type of resource")
    region: str = Field(description="Azure region")
    specifications: Dict[str, Any] = Field(default_factory=dict)
    quantity: int = Field(default=1)

class AzurePricingTool(BaseTool):
    """Tool for getting Azure pricing information"""
    
    name: str = "azure_pricing_tool"
    description: str = "Get Azure pricing for VMs with AWS instance mapping"
    args_schema: Type[BaseModel] = AzurePricingInput
    
    # Simple field definition - works with Pydantic v2
    base_url: str = "https://prices.azure.com/api/retail/prices"
    
    model_config = ConfigDict(arbitrary_types_allowed=True)
    
    # Complete AWS to Azure mappings
    AWS_TO_AZURE_MAP = {
        "t3.nano": "B2s", "t3.micro": "B2s", "t3.small": "B2s",
        "t3.medium": "B4ms", "t3.large": "B8ms", 
        "t3.xlarge": "B16ms", "t3.2xlarge": "B32ms",
        "m5.large": "D2s v3", "m5.xlarge": "D4s v3",
        "m5.2xlarge": "D8s v3", "m5.4xlarge": "D16s v3",
        "c5.large": "F2s v2", "c5.xlarge": "F4s v2",
        "c5.2xlarge": "F8s v2", "c5.4xlarge": "F16s v2",
        "r5.large": "E2s v3", "r5.xlarge": "E4s v3",
        "r5.2xlarge": "E8s v3", "r5.4xlarge": "E16s v3",
        "g4dn.xlarge": "NC6s v3", "g4dn.2xlarge": "NC12s v3",
        "g4dn.4xlarge": "NC24s v3", "g4dn.8xlarge": "NC48s v3",
    }
    
    # Region mappings
    AWS_TO_AZURE_REGION_MAP = {
        "us-east-1": "eastus", "us-east-2": "eastus2",
        "us-west-1": "westus", "us-west-2": "westus2",
        "eu-west-1": "westeurope", "eu-central-1": "germanywestcentral",
        "ap-southeast-1": "southeastasia", "ap-northeast-1": "japaneast",
    }
    
    def _map_aws_instance(self, aws_instance: str) -> str:
        """Map AWS instance to Azure equivalent"""
        if aws_instance in self.AWS_TO_AZURE_MAP:
            return self.AWS_TO_AZURE_MAP[aws_instance]
        # Family fallback
        family = aws_instance.split('.')[0]
        for key, value in self.AWS_TO_AZURE_MAP.items():
            if key.startswith(family):
                return value
        return "D2s v3"
    
    def _map_aws_region(self, aws_region: str) -> str:
        """Map AWS region to Azure region"""
        return self.AWS_TO_AZURE_REGION_MAP.get(aws_region, aws_region)
    
    def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
        """Run the tool"""
        try:
            instance_input = specifications.get('instance_type', 'D2s v3')
            
            # Check if it's an AWS instance
            is_aws = '.' in instance_input
            
            if is_aws:
                azure_instance = self._map_aws_instance(instance_input)
                azure_region = self._map_aws_region(region)
                logger.info(f"Mapped AWS {instance_input} -> Azure {azure_instance}")
            else:
                azure_instance = instance_input
                azure_region = region
            
            # Call Azure API
            response = requests.get(self.base_url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                items = data.get('Items', [])
                
                # Find matching instance
                for item in items:
                    if (item.get('serviceName') == 'Virtual Machines' and 
                        item.get('armRegionName') == azure_region and
                        azure_instance.lower() in item.get('armSkuName', '').lower()):
                        
                        price = item.get('retailPrice', 0)
                        unit = item.get('unitOfMeasure', '1 Hour')
                        
                        hourly = price if 'Hour' in unit else price / 730
                        monthly = hourly * 730 * quantity
                        
                        result = {
                            "provider": "Azure",
                            "region": azure_region,
                            "instance_type": azure_instance,
                            "hourly_rate": round(hourly, 4),
                            "monthly_rate": round(monthly, 2),
                            "currency": "USD",
                            "data_source": "live",
                            "mapped_from": instance_input if is_aws else None
                        }
                        return json.dumps(result, indent=2)
            
            # Demo fallback
            return json.dumps({
                "provider": "Azure",
                "region": azure_region,
                "instance_type": azure_instance,
                "hourly_rate": 0.096,
                "monthly_rate": 70.08,
                "currency": "USD",
                "data_source": "demo",
                "mapped_from": instance_input if is_aws else None
            })
            
        except Exception as e:
            logger.error(f"Error: {e}")
            return json.dumps({"error": str(e), "provider": "Azure"})
