"""
Azure Pricing Tool for Cloud Rationalization Agent
"""
from langchain.tools import BaseTool
from typing import Dict, List, Optional, Type
from pydantic import BaseModel, Field
import requests
import json
import logging

logger = logging.getLogger(__name__)

class AzurePricingInput(BaseModel):
    """Input schema for Azure pricing tool"""
    resource_type: str = Field(description="Type of resource (VM, Storage, SQL, etc.)")
    region: str = Field(description="Azure region (eastus, westeurope, etc.)")
    specifications: Dict = Field(description="Resource specifications")
    quantity: int = Field(default=1, description="Number of instances")

class AzurePricingTool(BaseTool):
    """Tool for getting Azure pricing information"""
    
    name = "azure_pricing_tool"
    description = """
    Get real-time Azure pricing for VMs, Storage, SQL, and other services.
    Uses Azure Retail Prices API. Returns prices in USD with hourly/monthly rates.
    """
    args_schema: Type[BaseModel] = AzurePricingInput
    
    def __init__(self, credentials: Optional[Dict] = None):
        super().__init__()
        self.credentials = credentials or {}
        self.base_url = "https://prices.azure.com/api/retail/prices"
    
    def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
        """Run the tool"""
        try:
            # Map resource types to Azure service names
            service_map = {
                "vm": "Virtual Machines",
                "storage": "Storage",
                "sql": "SQL Database",
                "aks": "Kubernetes Service",
                "functions": "Functions"
            }
            
            service_name = service_map.get(resource_type.lower(), "Virtual Machines")
            
            # Build filter for Azure API
            filters = []
            if resource_type.lower() == 'vm':
                vm_size = specifications.get('vm_size', 'D2s v3')
                filters.append(f"armSkuName eq '{vm_size}'")
            
            filters.append(f"armRegionName eq '{region}'")
            filters.append(f"serviceName eq '{service_name}'")
            
            filter_string = " and ".join(filters)
            
            # Query Azure Retail Prices API
            params = {
                "$filter": filter_string,
                "api-version": "2023-01-01"
            }
            
            response = requests.get(self.base_url, params=params)
            data = response.json()
            
            # Parse response
            prices = self._parse_pricing_response(data, resource_type)
            
            # Calculate costs
            hourly_rate = prices.get('hourly_rate', 0)
            monthly_rate = hourly_rate * 730 * quantity
            
            result = {
                "provider": "Azure",
                "service": service_name,
                "region": region,
                "specifications": specifications,
                "quantity": quantity,
                "hourly_rate": round(hourly_rate, 4),
                "monthly_rate": round(monthly_rate, 2),
                "currency": "USD",
                "pricing_model": "Pay-As-You-Go",
                "notes": "Azure Hybrid Benefit and reservations can reduce costs"
            }
            
            return json.dumps(result, indent=2)
            
        except requests.RequestException as e:
            logger.error(f"Azure API request error: {e}")
            return json.dumps({
                "error": "Azure API error",
                "details": str(e)
            })
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return json.dumps({
                "error": "Unexpected error",
                "details": str(e)
            })
    
    def _parse_pricing_response(self, data: Dict, resource_type: str) -> Dict:
        """Parse Azure pricing API response"""
        prices = {'hourly_rate': 0}
        
        try:
            items = data.get('Items', [])
            if items:
                # Get the first item (most relevant)
                item = items[0]
                retail_price = item.get('retailPrice', 0)
                unit_of_measure = item.get('unitOfMeasure', '1 Hour')
                
                if 'Hour' in unit_of_measure:
                    prices['hourly_rate'] = retail_price
                elif 'Month' in unit_of_measure:
                    prices['hourly_rate'] = retail_price / 730
                else:
                    prices['hourly_rate'] = retail_price
                    
                prices['unit'] = unit_of_measure
                prices['sku'] = item.get('armSkuName', '')
                prices['product_name'] = item.get('productName', '')
                
        except Exception as e:
            logger.error(f"Error parsing Azure pricing: {e}")
            
        return prices
    
    async def _arun(self, *args, **kwargs):
        """Async version (not implemented)"""
        raise NotImplementedError("Async not implemented")