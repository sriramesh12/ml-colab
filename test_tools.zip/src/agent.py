# """
# Cloud Rationalization Agent - Complete Version with SSL Fix
# """
# from typing import Dict, List, Optional, Any, Union
# from langchain.agents import AgentExecutor, create_openai_tools_agent
# from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
# from langchain_openai import ChatOpenAI
# from langchain.memory import ConversationBufferMemory
# import logging
# import json
# import os
# import httpx
# import certifi
# from datetime import datetime

# # Import helpers
# from src.utils.helpers import apply_ssl_fix, safe_serialize, safe_call_tool

# # Import tools
# from src.tools.aws_pricing import AWSPricingTool
# from src.tools.azure_pricing import AzurePricingTool
# from src.tools.gcp_pricing import GCPPricingTool
# from src.tools.analyzers import WorkloadAnalyzer, CostOptimizer

# # Apply SSL fix at module level
# ssl_context = apply_ssl_fix()
# logger = logging.getLogger(__name__)

# class CloudRationalizationAgent:
#     """
#     AI Agent for cloud infrastructure rationalization
#     Features:
#     - Tool-only mode (works without OpenAI)
#     - Full agent mode (with OpenAI for explanations)
#     - SSL fixes for corporate networks
#     - Safe serialization for Pydantic models
#     """
    
#     def __init__(self, 
#                  openai_api_key: Optional[str] = None,
#                  aws_credentials: Optional[Dict] = None,
#                  azure_credentials: Optional[Dict] = None,
#                  gcp_credentials: Optional[Dict] = None,
#                  model: str = "gpt-3.5-turbo",  # Using 3.5 for faster response
#                  temperature: float = 0.1):
#         """
#         Initialize the agent - tools always work, LLM is optional
#         """
#         # Create HTTP client with SSL fix
#         self.http_client = httpx.Client(
#             verify=certifi.where(),  # Use certifi certificates
#             timeout=30.0,
#             follow_redirects=True
#         )
        
#         # ===== STEP 1: Initialize tools FIRST (always work) =====
#         self.tools = self._initialize_tools(
#             aws_credentials or {},
#             azure_credentials or {},
#             gcp_credentials or {}
#         )
#         logger.info(f"✅ Tools initialized: {len(self.tools)} tools available")
        
#         # ===== STEP 2: Try to initialize LLM (optional) =====
#         self.llm = None
#         self.agent = None
#         self.agent_executor = None
#         self.memory = None
        
#         if openai_api_key:
#             try:
#                 self.llm = ChatOpenAI(
#                     model=model,
#                     temperature=temperature,
#                     api_key=openai_api_key,
#                     http_client=self.http_client,
#                     timeout=30,
#                     max_retries=2
#                 )
#                 logger.info("✅ LLM initialized successfully")
                
#                 # Create agent if LLM works
#                 self.memory = ConversationBufferMemory(
#                     memory_key="chat_history",
#                     return_messages=True
#                 )
                
#                 self.agent = self._create_agent()
#                 self.agent_executor = AgentExecutor(
#                     agent=self.agent,
#                     tools=self.tools,
#                     verbose=True,
#                     handle_parsing_errors=True,
#                     max_iterations=10
#                 )
#                 logger.info("✅ Full agent initialized with LLM")
                
#             except Exception as e:
#                 logger.warning(f"⚠️ LLM initialization failed: {e}")
#                 logger.info("🔄 Running in TOOL-ONLY mode")
#         else:
#             logger.info("🔄 No API key provided - running in TOOL-ONLY mode")
    
#     def _initialize_tools(self, aws_creds, azure_creds, gcp_creds):
#         """Initialize all tools - ALWAYS WORKS"""
#         tools = []
        
#         # Pricing tools - always initialize (they handle missing credentials internally)
#         tools.append(AWSPricingTool(credentials=aws_creds or {}))
#         tools.append(AzurePricingTool(credentials=azure_creds or {}))
#         tools.append(GCPPricingTool(credentials=gcp_creds or {}))
        
#         from src.tools.analyzers import WorkloadAnalyzer, CostOptimizer        
#         # Analysis tools
#         tools.append(WorkloadAnalyzer())
#         tools.append(CostOptimizer())
        
#         return tools
    
#     def _create_agent(self):
#         """Create the LangChain agent (only called if LLM available)"""
#         prompt = ChatPromptTemplate.from_messages([
#             ("system", """You are an expert cloud rationalization advisor. 
#             Analyze infrastructure and provide cost optimization recommendations.
#             Be specific with numbers and actionable steps."""),
#             MessagesPlaceholder(variable_name="chat_history"),
#             ("user", "{input}"),
#             MessagesPlaceholder(variable_name="agent_scratchpad")
#         ])
        
#         return create_openai_tools_agent(self.llm, self.tools, prompt)
    
#     # ===== TOOL-ONLY METHODS (Work without LLM) =====
    
#     def compare_prices(self, 
#                        resource_type: str = "ec2",
#                        specifications: Union[Dict, str] = None,
#                        regions: Union[List[str], str] = None) -> Dict:
#         """
#         Compare prices across providers - ALWAYS WORKS
#         Uses safe_call_tool helper for robust parameter handling
#         """
#         if specifications is None:
#             specifications = {"instance_type": "t3.medium", "os": "Linux"}
#         if regions is None:
#             regions = ["us-east-1"]
        
#         results = {}
        
#         # Find pricing tools
#         pricing_tools = [t for t in self.tools if 'pricing' in t.name]
        
#         for tool in pricing_tools:
#             try:
#                 # Use safe helper to call tool
#                 result = safe_call_tool(
#                     tool=tool,
#                     resource_type=resource_type,
#                     region_input=regions,
#                     specifications=specifications,
#                     quantity=1
#                 )
                
#                 # Extract provider name
#                 provider = tool.name.replace('_pricing_tool', '').replace('_', '')
#                 results[provider] = result
                
#             except Exception as e:
#                 logger.error(f"Error with {tool.name}: {e}")
#                 provider = tool.name.replace('_pricing_tool', '')
#                 results[provider] = {
#                     "error": str(e),
#                     "provider": provider.upper(),
#                     "monthly_rate": 30.37 if 'aws' in provider else 35.04 if 'azure' in provider else 27.38,
#                     "hourly_rate": 0.0416 if 'aws' in provider else 0.0480 if 'azure' in provider else 0.0375,
#                     "fallback": True
#                 }
        
#         # Add summary
#         results['_metadata'] = {
#             "timestamp": datetime.now().isoformat(),
#             "mode": "tool_only",
#             "resource_type": resource_type,
#             "instance_type": specifications.get('instance_type') if isinstance(specifications, dict) else "t3.medium"
#         }
        
#         return results
    
#     def analyze_workload(self, resources: List[Dict]) -> Dict:
#         """
#         Analyze workload using tools only
#         """
#         analyzer = next((t for t in self.tools if 'WorkloadAnalyzer' in t.__class__.__name__), None)
        
#         if analyzer:
#             try:
#                 result = analyzer._run(resources)
#                 if isinstance(result, str):
#                     return json.loads(result)
#                 return result
#             except Exception as e:
#                 return {"error": str(e)}
        
#         return {"error": "Analyzer tool not found"}
    
#     def calculate_savings(self, current_costs: Dict, strategy: str = "combined") -> Dict:
#         """
#         Calculate savings using tools only
#         """
#         optimizer = next((t for t in self.tools if 'CostOptimizer' in t.__class__.__name__), None)
        
#         if optimizer:
#             try:
#                 result = optimizer._run(current_costs, strategy)
#                 if isinstance(result, str):
#                     return json.loads(result)
#                 return result
#             except Exception as e:
#                 return {"error": str(e)}
        
#         return {"error": "Optimizer tool not found"}
    
#     # ===== AGENT METHODS (Require LLM) =====
    
#     # async def analyze_with_llm(self, request):
#     #     """
#     #     Full agent analysis WITH LLM
#     #     Falls back to tool-only if LLM unavailable
#     #     """
#     #     # If no LLM, use tool-only mode
#     #     if not self.agent_executor:
#     #         logger.info("LLM unavailable - using tool-only mode")
            
#     #         # Extract resources from request
#     #         resources = []
#     #         if hasattr(request, 'current_infrastructure'):
#     #             for r in request.current_infrastructure:
#     #                 resources.append({
#     #                     'name': getattr(r, 'name', 'unknown'),
#     #                     'monthly_cost': getattr(r, 'monthly_cost', 0),
#     #                     'usage_pattern': getattr(r, 'usage_pattern', 'steady'),
#     #                     'fault_tolerant': getattr(r, 'fault_tolerant', False)
#     #                 })
            
#     #         # Use tool-only methods
#     #         prices = self.compare_prices()
#     #         analysis = self.analyze_workload(resources)
#     #         total_cost = sum(r.get('monthly_cost', 0) for r in resources)
#     #         savings = self.calculate_savings({"total": total_cost})
            
#     #         return {
#     #             "analysis": f"Tool-Only Analysis:\n"
#     #                        f"- Prices compared from {len(prices)-1} providers\n"
#     #                        f"- Resources analyzed: {len(resources)}\n"
#     #                        f"- Current monthly cost: ${total_cost:,.2f}\n"
#     #                        f"- Estimated savings potential: 30-60%",
#     #             "tool_outputs": safe_serialize({
#     #                 "prices": prices,
#     #                 "analysis": analysis,
#     #                 "savings": savings
#     #             }),
#     #             "mode": "tool_only"
#     #         }
        
#     #     # Use full agent with LLM
#     #     try:
#     #         result = await self.agent_executor.ainvoke({
#     #             "input": "Analyze this infrastructure and provide recommendations",
#     #             "chat_history": self.memory.chat_memory.messages if self.memory else []
#     #         })
#     #         result["mode"] = "full_agent"
#     #         return result
#     #     except Exception as e:
#     #         logger.error(f"LLM analysis failed: {e}")
#     #         # Recursive fallback to tool-only
#     #         return await self.analyze_with_llm(request)
#     async def analyze_with_llm(self, request):
#         """
#         Full agent analysis WITH LLM - FIXED event loop issue
#         Falls back to tool-only if LLM unavailable
#         """
#         # If no LLM, use tool-only mode
#         if not self.agent_executor:
#             logger.info("LLM unavailable - using tool-only mode")
            
#             # Extract resources from request
#             resources = []
#             if hasattr(request, 'current_infrastructure'):
#                 for r in request.current_infrastructure:
#                     resources.append({
#                         'name': getattr(r, 'name', 'unknown'),
#                         'monthly_cost': getattr(r, 'monthly_cost', 0),
#                         'usage_pattern': getattr(r, 'usage_pattern', 'steady'),
#                         'fault_tolerant': getattr(r, 'fault_tolerant', False)
#                     })
            
#             # Use tool-only methods
#             prices = self.compare_prices()
#             analysis = self.analyze_workload(resources)
#             total_cost = sum(r.get('monthly_cost', 0) for r in resources)
#             savings = self.calculate_savings({"total": total_cost})
            
#             return {
#                 "analysis": f"Tool-Only Analysis:\n"
#                         f"- Prices compared from providers\n"
#                         f"- Resources analyzed: {len(resources)}\n"
#                         f"- Current monthly cost: ${total_cost:,.2f}\n"
#                         f"- Estimated savings potential: 30-60%",
#                 "tool_outputs": safe_serialize({
#                     "prices": prices,
#                     "analysis": analysis,
#                     "savings": savings
#                 }),
#                 "mode": "tool_only"
#             }
        
#         # Use full agent with LLM - NO NEW LOOP CREATED
#         try:
#             # Just await directly - no new loop
#             result = await self.agent_executor.ainvoke({
#                 "input": "Analyze this infrastructure and provide recommendations",
#                 "chat_history": self.memory.chat_memory.messages if self.memory else []
#             })
#             result["mode"] = "full_agent"
#             return result
#         except Exception as e:
#             logger.error(f"LLM analysis failed: {e}")
#             return {
#                 "analysis": f"LLM analysis failed: {e}\nFalling back to tool data",
#                 "mode": "error_fallback",
#                 "error": str(e)
#             }
"""
Cloud Rationalization Agent - Complete Version with Retry Control
"""
from typing import Dict, List, Optional, Any
from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langchain.memory import ConversationBufferMemory
import logging
import json
import httpx
import certifi
from datetime import datetime
import asyncio

# Import tools
from src.tools.aws_pricing import AWSPricingTool
from src.tools.azure_pricing import AzurePricingTool
from src.tools.gcp_pricing import GCPPricingTool
from src.tools.analyzers import WorkloadAnalyzer, CostOptimizer

logger = logging.getLogger(__name__)

class CloudRationalizationAgent:
    """
    AI Agent for cloud infrastructure rationalization
    Fixed version with retry control and quota management
    """
    
    def __init__(self, 
                 openai_api_key: Optional[str] = None,
                 aws_credentials: Optional[Dict] = None,
                 azure_credentials: Optional[Dict] = None,
                 gcp_credentials: Optional[Dict] = None,
                 model: str = "gpt-3.5-turbo",
                 temperature: float = 0.1):
        """
        Initialize the agent with retries disabled
        """
        # Create HTTP client with SSL fix
        self.http_client = httpx.Client(
            verify=certifi.where(),
            timeout=30.0,
            follow_redirects=True
        )
        
        # Initialize tools FIRST
        self.tools = self._initialize_tools(
            aws_credentials or {},
            azure_credentials or {},
            gcp_credentials or {}
        )
        logger.info(f"✅ Tools initialized: {len(self.tools)} tools available")
        
        # Track quota status
        self._quota_exceeded = False
        self._last_quota_error = None
        
        # Initialize LLM (optional)
        self.llm = None
        self.agent = None
        self.agent_executor = None
        self.memory = None
        
        if openai_api_key:
            try:
                # FIX 1: Disable retries by setting max_retries=1
                self.llm = ChatOpenAI(
                    model=model,
                    temperature=temperature,
                    api_key=openai_api_key,
                    http_client=self.http_client,
                    max_retries=1,  # Only try ONCE, no retries
                    request_timeout=30
                )
                logger.info("✅ LLM initialized with retries disabled")
                
                # Create agent with limits
                self.memory = ConversationBufferMemory(
                    memory_key="chat_history",
                    return_messages=True
                )
                
                self.agent = self._create_agent()
                self.agent_executor = AgentExecutor(
                    agent=self.agent,
                    tools=self.tools,
                    verbose=False,  # Set to False to reduce noise
                    handle_parsing_errors=True,
                    max_iterations=2,  # Limit iterations
                    max_execution_time=30,  # Max 30 seconds
                    early_stopping_method="generate"
                )
                logger.info("✅ Full agent initialized with limits")
                
            except Exception as e:
                logger.warning(f"⚠️ LLM initialization failed: {e}")
                logger.info("🔄 Running in TOOL-ONLY mode")
        else:
            logger.info("🔄 No API key provided - running in TOOL-ONLY mode")
    
    def _initialize_tools(self, aws_creds, azure_creds, gcp_creds):
        """Initialize all tools"""
        tools = []
        tools.append(AWSPricingTool(credentials=aws_creds))
        tools.append(AzurePricingTool(credentials=azure_creds))
        tools.append(GCPPricingTool(credentials=gcp_creds))
        tools.append(WorkloadAnalyzer())
        tools.append(CostOptimizer())
        return tools
    
    def _create_agent(self):
        """Create the LangChain agent"""
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert cloud rationalization advisor."""),
            MessagesPlaceholder(variable_name="chat_history"),
            ("user", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad")
        ])
        return create_openai_tools_agent(self.llm, self.tools, prompt)
    
    # ===== SYNCHRONOUS TOOL METHODS (Always work) =====
    
    def compare_prices(self, 
                       resource_type: str = "ec2",
                       specifications: Dict = None,
                       regions: list = None) -> Dict:
        """Compare prices across providers - SYNCHRONOUS"""
        if specifications is None:
            specifications = {"instance_type": "t3.medium"}
        if regions is None:
            regions = ["us-east-1"]
        
        results = {}
        pricing_tools = [t for t in self.tools if 'pricing' in t.name]
        
        for tool in pricing_tools:
            try:
                region = regions[0] if regions else "us-east-1"
                result = tool._run(
                    resource_type=resource_type,
                    region=region,
                    specifications=specifications,
                    quantity=1
                )
                if isinstance(result, str):
                    result = json.loads(result)
                provider = tool.name.replace('_pricing_tool', '').replace('_', '')
                results[provider] = result
            except Exception as e:
                provider = tool.name.replace('_pricing_tool', '')
                results[provider] = {"error": str(e)}
        
        return results
    
    def analyze_workload(self, resources: List[Dict]) -> Dict:
        """Analyze workload using tools only"""
        analyzer = next((t for t in self.tools if 'WorkloadAnalyzer' in t.__class__.__name__), None)
        if analyzer:
            try:
                result = analyzer._run(resources)
                return json.loads(result) if isinstance(result, str) else result
            except Exception as e:
                return {"error": str(e)}
        return {"error": "Analyzer tool not found"}
    
    def calculate_savings(self, current_costs: Dict, strategy: str = "combined") -> Dict:
        """Calculate savings using tools only"""
        optimizer = next((t for t in self.tools if 'CostOptimizer' in t.__class__.__name__), None)
        if optimizer:
            try:
                result = optimizer._run(current_costs, strategy)
                return json.loads(result) if isinstance(result, str) else result
            except Exception as e:
                return {"error": str(e)}
        return {"error": "Optimizer tool not found"}
    
    # ===== ASYNC LLM METHOD (With quota handling) =====
    
    async def analyze_with_llm(self, request):
        """
        Full agent analysis WITH LLM - Handles quota errors gracefully
        This is ASYNC and should be awaited
        """
        # Check quota cache first
        if self._quota_exceeded:
            if self._last_quota_error:
                # Wait 1 hour before trying again
                elapsed = (datetime.now() - self._last_quota_error).seconds
                if elapsed < 3600:  # 1 hour
                    return {
                        "analysis": "OpenAI quota exceeded. Please try again later or use Tool-Only Mode.",
                        "mode": "quota_cached",
                        "error": "quota_exceeded",
                        "retry_after": f"{3600 - elapsed} seconds"
                    }
                else:
                    self._quota_exceeded = False
        
        # If no LLM, use tool-only mode
        if not self.agent_executor:
            logger.info("LLM unavailable - using tool-only mode")
            return self._get_tool_only_analysis(request)
        
        try:
            # FIX 2: Use asyncio.wait_for to prevent hanging
            import asyncio
            result = await asyncio.wait_for(
                self.agent_executor.ainvoke({
                    "input": "Analyze this infrastructure and provide cost optimization recommendations with specific savings numbers.",
                    "chat_history": self.memory.chat_memory.messages if self.memory else []
                }),
                timeout=25  # Shorter timeout
            )
            
            # Reset quota flag on success
            self._quota_exceeded = False
            result["mode"] = "full_agent"
            return result
            
        except asyncio.TimeoutError:
            logger.error("Analysis timed out")
            return {
                "analysis": "Analysis timed out. Please try again or use Tool-Only Mode.",
                "mode": "timeout_error",
                "error": "timeout"
            }
        except Exception as e:
            error_str = str(e)
            logger.error(f"LLM analysis failed: {e}")
            
            # FIX 3: Handle quota errors specifically
            if "429" in error_str or "quota" in error_str.lower() or "rate limit" in error_str.lower():
                self._quota_exceeded = True
                self._last_quota_error = datetime.now()
                return {
                    "analysis": "OpenAI quota exceeded. Please switch to Tool-Only Mode or add funds to your account.",
                    "mode": "quota_error",
                    "error": "quota_exceeded",
                    "suggestion": "Use Tool-Only Mode in the sidebar for immediate results"
                }
            
            # Return tool-only analysis as fallback
            return {
                "analysis": f"LLM analysis failed: {error_str}\n\nFalling back to tool-only analysis.",
                "tool_outputs": self._get_tool_only_analysis(request).get("tool_outputs", {}),
                "mode": "error_fallback"
            }
    
    def _get_tool_only_analysis(self, request):
        """Helper for tool-only analysis"""
        resources = []
        if hasattr(request, 'current_infrastructure'):
            for r in request.current_infrastructure:
                resources.append({
                    'name': getattr(r, 'name', 'unknown'),
                    'monthly_cost': getattr(r, 'monthly_cost', 0),
                    'usage_pattern': getattr(r, 'usage_pattern', 'steady'),
                    'fault_tolerant': getattr(r, 'fault_tolerant', False)
                })
        
        total_cost = sum(r.get('monthly_cost', 0) for r in resources)
        
        return {
            "analysis": f"## Tool-Only Analysis\n\n"
                       f"- Resources analyzed: {len(resources)}\n"
                       f"- Current monthly cost: ${total_cost:,.2f}\n"
                       f"- Estimated savings potential: 30-60%\n\n"
                       f"**Recommendations:**\n"
                       f"1. Right-size over-provisioned instances\n"
                       f"2. Purchase Reserved Instances for steady workloads\n"
                       f"3. Use Spot Instances for fault-tolerant jobs",
            "tool_outputs": {
                "prices": self.compare_prices(),
                "savings": self.calculate_savings({"total": total_cost})
            },
            "mode": "tool_only"
        }
