"""
Cloud Rationalization Agent - Main Agent Implementation
"""
from typing import Dict, List, Optional, Any
from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from src.tools.aws_pricing import AWSPricingTool
from src.tools.azure_pricing import AzurePricingTool
from src.tools.gcp_pricing import GCPPricingTool
from src.tools.analyzers import WorkloadAnalyzer, CostOptimizer
from src.models.schemas import RationalizationRequest, RationalizationResponse
import logging
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CloudRationalizationAgent:
    """
    AI Agent for cloud infrastructure rationalization and cost optimization
    """
    
    def __init__(self, 
                 openai_api_key: str,
                 aws_credentials: Optional[Dict] = None,
                 azure_credentials: Optional[Dict] = None,
                 gcp_credentials: Optional[Dict] = None,
                 model: str = "gpt-4-turbo-preview",
                 temperature: float = 0.1):
        """
        Initialize the Cloud Rationalization Agent
        
        Args:
            openai_api_key: OpenAI API key
            aws_credentials: AWS credentials dictionary
            azure_credentials: Azure credentials dictionary
            gcp_credentials: GCP credentials dictionary
            model: OpenAI model to use
            temperature: Model temperature (0-1)
        """
        self.llm = ChatOpenAI(
            model=model,
            temperature=temperature,
            api_key=openai_api_key
        )
        
        # Initialize tools
        self.tools = self._initialize_tools(
            aws_credentials, 
            azure_credentials, 
            gcp_credentials
        )
        
        # Initialize memory
        self.memory = ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True
        )
        
        # Setup agent
        self.agent = self._create_agent()
        self.agent_executor = AgentExecutor(
            agent=self.agent,
            tools=self.tools,
            verbose=True,
            handle_parsing_errors=True,
            max_iterations=15,
            early_stopping_method="generate"
        )
        
        logger.info("Cloud Rationalization Agent initialized successfully")
    
    def _initialize_tools(self, aws_creds, azure_creds, gcp_creds):
        """Initialize all tools"""
        tools = []
        
        # Pricing tools
        if aws_creds:
            tools.append(AWSPricingTool(credentials=aws_creds))
        if azure_creds:
            tools.append(AzurePricingTool(credentials=azure_creds))
        if gcp_creds:
            tools.append(GCPPricingTool(credentials=gcp_creds))
        
        # Analysis tools
        tools.extend([
            WorkloadAnalyzer(),
            CostOptimizer()
        ])
        
        return tools
    
    def _create_agent(self):
        """Create the LangChain agent"""
        
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert cloud rationalization and FinOps advisor. 
            Your capabilities include:
            
            1. **Multi-Cloud Pricing Analysis**: Compare costs across AWS, Azure, and GCP
            2. **Workload Optimization**: Right-sizing, reserved instances, spot instances
            3. **Migration Planning**: Lift-and-shift vs re-platforming strategies
            4. **Cost Forecasting**: Predict future costs based on usage patterns
            5. **Compliance Checking**: Ensure recommendations meet business constraints
            
            Always follow these principles:
            - Use real-time pricing data from tools when available
            - Consider both short-term and long-term optimization strategies
            - Provide specific, actionable recommendations
            - Include risk assessments for each recommendation
            - Quantify savings in both percentage and absolute terms
            
            When analyzing infrastructure, consider:
            - Workload patterns (steady, variable, batch)
            - Data residency requirements
            - Compliance needs (HIPAA, GDPR, etc.)
            - Performance requirements
            - Business criticality
            
            Format your responses with clear sections and bullet points.
            """),
            MessagesPlaceholder(variable_name="chat_history"),
            ("user", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad")
        ])
        
        return create_openai_tools_agent(self.llm, self.tools, prompt)
    
    async def analyze(self, request: RationalizationRequest) -> RationalizationResponse:
        """
        Analyze cloud infrastructure and provide optimization recommendations
        
        Args:
            request: RationalizationRequest object containing infrastructure details
            
        Returns:
            RationalizationResponse with analysis results
        """
        try:
            # Prepare input for agent
            input_text = f"""
            Please analyze this cloud infrastructure and provide optimization recommendations:
            
            CURRENT INFRASTRUCTURE:
            {json.dumps([r.dict() for r in request.current_infrastructure], indent=2)}
            
            BUSINESS CONSTRAINTS:
            {json.dumps(request.business_constraints, indent=2)}
            
            OPTIMIZATION GOALS:
            {', '.join(request.optimization_goals)}
            
            TIME HORIZON: {request.time_horizon}
            
            Please provide:
            1. Multi-cloud price comparison for all resources
            2. Right-sizing recommendations
            3. Reserved instance/commitment discount analysis
            4. Spot instance opportunities
            5. Migration recommendations
            6. Cost savings projection with confidence levels
            7. Implementation roadmap
            8. Risk assessment
            """
            
            # Run agent
            result = await self.agent_executor.ainvoke({
                "input": input_text,
                "chat_history": self.memory.chat_memory.messages
            })
            
            # Update memory
            self.memory.chat_memory.add_user_message(input_text)
            self.memory.chat_memory.add_ai_message(result["output"])
            
            # Parse and structure response
            response = self._structure_response(result, request)
            
            return response
            
        except Exception as e:
            logger.error(f"Error during analysis: {str(e)}")
            raise
    
    def _structure_response(self, raw_result: Dict, request: RationalizationRequest) -> RationalizationResponse:
        """Structure the raw agent response into a formatted response"""
        
        # This would parse the LLM output and extract structured data
        # For now, return a basic structure
        return RationalizationResponse(
            request_id=request.request_id,
            analysis=raw_result["output"],
            recommendations=[],
            cost_savings={},
            risks=[],
            timestamp=datetime.now()
        )
    
    async def compare_prices(self, 
                            resource_type: str,
                            specifications: Dict,
                            regions: List[str] = None) -> Dict:
        """
        Compare prices across cloud providers for specific resources
        
        Args:
            resource_type: Type of resource (VM, Storage, etc.)
            specifications: Resource specifications
            regions: List of regions to compare
            
        Returns:
            Dictionary with price comparisons
        """
        results = {}
        
        for tool in self.tools:
            if hasattr(tool, 'get_pricing'):
                try:
                    price = await tool.get_pricing(
                        resource_type=resource_type,
                        specifications=specifications,
                        regions=regions
                    )
                    results[tool.name] = price
                except Exception as e:
                    logger.warning(f"Error getting price from {tool.name}: {e}")
        
        return results
    
    def get_conversation_history(self) -> List:
        """Get the conversation history"""
        return self.memory.chat_memory.messages
    
    def clear_conversation(self):
        """Clear the conversation history"""
        self.memory.clear()