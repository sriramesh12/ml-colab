"""
Data models for the Cloud Rationalization Agent
"""
from pydantic import BaseModel, Field, validator
from typing import List, Dict, Optional, Any
from datetime import datetime
from enum import Enum

class CloudProvider(str, Enum):
    AWS = "aws"
    AZURE = "azure"
    GCP = "gcp"
    MULTI = "multi"

class ResourceType(str, Enum):
    COMPUTE = "compute"
    STORAGE = "storage"
    DATABASE = "database"
    NETWORKING = "networking"
    CONTAINER = "container"
    SERVERLESS = "serverless"

class UsagePattern(str, Enum):
    STEADY = "steady"
    VARIABLE = "variable"
    SPIKY = "spiky"
    BATCH = "batch"
    DEVELOPMENT = "development"

class CommitmentTerm(str, Enum):
    ONDEMAND = "on_demand"
    ONE_YEAR = "1_year"
    THREE_YEAR = "3_year"
    SPOT = "spot"

class CloudResource(BaseModel):
    """Represents a cloud resource"""
    resource_id: Optional[str] = None
    name: str
    resource_type: ResourceType
    provider: CloudProvider
    region: str
    specifications: Dict[str, Any] = Field(default_factory=dict)
    quantity: int = 1
    usage_pattern: UsagePattern = UsagePattern.STEADY
    monthly_cost: Optional[float] = None
    tags: Dict[str, str] = Field(default_factory=dict)
    fault_tolerant: bool = False
    criticality: str = "medium"  # low, medium, high
    
    @validator('quantity')
    def quantity_must_be_positive(cls, v):
        if v < 1:
            raise ValueError('Quantity must be at least 1')
        return v

class BusinessConstraints(BaseModel):
    """Business constraints for optimization"""
    max_budget: Optional[float] = None
    min_availability: str = "99.9%"
    data_residency: List[str] = Field(default_factory=list)
    compliance_requirements: List[str] = Field(default_factory=list)
    preferred_providers: List[CloudProvider] = Field(default_factory=list)
    migration_window: Optional[str] = None
    risk_tolerance: str = "medium"  # low, medium, high

class OptimizationGoal(str, Enum):
    COST_REDUCTION = "cost_reduction"
    PERFORMANCE = "performance"
    AVAILABILITY = "availability"
    GREEN_IT = "green_it"
    MODERNIZATION = "modernization"

class RationalizationRequest(BaseModel):
    """Request for cloud rationalization"""
    request_id: str = Field(default_factory=lambda: f"req_{datetime.now().timestamp()}")
    current_infrastructure: List[CloudResource]
    business_constraints: BusinessConstraints
    optimization_goals: List[OptimizationGoal]
    time_horizon: str = "1 year"
    include_detailed_breakdown: bool = True
    created_at: datetime = Field(default_factory=datetime.now)

class PriceEstimate(BaseModel):
    """Price estimate for a resource"""
    provider: CloudProvider
    region: str
    commitment_term: CommitmentTerm
    unit_price: float
    currency: str = "USD"
    monthly_cost: float
    yearly_cost: float
    effective_rate: float  # per hour/core/GB etc.
    confidence: float  # 0-1

class Recommendation(BaseModel):
    """Optimization recommendation"""
    resource_id: Optional[str]
    title: str
    description: str
    type: str  # right_size, reserved_instance, spot, migration, etc.
    current_cost: float
    proposed_cost: float
    savings: float
    savings_percentage: float
    implementation_effort: str  # low, medium, high
    risk_level: str  # low, medium, high
    timeline: str
    prerequisites: List[str] = Field(default_factory=list)
    auto_remediation_possible: bool = False

class RationalizationResponse(BaseModel):
    """Response from rationalization analysis"""
    request_id: str
    analysis: str
    summary: Optional[str] = None
    current_monthly_cost: Optional[float] = None
    optimized_monthly_cost: Optional[float] = None
    total_savings: Optional[float] = None
    savings_percentage: Optional[float] = None
    recommendations: List[Recommendation] = Field(default_factory=list)
    price_comparisons: Dict[str, List[PriceEstimate]] = Field(default_factory=dict)
    risks: List[Dict] = Field(default_factory=list)
    implementation_plan: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.now)