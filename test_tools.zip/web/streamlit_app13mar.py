"""
Streamlit Web Interface for Cloud Rationalization Agent
Updated with SSL fixes and helper integrations
"""
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import requests
import json
import sys
import os
from pathlib import Path
from datetime import datetime

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent))

# Apply SSL fix FIRST
from src.utils.helpers import apply_ssl_fix, format_currency, get_region_display_name
apply_ssl_fix()

# Page configuration
st.set_page_config(
    page_title="Cloud Rationalization Agent",
    page_icon="☁️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1E88E5;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1.5rem;
        border-radius: 10px;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    .recommendation-card {
        background-color: #f0f8ff;
        padding: 1rem;
        border-radius: 5px;
        border-left: 4px solid #1E88E5;
        margin: 0.5rem 0;
    }
    .savings-positive {
        color: #00C853;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'resources' not in st.session_state:
    st.session_state.resources = []
if 'analysis_result' not in st.session_state:
    st.session_state.analysis_result = None
if 'agent' not in st.session_state:
    st.session_state.agent = None
if 'api_mode' not in st.session_state:
    st.session_state.api_mode = False
if 'api_url' not in st.session_state:
    st.session_state.api_url = "http://localhost:8080"

# ===== SIDEBAR =====
with st.sidebar:
    st.image("https://img.icons8.com/color/96/000000/cloud--v1.png", width=80)
    st.title("Cloud Rationalization Agent")
    
    # Mode selection
    st.header("⚙️ Configuration")
    mode = st.radio(
        "Select Mode",
        ["Local Agent", "API Mode"],
        help="Local Agent uses direct agent (tools always work), API Mode connects to FastAPI backend"
    )
    
    if mode == "Local Agent":
        st.session_state.api_mode = False
        with st.expander("🔑 OpenAI API Key (Optional)", expanded=False):
            openai_key = st.text_input("OpenAI API Key", type="password", 
                                      help="Optional - without it, tool-only mode works")
            
            if st.button("🚀 Initialize Agent", type="primary"):
                with st.spinner("Initializing agent..."):
                    try:
                        from src.agent import CloudRationalizationAgent
                        st.session_state.agent = CloudRationalizationAgent(
                            openai_api_key=openai_key if openai_key else None
                        )
                        mode_text = "FULL AGENT" if st.session_state.agent.llm else "TOOL-ONLY"
                        st.success(f"✅ Agent initialized in {mode_text} mode!")
                        st.info("✓ Price comparison works\n✓ Workload analysis works\n✓ Savings calculation works")
                    except Exception as e:
                        st.error(f"Failed to initialize: {e}")
    else:
        st.session_state.api_mode = True
        st.session_state.api_url = st.text_input(
            "API URL",
            value="http://localhost:8080",
            help="URL of the FastAPI backend"
        )
        
        if st.button("🔍 Check API Health"):
            try:
                response = requests.get(f"{st.session_state.api_url}/health", timeout=5)
                if response.status_code == 200:
                    data = response.json()
                    st.success(f"✅ API is healthy (Mode: {data.get('agent_mode', 'unknown')})")
                else:
                    st.error("❌ API returned error")
            except Exception as e:
                st.error(f"❌ Cannot connect: {e}")
    
    st.markdown("---")
    st.markdown("### 📊 Quick Stats")
    st.metric("Total Resources", len(st.session_state.resources))
    
    if st.button("🗑️ Clear All"):
        st.session_state.resources = []
        st.session_state.analysis_result = None
        st.rerun()

# ===== MAIN CONTENT =====
st.markdown("<h1 class='main-header'>☁️ Cloud Infrastructure Optimizer</h1>", unsafe_allow_html=True)

# Create tabs
tab1, tab2, tab3, tab4 = st.tabs([
    "📋 Infrastructure Input", 
    "💰 Price Comparison", 
    "📈 Analysis Results",
    "🔍 Debug"
])

# ===== TAB 1: Infrastructure Input =====
with tab1:
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Add Cloud Resource")
        
        with st.form("resource_form"):
            row1_col1, row1_col2, row1_col3 = st.columns(3)
            
            with row1_col1:
                resource_name = st.text_input("Resource Name", "web-server-01")
                provider = st.selectbox("Provider", ["aws", "azure", "gcp"])
            
            with row1_col2:
                instance_type = st.text_input("Instance Type", "t3.medium")
                region = st.text_input("Region", "us-east-1")
            
            with row1_col3:
                quantity = st.number_input("Quantity", 1, 100, 1)
                monthly_cost = st.number_input("Monthly Cost ($)", 0.0, 10000.0, 100.0)
            
            col_a, col_b, col_c = st.columns(3)
            with col_a:
                usage = st.selectbox("Usage Pattern", ["steady", "variable", "batch"])
            with col_b:
                criticality = st.selectbox("Criticality", ["high", "medium", "low"])
            with col_c:
                fault_tolerant = st.checkbox("Fault Tolerant")
            
            submitted = st.form_submit_button("➕ Add Resource")
            
            if submitted:
                st.session_state.resources.append({
                    "name": resource_name,
                    "provider": provider,
                    "resource_type": "compute",
                    "region": region,
                    "instance_type": instance_type,
                    "quantity": quantity,
                    "monthly_cost": monthly_cost,
                    "usage_pattern": usage,
                    "criticality": criticality,
                    "fault_tolerant": fault_tolerant
                })
                st.success(f"Added {resource_name}")
    
    with col2:
        st.subheader("Business Constraints")
        with st.form("constraints_form"):
            max_budget = st.number_input("Max Monthly Budget ($)", 0, 100000, 5000)
            availability = st.select_slider("Availability", ["99%", "99.9%", "99.99%"], "99.9%")
            risk_tolerance = st.select_slider("Risk Tolerance", ["low", "medium", "high"], "medium")
            st.form_submit_button("Save Constraints")
    
    # Display current resources
    if st.session_state.resources:
        st.subheader("📋 Current Infrastructure")
        df = pd.DataFrame(st.session_state.resources)
        st.dataframe(df[['name', 'provider', 'instance_type', 'region', 'quantity', 'monthly_cost']], 
                    use_container_width=True)
        
        total = df['monthly_cost'].sum()
        st.metric("Total Monthly Cost", f"${total:,.2f}")

# ===== TAB 2: Price Comparison =====
with tab2:
    st.subheader("💰 Multi-Cloud Price Comparison")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        compare_resource = st.selectbox(
            "Resource Type",
            ["ec2", "vm", "compute"],
            key="compare_resource"
        )
    
    with col2:
        compare_region = st.text_input("Region", "us-east-1", key="compare_region")
        # Show friendly region name
        st.caption(f"📍 {get_region_display_name('aws', compare_region)}")
    
    with col3:
        compare_instance = st.text_input("Instance Type", "t3.medium", key="compare_instance")
    
    if st.button("Compare Prices", type="primary", key="compare_button"):
        with st.spinner("Fetching prices from all providers..."):
            
            if st.session_state.api_mode:
                # API Mode
                try:
                    payload = {
                        "resource_type": compare_resource,
                        "specifications": {
                            "instance_type": compare_instance,
                            "os": "Linux"
                        },
                        "regions": [compare_region]
                    }
                    
                    response = requests.post(
                        f"{st.session_state.api_url}/compare-prices",
                        json=payload,
                        timeout=10
                    )
                    
                    if response.status_code == 200:
                        data = response.json()
                        st.success("✅ Price data received!")
                        display_price_chart(data, compare_instance, compare_region)
                    else:
                        st.error(f"API Error: {response.status_code}")
                        
                except Exception as e:
                    st.error(f"Error: {e}")
            
            else:
                # Local Agent Mode
                if st.session_state.agent:
                    try:
                        prices = st.session_state.agent.compare_prices(
                            specifications={"instance_type": compare_instance, "os": "Linux"},
                            regions=[compare_region]
                        )
                        st.success("✅ Price data from local agent!")
                        display_price_chart(prices, compare_instance, compare_region)
                    except Exception as e:
                        st.error(f"Agent error: {e}")
                else:
                    st.warning("Please initialize the agent first in the sidebar")

def display_price_chart(data, instance_type, region):
    """Display price comparison chart using helper"""
    
    # Extract data for plotting
    providers = []
    monthly_costs = []
    hourly_rates = []
    
    for provider, values in data.items():
        if provider != '_metadata' and isinstance(values, dict):
            providers.append(provider.upper())
            monthly_costs.append(values.get('monthly_rate', values.get('monthly', 0)))
            hourly_rates.append(values.get('hourly_rate', values.get('hourly', 0)))
    
    if providers and monthly_costs:
        df = pd.DataFrame({
            'Provider': providers,
            'Monthly Cost ($)': monthly_costs,
            'Hourly Rate ($)': hourly_rates
        })
        
        # Sort by cost
        df = df.sort_values('Monthly Cost ($)')
        
        # Display metrics
        col1, col2, col3 = st.columns(3)
        with col1:
            cheapest = df.iloc[0]
            st.metric("Cheapest Provider", cheapest['Provider'], 
                     f"${cheapest['Monthly Cost ($)']:.2f}")
        with col2:
            avg_cost = df['Monthly Cost ($)'].mean()
            st.metric("Average Cost", f"${avg_cost:.2f}")
        with col3:
            if len(df) > 1:
                savings = df['Monthly Cost ($)'].max() - df['Monthly Cost ($)'].min()
                st.metric("Max Savings", f"${savings:.2f}")
        
        # Create bar chart
        fig = px.bar(
            df,
            x='Provider',
            y='Monthly Cost ($)',
            title=f"Monthly Cost Comparison - {instance_type} in {region}",
            color='Provider',
            text_auto='.2f'
        )
        
        fig.update_layout(
            yaxis_title="Monthly Cost (USD)",
            showlegend=False,
            height=500
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Detailed table
        st.subheader("📋 Detailed Pricing")
        st.dataframe(df, use_container_width=True)
    else:
        st.warning("No price data available")
        if '_metadata' in data:
            st.json(data['_metadata'])

# ===== TAB 3: Analysis Results =====
with tab3:
    if not st.session_state.resources:
        st.info("Add some resources first in the Infrastructure tab")
    else:
        st.subheader("📊 Infrastructure Analysis")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🔍 Run Analysis", type="primary", use_container_width=True):
                with st.spinner("Analyzing infrastructure..."):
                    
                    if st.session_state.api_mode:
                        # API Mode
                        try:
                            payload = {
                                "current_infrastructure": st.session_state.resources,
                                "business_constraints": {
                                    "max_budget": 5000,
                                    "min_availability": "99.9%"
                                },
                                "optimization_goals": ["cost_reduction"]
                            }
                            
                            response = requests.post(
                                f"{st.session_state.api_url}/analyze",
                                json=payload,
                                timeout=30
                            )
                            
                            if response.status_code == 200:
                                st.session_state.analysis_result = response.json()
                                st.success("Analysis complete!")
                            else:
                                st.error(f"API Error: {response.status_code}")
                                
                        except Exception as e:
                            st.error(f"Error: {e}")
                    
                    else:
                        # Local Agent Mode
                        if st.session_state.agent:
                            try:
                                # Create request
                                from src.models.schemas import RationalizationRequest, CloudResource, BusinessConstraints
                                
                                resources = []
                                for r in st.session_state.resources:
                                    resources.append(CloudResource(
                                        name=r['name'],
                                        resource_type=r.get('resource_type', 'compute'),
                                        provider=r['provider'],
                                        region=r['region'],
                                        specifications={"instance_type": r['instance_type']},
                                        quantity=r['quantity'],
                                        usage_pattern=r['usage_pattern'],
                                        monthly_cost=r['monthly_cost'],
                                        fault_tolerant=r.get('fault_tolerant', False)
                                    ))
                                
                                constraints = BusinessConstraints()
                                request = RationalizationRequest(
                                    current_infrastructure=resources,
                                    business_constraints=constraints,
                                    optimization_goals=["cost_reduction"],
                                    time_horizon="1 year"
                                )
                                
                                # Run analysis
                                import asyncio
                                loop = asyncio.new_event_loop()
                                asyncio.set_event_loop(loop)
                                result = loop.run_until_complete(
                                    st.session_state.agent.analyze_with_llm(request)
                                )
                                loop.close()
                                
                                st.session_state.analysis_result = result
                                st.success("Analysis complete!")
                                
                            except Exception as e:
                                st.error(f"Error: {e}")
                        else:
                            st.warning("Initialize agent first")
        
        with col2:
            if st.button("📊 Demo Analysis", use_container_width=True):
                # Demo analysis without agent
                total = sum(r['monthly_cost'] for r in st.session_state.resources)
                st.session_state.analysis_result = {
                    "summary": {
                        "current_cost": total,
                        "optimized_cost": total * 0.7,
                        "savings": total * 0.3,
                        "savings_percentage": 30
                    },
                    "recommendations": [
                        {"title": "Right-size instances", "savings": total * 0.15, "risk": "low"},
                        {"title": "Reserved Instances", "savings": total * 0.25, "risk": "medium"},
                        {"title": "Spot Instances", "savings": total * 0.10, "risk": "high"}
                    ]
                }
                st.success("Demo analysis generated!")
        
        # Display results
        if st.session_state.analysis_result:
            result = st.session_state.analysis_result
            
            # Summary metrics
            if isinstance(result, dict):
                if 'summary' in result:
                    s = result['summary']
                    col1, col2, col3, col4 = st.columns(4)
                    col1.metric("Current", f"${s.get('current_cost', 0):,.2f}")
                    col2.metric("Optimized", f"${s.get('optimized_cost', 0):,.2f}")
                    col3.metric("Savings", f"${s.get('savings', 0):,.2f}")
                    col4.metric("Percentage", f"{s.get('savings_percentage', 0)}%")
                
                # Recommendations
                if 'recommendations' in result:
                    st.subheader("💡 Recommendations")
                    for rec in result['recommendations']:
                        with st.expander(f"📌 {rec.get('title', 'Recommendation')}"):
                            st.write(f"**Savings:** ${rec.get('savings', 0):,.2f}")
                            st.write(f"**Risk:** {rec.get('risk', 'medium').upper()}")
                
                # Raw output
                if 'analysis' in result:
                    with st.expander("Detailed Analysis"):
                        st.write(result['analysis'])

# ===== TAB 4: Debug =====
with tab4:
    st.subheader("🔍 Debug Information")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Session State:**")
        st.json({
            "api_mode": st.session_state.api_mode,
            "api_url": st.session_state.api_url,
            "resources_count": len(st.session_state.resources),
            "agent_initialized": st.session_state.agent is not None
        })
    
    with col2:
        if st.button("Test API Connection"):
            try:
                response = requests.get(f"{st.session_state.api_url}/health", timeout=5)
                st.json({
                    "status_code": response.status_code,
                    "response": response.json()
                })
            except Exception as e:
                st.error(str(e))
        
        if st.button("Test SSL Configuration"):
            try:
                from src.utils.helpers import apply_ssl_fix
                import certifi
                st.json({
                    "certifi_path": certifi.where(),
                    "ssl_fix_applied": True
                })
            except Exception as e:
                st.error(str(e))
    
    if st.session_state.resources:
        st.markdown("**Current Resources:**")
        st.json(st.session_state.resources)

# Footer
st.markdown("---")
st.markdown("Made with ❤️ using LangChain, OpenAI, and Streamlit")