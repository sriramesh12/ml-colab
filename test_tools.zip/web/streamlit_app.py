"""
Streamlit web interface for Cloud Rationalization Agent
Complete fixed version - No 60s wait on errors, agent persists, auto-initializes
"""
import sys
import os
from pathlib import Path

# Add the project root to Python path
project_root = str(Path(__file__).parent.parent)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# Import helpers with fallbacks for missing functions
try:
    from src.utils.helpers import apply_ssl_fix, format_currency, safe_serialize
    apply_ssl_fix()
    HELPERS_AVAILABLE = True
except ImportError:
    HELPERS_AVAILABLE = False
    # Define fallback functions
    def format_currency(amount, currency="USD"):
        return f"${amount:,.2f}" if amount else "$0.00"
    def safe_serialize(obj):
        if hasattr(obj, 'dict'):
            return obj.dict()
        return obj

# Now try the main imports
try:
    from src.agent import CloudRationalizationAgent
    from src.models.schemas import (
        RationalizationRequest, 
        CloudResource,
        BusinessConstraints,
        CloudProvider,
        ResourceType,
        UsagePattern,
        OptimizationGoal
    )
    print("✅ Imports successful")
except ImportError as e:
    print(f"❌ Import error: {e}")
    print(f"Current sys.path: {sys.path}")

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import asyncio
import json
from datetime import datetime
import requests
from typing import Dict, Any, List, Optional
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# ===== PAGE CONFIGURATION =====
st.set_page_config(
    page_title="Cloud Rationalization Agent",
    page_icon="☁️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ===== HELPER FUNCTIONS - DEFINED FIRST =====

def _safe_to_dict(raw: Any) -> Dict[str, Any]:
    """Accept dict or JSON-string and return a dict; else empty dict."""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {}
    return {}

def _to_dataframe(prices: Dict[str, Any]) -> pd.DataFrame:
    """
    Normalize API shape into tidy data.
    Expected keys: aws_pricing_tool / azure_pricing_tool / gcp_pricing_tool
    Each can be a dict or a JSON string.
    """
    rows: List[Dict[str, Any]] = []
    for provider_key, payload in prices.items():
        # Skip metadata keys
        if provider_key.startswith('_') or provider_key == 'metadata':
            continue
            
        data = _safe_to_dict(payload)
        if not data:
            continue

        provider = data.get("provider") or provider_key.replace("_pricing_tool", "").upper()
        hourly = data.get("hourly_rate") or data.get("hourly")
        monthly = data.get("monthly_rate") or data.get("monthly")
        currency = data.get("currency", "USD")
        pricing_model = data.get("pricing_model", "On-Demand")
        region = data.get("region") or (data.get("specifications") or {}).get("region")

        # Keep only valid numeric rows
        if hourly is None and monthly is None:
            continue

        rows.append({
            "provider": provider,
            "region": region,
            "pricing_model": pricing_model,
            "currency": currency,
            "hourly_rate": float(hourly) if hourly is not None else None,
            "monthly_rate": float(monthly) if monthly is not None else None,
        })

    return pd.DataFrame(rows)

def display_price_chart(data, instance_type, region):
    """Display price comparison chart"""
    st.subheader(f"💰 Price Comparison: {instance_type} in {region}")
    
    # Extract data for plotting
    providers = []
    monthly_costs = []
    hourly_rates = []
    currencies = []
    
    if isinstance(data, dict):
        for provider, values in data.items():
            if provider != '_metadata' and isinstance(values, dict):
                providers.append(provider.upper())
                monthly = values.get('monthly_rate', values.get('monthly', 0))
                monthly_costs.append(float(monthly) if monthly else 0)
                hourly = values.get('hourly_rate', values.get('hourly', 0))
                hourly_rates.append(float(hourly) if hourly else 0)
                currencies.append(values.get('currency', 'USD'))
    
    if providers and monthly_costs:
        df = pd.DataFrame({
            'Provider': providers,
            'Monthly Cost ($)': monthly_costs,
            'Hourly Rate ($)': hourly_rates,
            'Currency': currencies
        })
        
        # Sort by cost
        df = df.sort_values('Monthly Cost ($)')
        
        # Display metrics
        col1, col2, col3 = st.columns(3)
        with col1:
            cheapest = df.iloc[0]
            st.metric("Cheapest Provider", cheapest['Provider'], 
                     f"${cheapest['Monthly Cost ($)']:.2f}")
        with col2:
            avg_cost = df['Monthly Cost ($)'].mean()
            st.metric("Average Cost", f"${avg_cost:.2f}")
        with col3:
            if len(df) > 1:
                savings = df['Monthly Cost ($)'].max() - df['Monthly Cost ($)'].min()
                st.metric("Max Savings", f"${savings:.2f}")
        
        # Create bar chart
        fig = px.bar(
            df,
            x='Provider',
            y='Monthly Cost ($)',
            title=f"Monthly Cost Comparison - {instance_type} in {region}",
            color='Provider',
            text_auto='.2f'
        )
        
        fig.update_layout(
            yaxis_title="Monthly Cost (USD)",
            showlegend=False,
            height=500
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Detailed table
        st.subheader("📋 Detailed Pricing")
        st.dataframe(df, use_container_width=True)
    else:
        st.warning("No price data available")
        if '_metadata' in data:
            st.json(data['_metadata'])

def render_enhanced_pricing_dashboard(response):
    """Render enhanced pricing dashboard with charts and tables"""
    try:
        if response.status_code != 200:
            st.error(f"API error: {response.text}")
            return

        raw = response.json()
        df = _to_dataframe(raw)

        if df.empty:
            st.warning("No valid pricing data received from API.")
            with st.expander("Raw API payload"):
                st.json(raw)
            return

        # Normalize currency
        currency = df["currency"].dropna().iloc[0] if not df["currency"].dropna().empty else "USD"

        # Calculate monthly effective rate
        df["monthly_effective"] = df.apply(
            lambda r: r["monthly_rate"]
            if pd.notna(r["monthly_rate"])
            else (r["hourly_rate"] * 730 if pd.notna(r["hourly_rate"]) else None),
            axis=1
        )

        # Drop rows missing monthly_effective
        df_plot = df.dropna(subset=["monthly_effective"]).copy()
        if df_plot.empty:
            st.warning("No billable rates found to plot.")
            with st.expander("Parsed DataFrame"):
                st.dataframe(df)
            return

        # Find cheapest provider
        cheapest_idx = df_plot["monthly_effective"].idxmin()
        cheapest_row = df_plot.loc[cheapest_idx]
        cheapest_provider = cheapest_row["provider"]
        cheapest_cost = float(cheapest_row["monthly_effective"])

        df_plot["savings_abs"] = df_plot["monthly_effective"] - cheapest_cost
        df_plot["savings_pct"] = df_plot["savings_abs"] / df_plot["monthly_effective"] * 100
        df_plot["label_monthly"] = df_plot.apply(
            lambda r: format_currency(r["monthly_effective"], currency), axis=1
        )

        # KPI cards
        c1, c2, c3 = st.columns(3)
        with c1:
            st.metric("Cheapest Provider", cheapest_provider)
        with c2:
            st.metric("Cheapest Monthly Cost", format_currency(cheapest_cost, currency))
        with c3:
            max_savings = df_plot.loc[df_plot["provider"] != cheapest_provider, "savings_abs"].max()
            if pd.notna(max_savings):
                st.metric("Max Monthly Savings", format_currency(max_savings, currency))
            else:
                st.metric("Max Monthly Savings", "-")

        # Monthly bar chart
        st.subheader("Monthly Cost Comparison")
        fig_monthly = px.bar(
            df_plot.sort_values("monthly_effective"),
            x="provider",
            y="monthly_effective",
            color="provider",
            text="label_monthly",
            hover_data=["pricing_model", "region", "currency"],
            title="Monthly Cloud Cost (Effective)",
        )
        fig_monthly.update_traces(textposition="outside")
        fig_monthly.update_layout(
            yaxis_title=f"Monthly Cost ({currency})",
            xaxis_title="Provider",
            showlegend=False,
        )
        st.plotly_chart(fig_monthly, use_container_width=True)

        # Hourly chart if available
        if df_plot["hourly_rate"].notna().any():
            st.subheader("Hourly Cost Comparison")
            df_hourly = df_plot.dropna(subset=["hourly_rate"]).copy()
            df_hourly["label_hourly"] = df_hourly.apply(
                lambda r: format_currency(r["hourly_rate"], currency), axis=1
            )
            fig_hourly = px.bar(
                df_hourly.sort_values("hourly_rate"),
                x="provider",
                y="hourly_rate",
                color="provider",
                text="label_hourly",
                hover_data=["pricing_model", "region", "currency"],
                title="Hourly Cloud Cost",
            )
            fig_hourly.update_traces(textposition="outside")
            st.plotly_chart(fig_hourly, use_container_width=True)

        # Pie chart
        st.subheader("Monthly Spend Share")
        fig_pie = px.pie(
            df_plot,
            names="provider",
            values="monthly_effective",
            hole=0.35,
            title="Share of Monthly Cost by Provider"
        )
        st.plotly_chart(fig_pie, use_container_width=True)

        # Data table
        st.subheader("Detailed Pricing (Normalized)")
        nice_df = df_plot[[
            "provider", "region", "pricing_model", "currency",
            "hourly_rate", "monthly_rate", "monthly_effective",
            "savings_abs", "savings_pct"
        ]].copy()

        # Format for display
        display_df = nice_df.copy()
        display_df["hourly_rate"] = display_df["hourly_rate"].apply(
            lambda v: format_currency(v, currency) if pd.notna(v) else "-"
        )
        display_df["monthly_rate"] = display_df["monthly_rate"].apply(
            lambda v: format_currency(v, currency) if pd.notna(v) else "-"
        )
        display_df["monthly_effective"] = display_df["monthly_effective"].apply(
            lambda v: format_currency(v, currency)
        )
        display_df["savings_abs"] = display_df["savings_abs"].apply(
            lambda v: format_currency(v, currency) if pd.notna(v) else "-"
        )
        display_df["savings_pct"] = display_df["savings_pct"].apply(
            lambda v: f"{v:,.1f}%" if pd.notna(v) else "-"
        )

        st.dataframe(display_df, use_container_width=True)

        # Download button
        csv = nice_df.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="Download CSV (Normalized Pricing)",
            data=csv,
            file_name="cloud_pricing_comparison.csv",
            mime="text/csv"
        )

        # Raw payloads
        st.markdown("### Provider Payloads")
        for k, v in raw.items():
            if not k.startswith('_'):
                with st.expander(k.upper()):
                    parsed = _safe_to_dict(v)
                    st.json(parsed if parsed else v)

    except Exception as ex:
        st.error(f"Error while rendering pricing dashboard: {ex}")
        import traceback
        st.code(traceback.format_exc())
        
def run_analysis_sync(agent, request):
    """Run async analysis in a synchronous way for Streamlit"""
    import asyncio
    import threading
    
    result_container = []
    error_container = []
    
    def run_async():
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            # FIX: Use asyncio.run() which handles loop cleanup properly
            result = loop.run_until_complete(
                asyncio.wait_for(
                    agent.analyze_with_llm(request),
                    timeout=30
                )
            )
            loop.close()
            result_container.append(result)
        except asyncio.TimeoutError:
            error_container.append("timeout")
        except Exception as e:
            error_container.append(str(e))
    
    thread = threading.Thread(target=run_async)
    thread.start()
    thread.join(timeout=35)
    
    if error_container:
        return {"error": error_container[0], "mode": "error"}
    return result_container[0] if result_container else {"error": "No result", "mode": "error"}

# ===== SESSION STATE INITIALIZATION =====
if 'agent' not in st.session_state:
    st.session_state.agent = None
if 'resources' not in st.session_state:
    st.session_state.resources = []
if 'analysis_result' not in st.session_state:
    st.session_state.analysis_result = None
if 'api_mode' not in st.session_state:
    st.session_state.api_mode = False  # False = local mode, True = API mode
if 'api_url' not in st.session_state:
    st.session_state.api_url = "http://localhost:8080"
if 'constraints' not in st.session_state:
    st.session_state.constraints = {
        "max_budget": 10000.0,
        "availability": "99.9%",
        "compliance": [],
        "risk_tolerance": "medium",
        "optimization_goals": ["cost_reduction"]
    }
if 'creds' not in st.session_state:
    st.session_state.creds = {
        'aws': False,
        'azure': False,
        'gcp': False,
        'openai': False
    }
if 'use_llm' not in st.session_state:
    st.session_state.use_llm = False
if 'operation_in_progress' not in st.session_state:
    st.session_state.operation_in_progress = False

# ===== CUSTOM CSS =====
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1E88E5;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        text-align: center;
    }
    .recommendation-card {
        background-color: #e8f4fd;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
        border-left: 4px solid #1E88E5;
    }
    .savings-positive {
        color: #00C853;
        font-weight: bold;
    }
    .stButton button {
        width: 100%;
    }
</style>
""", unsafe_allow_html=True)

# ===== SIDEBAR =====
with st.sidebar:
    st.image("https://img.icons8.com/color/96/000000/cloud--v1.png", width=80)
    st.title("Cloud Rationalization Agent")
    
    # Mode selection
    st.header("⚙️ Operation Mode")
    mode = st.radio(
        "Select how to run the agent:",
        ["🧠 LLM Mode (AI Explanations)", "🔧 Tool-Only Mode (Faster)"],
        help="LLM Mode uses OpenAI for natural language explanations. Tool-Only Mode works without OpenAI.",
        key="mode_selector"
    )
    
    # Set local mode flag and LLM preference
    st.session_state.api_mode = False
    st.session_state.use_llm = "LLM Mode" in mode
    
    # Auto-detect credentials from .env
    env_openai = os.getenv("OPENAI_API_KEY")
    env_aws_key = os.getenv("AWS_ACCESS_KEY_ID")
    env_aws_secret = os.getenv("AWS_SECRET_ACCESS_KEY")
    env_azure = os.getenv("AZURE_SUBSCRIPTION_KEY")
    env_gcp = os.getenv("GCP_CREDENTIALS_PATH")
    
    # Display credential status
    st.header("🔑 Detected Credentials")
    
    col1, col2 = st.columns(2)
    with col1:
        if env_openai:
            st.success("✅ OpenAI")
        else:
            st.info("⬜ OpenAI (not found)")
    
    with col2:
        if env_aws_key and env_aws_secret:
            st.success("✅ AWS")
        else:
            st.info("⬜ AWS (not found)")
    
    col1, col2 = st.columns(2)
    with col1:
        if env_azure:
            st.success("✅ Azure")
        else:
            st.info("⬜ Azure (not found)")
    
    with col2:
        if env_gcp:
            st.success("✅ GCP")
        else:
            st.info("⬜ GCP (not found)")
    
    # Warning about missing credentials
    missing = []
    if not (env_aws_key and env_aws_secret):
        missing.append("AWS")
    if not env_azure:
        missing.append("Azure")
    if not env_gcp:
        missing.append("GCP")
    
    if missing:
        st.warning(f"⚠️ Missing credentials for: {', '.join(missing)}. These providers will use demo pricing.")
    
    # LLM Mode warning if OpenAI missing
    if st.session_state.use_llm and not env_openai:
        st.error("❌ OpenAI API key not found in .env file. Switch to Tool-Only Mode or add OPENAI_API_KEY to .env")
    
    # Initialize button - OPTIONAL now, agent will auto-initialize on analysis
    with st.expander("🔧 Manual Initialization (Optional)"):
        st.markdown("Agent will auto-initialize when you run analysis. Manual init only needed for testing.")
        if st.button("🔄 Initialize Agent Manually", key="init_agent_button"):
            st.session_state.operation_in_progress = True
            with st.spinner("Initializing agent... (this may take a few seconds)"):
                try:
                    # Prepare credentials from env
                    aws_creds = None
                    if env_aws_key and env_aws_secret:
                        aws_creds = {
                            'aws_access_key_id': env_aws_key,
                            'aws_secret_access_key': env_aws_secret
                        }
                    
                    azure_creds = None
                    if env_azure:
                        azure_creds = {'subscription_key': env_azure}
                    
                    gcp_creds = None
                    if env_gcp:
                        gcp_creds = {'credentials_path': env_gcp}
                    
                    # Initialize agent - pass OpenAI key only if in LLM mode
                    openai_key = env_openai if st.session_state.use_llm else None
                    
                    st.session_state.agent = CloudRationalizationAgent(
                        openai_api_key=openai_key,
                        aws_credentials=aws_creds,
                        azure_credentials=azure_creds,
                        gcp_credentials=gcp_creds
                    )
                    
                    # Store which credentials are configured
                    st.session_state.creds = {
                        'aws': bool(aws_creds),
                        'azure': bool(azure_creds),
                        'gcp': bool(gcp_creds),
                        'openai': bool(openai_key)
                    }
                    
                    mode_text = "LLM MODE" if st.session_state.agent.llm else "TOOL-ONLY MODE"
                    st.success(f"✅ Agent initialized in {mode_text}!")
                    
                except Exception as e:
                    st.error(f"Failed to initialize: {e}")
                finally:
                    st.session_state.operation_in_progress = False
    
    st.markdown("---")
    st.header("🌐 API Mode")
    st.markdown("Connect to a remote agent server")
    
    use_api = st.checkbox("Use API Mode instead", key="use_api_checkbox")
    
    if use_api:
        st.session_state.api_mode = True
        st.session_state.api_url = st.text_input(
            "API URL",
            value="http://localhost:8080",
            help="URL of the FastAPI backend",
            key="api_url_input"
        )
        
        if st.button("🔍 Check API Health", key="check_api_button"):
            st.session_state.operation_in_progress = True
            with st.spinner("Checking API status..."):
                try:
                    response = requests.get(f"{st.session_state.api_url}/health", timeout=5)
                    if response.status_code == 200:
                        data = response.json()
                        st.success(f"✅ API is healthy")
                        
                        # Try to get credential status from API
                        try:
                            creds_response = requests.get(f"{st.session_state.api_url}/debug/credentials", timeout=5)
                            if creds_response.status_code == 200:
                                creds = creds_response.json()
                                st.markdown("### Server Credentials:")
                                
                                # Display server credentials
                                c1, c2, c3 = st.columns(3)
                                with c1:
                                    if creds.get('aws_configured'):
                                        st.success("✅ AWS Live")
                                    else:
                                        st.info("⬜ AWS Demo")
                                with c2:
                                    if creds.get('azure_configured'):
                                        st.success("✅ Azure Live")
                                    else:
                                        st.info("⬜ Azure Demo")
                                with c3:
                                    if creds.get('gcp_configured'):
                                        st.success("✅ GCP Live")
                                    else:
                                        st.info("⬜ GCP Demo")
                                
                                if creds.get('openai_configured'):
                                    st.success(f"✅ OpenAI: {creds.get('agent_mode', 'full').upper()}")
                                else:
                                    st.info("⬜ OpenAI: Tool-only mode")
                        except:
                            st.info("ℹ️ Could not fetch server credential status")
                    else:
                        st.error("❌ API error")
                except Exception as e:
                    st.error(f"❌ Cannot connect: {e}")
                finally:
                    st.session_state.operation_in_progress = False
    else:
        st.session_state.api_mode = False
    
    st.markdown("---")
    st.markdown("### 📊 Resource Stats")
    
    # Resource stats
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Total Resources", len(st.session_state.resources))
    with col2:
        if st.session_state.resources:
            total_cost = sum(r.get('monthly_cost', 0) for r in st.session_state.resources)
            st.metric("Total Cost", f"${total_cost:,.0f}")
        else:
            st.metric("Total Cost", "$0")
    
    # Show which providers will use live pricing
    if st.session_state.get('creds') and not st.session_state.api_mode:
        st.markdown("### 🔑 Live Pricing For:")
        live = []
        if st.session_state.creds.get('aws'):
            live.append("AWS")
        if st.session_state.creds.get('azure'):
            live.append("Azure")
        if st.session_state.creds.get('gcp'):
            live.append("GCP")
        
        if live:
            st.success(f"✅ {', '.join(live)}")
        else:
            st.info("ℹ️ All providers using demo pricing")
    
    # Kill switch for stuck operations
    if st.session_state.get('operation_in_progress', False):
        if st.button("🛑 Force Stop Operation", key="stop_button"):
            st.session_state.operation_in_progress = False
            st.warning("Operation stopped. You can try again.")
            st.rerun()
    
    # Clear button
    if st.button("🗑️ Clear All Resources", key="clear_button"):
        if st.session_state.resources:
            st.session_state.resources = []
            st.session_state.analysis_result = None
            st.success("✅ All resources cleared!")
            # No rerun needed - state updated
        else:
            st.warning("No resources to clear")

# ===== MAIN HEADER =====
st.markdown("<h1 class='main-header'>☁️ Cloud Infrastructure Optimizer</h1>", unsafe_allow_html=True)

# ===== TABS =====
tab1, tab2, tab3, tab4 = st.tabs([
    "📋 Infrastructure Input", 
    "💰 Price Comparison", 
    "📈 Analysis Results",
    "📊 Reports"
])

# ===== TAB 1: Infrastructure Input =====
with tab1:
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Add Cloud Resource")
        
        with st.form("resource_form"):
            # Row 1: Basic info
            row1_col1, row1_col2, row1_col3 = st.columns(3)
            with row1_col1:
                resource_name = st.text_input("Resource Name", value="web-server-01")
            with row1_col2:
                provider = st.selectbox(
                    "Cloud Provider",
                    options=[p.value for p in CloudProvider],
                    format_func=lambda x: x.upper()
                )
            with row1_col3:
                resource_type = st.selectbox(
                    "Resource Type",
                    options=[r.value for r in ResourceType],
                    format_func=lambda x: x.upper(),
                    index=0
                )
            
            # Row 2: Instance details
            row2_col1, row2_col2, row2_col3 = st.columns(3)
            with row2_col1:
                instance_type = st.text_input("Instance Type", value="t3.medium")
            with row2_col2:
                region = st.text_input("Region", value="us-east-1")
            with row2_col3:
                quantity = st.number_input("Quantity", min_value=1, value=1)
            
            # Row 3: Cost and usage
            row3_col1, row3_col2, row3_col3 = st.columns(3)
            with row3_col1:
                monthly_cost = st.number_input(
                    "Current Monthly Cost ($)",
                    min_value=0.0,
                    value=100.0,
                    step=10.0
                )
            with row3_col2:
                usage_pattern = st.selectbox(
                    "Usage Pattern",
                    options=[u.value for u in UsagePattern],
                    format_func=lambda x: x.upper()
                )
            with row3_col3:
                criticality = st.select_slider(
                    "Criticality",
                    options=["low", "medium", "high"],
                    value="medium"
                )
            
            # Row 4: Additional options
            row4_col1, row4_col2 = st.columns(2)
            with row4_col1:
                fault_tolerant = st.checkbox("Fault Tolerant")
            with row4_col2:
                auto_scaling = st.checkbox("Auto Scaling Enabled")
            
            # EXPANDED SPECIFICATIONS
            with st.expander("💻 Detailed Specifications"):
                spec_col1, spec_col2, spec_col3 = st.columns(3)
                with spec_col1:
                    os_type = st.selectbox("Operating System", ["Linux", "Windows", "Other"])
                    cpu = st.number_input("vCPU Cores", min_value=1, value=2)
                with spec_col2:
                    memory = st.number_input("Memory (GB)", min_value=0.5, value=8.0, step=0.5)
                    storage_type = st.selectbox("Storage Type", ["SSD", "HDD", "NVMe"])
                with spec_col3:
                    storage = st.number_input("Storage (GB)", min_value=10, value=100, step=10)
                    network = st.selectbox("Network Performance", ["Low", "Medium", "High"])
            
            submitted = st.form_submit_button("➕ Add Resource", type="primary")
            
            if submitted:
                new_resource = {
                    "name": resource_name,
                    "provider": provider,
                    "resource_type": resource_type,
                    "region": region,
                    "instance_type": instance_type,
                    "quantity": quantity,
                    "usage_pattern": usage_pattern,
                    "monthly_cost": monthly_cost,
                    "fault_tolerant": fault_tolerant,
                    "criticality": criticality,
                    "auto_scaling": auto_scaling,
                    "specifications": {
                        "os": os_type,
                        "cpu": cpu,
                        "memory": memory,
                        "storage": storage,
                        "storage_type": storage_type,
                        "network": network,
                        "instance_type": instance_type
                    }
                }
                # Append to session state WITHOUT rerun
                st.session_state.resources.append(new_resource)
                st.success(f"✅ Added {resource_name} (Total: {len(st.session_state.resources)} resources)")
    
    with col2:
        st.subheader("Business Constraints")
        with st.form("constraints_form"):
            max_budget = st.number_input(
                "Max Monthly Budget ($)",
                min_value=0.0,
                value=st.session_state.constraints["max_budget"],
                step=1000.0
            )
            
            availability = st.select_slider(
                "Required Availability",
                options=["99%", "99.9%", "99.99%", "99.999%"],
                value=st.session_state.constraints["availability"]
            )
            
            compliance = st.multiselect(
                "Compliance Requirements",
                ["HIPAA", "GDPR", "PCI-DSS", "SOC2", "ISO27001"],
                default=st.session_state.constraints["compliance"]
            )
            
            risk_tolerance = st.select_slider(
                "Risk Tolerance",
                options=["low", "medium", "high"],
                value=st.session_state.constraints["risk_tolerance"]
            )
            
            optimization_goals = st.multiselect(
                "Optimization Goals",
                [g.value for g in OptimizationGoal],
                default=st.session_state.constraints["optimization_goals"]
            )
            
            if st.form_submit_button("Save Constraints"):
                st.session_state.constraints = {
                    "max_budget": max_budget,
                    "availability": availability,
                    "compliance": compliance,
                    "risk_tolerance": risk_tolerance,
                    "optimization_goals": optimization_goals
                }
                st.success("Constraints saved!")
    
    # Display current resources
    if st.session_state.resources:
        st.markdown("---")
        st.subheader("📋 Current Infrastructure")
        
        df = pd.DataFrame(st.session_state.resources)
        
        # Metrics row
        metric_col1, metric_col2, metric_col3, metric_col4 = st.columns(4)
        with metric_col1:
            st.metric("Total Resources", len(df))
        with metric_col2:
            total_cost = df['monthly_cost'].sum()
            st.metric("Total Monthly Cost", f"${total_cost:,.2f}")
        with metric_col3:
            avg_cost = df['monthly_cost'].mean()
            st.metric("Avg Cost/Resource", f"${avg_cost:,.2f}")
        with metric_col4:
            providers = df['provider'].nunique()
            st.metric("Cloud Providers", providers)
        
        # Resource table
        st.dataframe(
            df[['name', 'provider', 'instance_type', 'region', 'quantity', 
                'monthly_cost', 'usage_pattern', 'criticality']],
            use_container_width=True
        )
        
        # Cost visualization
        fig = px.bar(
            df, 
            x='name', 
            y='monthly_cost', 
            color='provider',
            title="Monthly Costs by Resource",
            labels={'monthly_cost': 'Cost ($)', 'name': 'Resource'}
        )
        st.plotly_chart(fig, use_container_width=True)
        
        # Run analysis button
        col_btn1, col_btn2, col_btn3 = st.columns([1, 2, 1])
        with col_btn2:
            analysis_disabled = st.session_state.get('operation_in_progress', False)
            if st.button("🚀 Run Optimization Analysis", type="primary", use_container_width=True, disabled=analysis_disabled):
                st.session_state.operation_in_progress = True
                
                # AUTO-INITIALIZE AGENT IF NEEDED
                if not st.session_state.api_mode and not st.session_state.agent:
                    with st.spinner("Auto-initializing agent..."):
                        try:
                            env_openai = os.getenv("OPENAI_API_KEY")
                            env_aws_key = os.getenv("AWS_ACCESS_KEY_ID")
                            env_aws_secret = os.getenv("AWS_SECRET_ACCESS_KEY")
                            env_azure = os.getenv("AZURE_SUBSCRIPTION_KEY")
                            env_gcp = os.getenv("GCP_CREDENTIALS_PATH")
                            
                            aws_creds = None
                            if env_aws_key and env_aws_secret:
                                aws_creds = {
                                    'aws_access_key_id': env_aws_key,
                                    'aws_secret_access_key': env_aws_secret
                                }
                            
                            azure_creds = None
                            if env_azure:
                                azure_creds = {'subscription_key': env_azure}
                            
                            gcp_creds = None
                            if env_gcp:
                                gcp_creds = {'credentials_path': env_gcp}
                            
                            openai_key = env_openai if st.session_state.use_llm else None
                            
                            st.session_state.agent = CloudRationalizationAgent(
                                openai_api_key=openai_key,
                                aws_credentials=aws_creds,
                                azure_credentials=azure_creds,
                                gcp_credentials=gcp_creds
                            )
                            
                            st.session_state.creds = {
                                'aws': bool(aws_creds),
                                'azure': bool(azure_creds),
                                'gcp': bool(gcp_creds),
                                'openai': bool(openai_key)
                            }
                            
                            st.success("✅ Agent auto-initialized")
                        except Exception as e:
                            st.error(f"Failed to auto-initialize agent: {e}")
                            st.session_state.operation_in_progress = False
                            st.stop()
                
                if st.session_state.api_mode:
                    # API Mode
                    with st.spinner("Calling API for analysis..."):
                        try:
                            resources_data = []
                            for r in st.session_state.resources:
                                resources_data.append({
                                    "name": r['name'],
                                    "resource_type": r['resource_type'],
                                    "provider": r['provider'],
                                    "region": r['region'],
                                    "specifications": r['specifications'],
                                    "quantity": r['quantity'],
                                    "usage_pattern": r['usage_pattern'],
                                    "monthly_cost": r['monthly_cost'],
                                    "fault_tolerant": r['fault_tolerant']
                                })
                            
                            response = requests.post(
                                f"{st.session_state.api_url}/analyze",
                                json={
                                    "current_infrastructure": resources_data,
                                    "business_constraints": st.session_state.constraints,
                                    "optimization_goals": st.session_state.constraints["optimization_goals"],
                                    "time_horizon": "1 year"
                                },
                                timeout=30
                            )
                            
                            if response.status_code == 200:
                                st.session_state.analysis_result = response.json()
                                st.success("Analysis complete! Check the Analysis Results tab.")
                            else:
                                error_msg = response.text
                                st.error(f"API error: {response.status_code}")
                                if "quota" in error_msg.lower() or "429" in error_msg:
                                    st.warning("⚠️ API quota exceeded. The server may be rate-limited.")
                                
                        except requests.exceptions.Timeout:
                            st.error("API request timed out after 30 seconds")
                        except Exception as e:
                            st.error(f"Error: {e}")
                        finally:
                            st.session_state.operation_in_progress = False
                
                else:
                    # Local Agent Mode
                    # if st.session_state.agent:
                    #     with st.spinner("Analyzing infrastructure..."):
                    #         try:
                    #             # Convert to Pydantic models
                    #             resources = []
                    #             for r in st.session_state.resources:
                    #                 resources.append(CloudResource(
                    #                     name=r['name'],
                    #                     resource_type=r['resource_type'],
                    #                     provider=r['provider'],
                    #                     region=r['region'],
                    #                     specifications=r['specifications'],
                    #                     quantity=r['quantity'],
                    #                     usage_pattern=r['usage_pattern'],
                    #                     monthly_cost=r['monthly_cost'],
                    #                     fault_tolerant=r['fault_tolerant']
                    #                 ))
                                
                    #             constraints = BusinessConstraints(
                    #                 max_budget=st.session_state.constraints["max_budget"],
                    #                 min_availability=st.session_state.constraints["availability"],
                    #                 compliance_requirements=st.session_state.constraints["compliance"],
                    #                 risk_tolerance=st.session_state.constraints["risk_tolerance"]
                    #             )
                                
                    #             goals = [OptimizationGoal(g) for g in st.session_state.constraints["optimization_goals"]]
                                
                    #             request = RationalizationRequest(
                    #                 current_infrastructure=resources,
                    #                 business_constraints=constraints,
                    #                 optimization_goals=goals,
                    #                 time_horizon="1 year"
                    #             )
                                
                    #             # Run async analysis with timeout
                    #             loop = asyncio.new_event_loop()
                    #             asyncio.set_event_loop(loop)
                                
                    #             try:
                    #                 # Create task
                    #                 task = asyncio.ensure_future(
                    #                     st.session_state.agent.analyze_with_llm(request),
                    #                     loop=loop
                    #                 )
                                    
                    #                 # Wait for result with timeout
                    #                 result = loop.run_until_complete(
                    #                     asyncio.wait_for(task, timeout=30)
                    #                 )
                                    
                    #                 if result:
                    #                     st.session_state.analysis_result = safe_serialize(result)
                    #                     st.success("Analysis complete! Check the Analysis Results tab.")
                                    
                    #             except asyncio.TimeoutError:
                    #                 st.error("⏱️ Analysis timed out after 30 seconds")
                    #                 task.cancel()
                    #                 try:
                    #                     loop.run_until_complete(task)
                    #                 except:
                    #                     pass
                    #             except Exception as e:
                    #                 error_msg = str(e)
                    #                 st.error(f"❌ Analysis failed: {error_msg}")
                                    
                    #                 # Check for quota/rate limit errors - IMMEDIATE STOP
                    #                 if "429" in error_msg or "quota" in error_msg.lower() or "rate limit" in error_msg.lower():
                    #                     st.warning("⚠️ OpenAI quota exceeded or rate limited. The agent will continue in TOOL-ONLY mode for this session.")
                    #                     # Optionally downgrade
                    #                     if hasattr(st.session_state.agent, 'llm'):
                    #                         st.session_state.agent.llm = None
                    #             finally:
                    #                 loop.close()
                    #                 # IMPORTANT: Reset operation flag immediately
                    #                 st.session_state.operation_in_progress = False
                                    
                    #         except Exception as e:
                    #             st.error(f"Analysis error: {e}")
                    #             st.session_state.operation_in_progress = False
                    # else:
                    #     st.warning("Agent initialization failed")
                    #     st.session_state.operation_in_progress = False
                    # Local Agent Mode - FIXED event loop issue
                    if st.session_state.agent:
                        with st.spinner("Analyzing infrastructure... (this may take 10-30 seconds)"):
                            try:
                                # Convert to Pydantic models (your existing code)
                                resources = []
                                for r in st.session_state.resources:
                                    resources.append(CloudResource(
                                        name=r['name'],
                                        resource_type=r['resource_type'],
                                        provider=r['provider'],
                                        region=r['region'],
                                        specifications=r['specifications'],
                                        quantity=r['quantity'],
                                        usage_pattern=r['usage_pattern'],
                                        monthly_cost=r['monthly_cost'],
                                        fault_tolerant=r['fault_tolerant']
                                    ))
                                
                                constraints = BusinessConstraints(
                                    max_budget=st.session_state.constraints["max_budget"],
                                    min_availability=st.session_state.constraints["availability"],
                                    compliance_requirements=st.session_state.constraints["compliance"],
                                    risk_tolerance=st.session_state.constraints["risk_tolerance"]
                                )
                                
                                goals = [OptimizationGoal(g) for g in st.session_state.constraints["optimization_goals"]]
                                
                                request = RationalizationRequest(
                                    current_infrastructure=resources,
                                    business_constraints=constraints,
                                    optimization_goals=goals,
                                    time_horizon="1 year"
                                )
                                
                                # FIX: Use synchronous wrapper instead of direct await
                                result = run_analysis_sync(st.session_state.agent, request)
                                
                                # Handle quota error specially
                                if isinstance(result, dict):
                                    if result.get('mode') == 'quota_error' or result.get('mode') == 'quota_cached':
                                        st.error("❌ OpenAI Quota Exceeded")
                                        
                                        # Show helpful message with options
                                        st.warning("""
                                        ## ⚠️ OpenAI API quota exceeded
                                        
                                        **Your options:**
                                        
                                        1. **Switch to Tool-Only Mode** - Click "Tool-Only Mode" in the sidebar
                                        2. **Add funds** to your OpenAI account at [platform.openai.com](https://platform.openai.com/account/billing)
                                        3. **Use a different API key** in your `.env` file
                                        4. **Use API Mode** with a server that has a working key
                                        
                                        The agent will continue with **demo data** for now.
                                        """)
                                        
                                        # Show demo data
                                        total_cost = sum(r.monthly_cost for r in resources)
                                        st.session_state.analysis_result = {
                                            "summary": {
                                                "current_cost": total_cost,
                                                "optimized_cost": total_cost * 0.7,
                                                "savings": total_cost * 0.3,
                                                "savings_percentage": 30
                                            },
                                            "analysis": "## Demo Analysis\n\nOpenAI quota exceeded. Showing demo recommendations.",
                                            "recommendations": [
                                                {"title": "Right-size instances", "savings": total_cost * 0.15, "risk": "low"},
                                                {"title": "Reserved Instances", "savings": total_cost * 0.25, "risk": "medium"}
                                            ]
                                        }
                                        st.success("Demo analysis generated!")
                                        
                                    elif result.get('mode') == 'timeout_error':
                                        st.error("⏱️ Analysis timed out. Please try again or use Tool-Only Mode.")
                                        
                                    elif 'error' in result:
                                        st.error(f"Analysis error: {result['error']}")
                                        
                                    else:
                                        st.session_state.analysis_result = safe_serialize(result)
                                        st.success("Analysis complete! Check the Analysis Results tab.")
                                
                            except Exception as e:
                                st.error(f"Analysis error: {e}")
                                import traceback
                                st.code(traceback.format_exc())
                            finally:
                                st.session_state.operation_in_progress = False
                    else:
                        st.warning("Please initialize the agent first in the sidebar")
                        st.session_state.operation_in_progress = False
# ===== TAB 2: Price Comparison =====
with tab2:
    st.subheader("💰 Multi-Cloud Price Comparison")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        compare_resource = st.selectbox(
            "Resource Type",
            ["ec2", "vm", "compute"],
            key="compare_resource"
        )
    
    with col2:
        compare_region = st.text_input("Region", "us-east-1", key="compare_region")
    
    with col3:
        compare_instance = st.text_input("Instance Type", "t3.medium", key="compare_instance")
    
    compare_disabled = st.session_state.get('operation_in_progress', False)
    if st.button("Compare Prices", type="primary", use_container_width=True, disabled=compare_disabled):
        st.session_state.operation_in_progress = True
        
        with st.spinner("Fetching prices from all providers..."):
            if st.session_state.api_mode:
                # API Mode
                try:
                    response = requests.post(
                        f"{st.session_state.api_url}/compare-prices",
                        json={
                            "resource_type": compare_resource,
                            "specifications": {
                                "instance_type": compare_instance,
                                "os": "Linux"
                            },
                            "regions": [compare_region]
                        },
                        timeout=30
                    )
                    
                    if response.status_code == 200:
                        render_enhanced_pricing_dashboard(response)
                    else:
                        st.error(f"API error: {response.status_code}")
                        st.json(response.text)
                        
                except requests.exceptions.Timeout:
                    st.error("Price comparison timed out after 30 seconds")
                except Exception as e:
                    st.error(f"Error: {e}")
                finally:
                    st.session_state.operation_in_progress = False
            
            else:
                # Local Agent Mode - AUTO-INITIALIZE IF NEEDED
                if not st.session_state.agent:
                    with st.spinner("Auto-initializing agent..."):
                        try:
                            env_openai = os.getenv("OPENAI_API_KEY")
                            env_aws_key = os.getenv("AWS_ACCESS_KEY_ID")
                            env_aws_secret = os.getenv("AWS_SECRET_ACCESS_KEY")
                            
                            aws_creds = None
                            if env_aws_key and env_aws_secret:
                                aws_creds = {
                                    'aws_access_key_id': env_aws_key,
                                    'aws_secret_access_key': env_aws_secret
                                }
                            
                            st.session_state.agent = CloudRationalizationAgent(
                                openai_api_key=env_openai if st.session_state.use_llm else None,
                                aws_credentials=aws_creds
                            )
                            st.success("✅ Agent auto-initialized")
                        except Exception as e:
                            st.error(f"Failed to auto-initialize: {e}")
                            st.session_state.operation_in_progress = False
                            st.stop()
                
                if st.session_state.agent:
                    try:
                        # Run comparison with timeout
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                        
                        try:
                            # Run in thread to avoid blocking
                            task = asyncio.ensure_future(
                                asyncio.to_thread(
                                    st.session_state.agent.compare_prices,
                                    specifications={"instance_type": compare_instance, "os": "Linux"},
                                    regions=[compare_region]
                                ),
                                loop=loop
                            )
                            prices = loop.run_until_complete(
                                asyncio.wait_for(task, timeout=30)
                            )
                        except asyncio.TimeoutError:
                            st.error("Price comparison timed out after 30 seconds")
                            prices = None
                        finally:
                            loop.close()
                        
                        if prices:
                            # Create a mock response object
                            class MockResponse:
                                def __init__(self, data):
                                    self.status_code = 200
                                    self._data = data
                                def json(self):
                                    return self._data
                            
                            mock_response = MockResponse(prices)
                            render_enhanced_pricing_dashboard(mock_response)
                        
                    except Exception as e:
                        st.error(f"Agent error: {e}")
                    finally:
                        st.session_state.operation_in_progress = False
                else:
                    st.warning("Agent initialization failed")
                    st.session_state.operation_in_progress = False

# ===== TAB 3: Analysis Results =====
with tab3:
    if st.session_state.analysis_result:
        result = st.session_state.analysis_result
        
        st.subheader("📊 Optimization Results")
        
        # Calculate metrics
        if st.session_state.resources:
            current_cost = sum(r.get('monthly_cost', 0) for r in st.session_state.resources)
        else:
            current_cost = result.get('summary', {}).get('current_cost', 0)
        
        optimized_cost = result.get('summary', {}).get('optimized_cost', current_cost * 0.7)
        savings = current_cost - optimized_cost
        savings_pct = (savings / current_cost * 100) if current_cost > 0 else 0
        
        # Metrics row
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Current Monthly", f"${current_cost:,.2f}")
        with col2:
            st.metric("Optimized", f"${optimized_cost:,.2f}", delta=f"-${savings:,.2f}")
        with col3:
            st.metric("Monthly Savings", f"${savings:,.2f}", delta=f"{savings_pct:.1f}%")
        with col4:
            st.metric("Annual Savings", f"${savings * 12:,.2f}")
        
        # Analysis text
        if 'analysis' in result:
            st.markdown("### 📝 Detailed Analysis")
            st.markdown(result['analysis'])
        
        # Recommendations
        if 'recommendations' in result:
            st.markdown("### ✅ Key Recommendations")
            
            for rec in result['recommendations']:
                risk_class = f"risk-{rec.get('risk', 'medium')}"
                st.markdown(f"""
                <div class='recommendation-card'>
                    <h4>{rec.get('title', 'Recommendation')}</h4>
                    <p>{rec.get('description', rec.get('reason', ''))}</p>
                    <p><span class='savings-positive'>💰 Savings: ${rec.get('savings', 0):,.2f}</span></p>
                    <p>Risk: <span class='{risk_class}'>{rec.get('risk', 'MEDIUM').upper()}</span></p>
                </div>
                """, unsafe_allow_html=True)
        
        # Implementation timeline
        if 'timeline' in result:
            st.markdown("### 📅 Implementation Timeline")
            st.dataframe(pd.DataFrame(result['timeline']), use_container_width=True)
        
    else:
        st.info("Run an optimization analysis first to see results here.")
        demo_disabled = st.session_state.get('operation_in_progress', False)
        if st.button("Run Demo Analysis", disabled=demo_disabled):
            st.session_state.operation_in_progress = True
            
            if st.session_state.resources:
                # Create demo analysis
                total = sum(r['monthly_cost'] for r in st.session_state.resources)
                st.session_state.analysis_result = {
                    "summary": {
                        "current_cost": total,
                        "optimized_cost": total * 0.7,
                        "savings": total * 0.3,
                        "savings_percentage": 30
                    },
                    "analysis": "## Demo Analysis\n\nThis is a sample analysis. For real analysis, please initialize the agent or connect to API.",
                    "recommendations": [
                        {
                            "title": "Right-size over-provisioned instances",
                            "description": "Consider downsizing instances with low utilization",
                            "savings": total * 0.15,
                            "risk": "low"
                        },
                        {
                            "title": "Purchase Reserved Instances",
                            "description": "For steady-state production workloads",
                            "savings": total * 0.25,
                            "risk": "medium"
                        }
                    ]
                }
                st.success("Demo analysis generated!")
            else:
                st.warning("Add some resources first")
            
            st.session_state.operation_in_progress = False

# ===== TAB 4: Reports =====
with tab4:
    st.subheader("📊 Generate Reports")
    
    report_type = st.selectbox(
        "Report Type",
        ["Executive Summary", "Detailed Technical Report", "Cost Savings Analysis", "Migration Plan"]
    )
    
    report_format = st.radio("Format", ["PDF", "Excel", "JSON"], horizontal=True)
    
    report_disabled = st.session_state.get('operation_in_progress', False)
    if st.button("Generate Report", use_container_width=True, disabled=report_disabled):
        st.session_state.operation_in_progress = True
        
        with st.spinner("Generating report..."):
            st.success("Report generated successfully!")
            
            # Sample report preview
            if report_type == "Executive Summary":
                st.markdown("""
                # Executive Summary: Cloud Optimization Report
                
                **Date:** {}
                **Prepared for:** Cloud Rationalization Agent User
                
                ## Key Findings
                - Current monthly spend: ${:,.2f}
                - Optimization potential: ${:,.2f}/month ({:.1f}%)
                - Payback period: 8 months
                
                ## Top Recommendations
                1. Implement Reserved Instances for production workloads
                2. Right-size development environments
                3. Use Spot Instances for CI/CD pipelines
                
                ## Next Steps
                - Begin with quick wins (week 1-2)
                - Schedule implementation windows
                - Set up cost monitoring
                """.format(
                    datetime.now().strftime("%B %d, %Y"),
                    sum(r['monthly_cost'] for r in st.session_state.resources) if st.session_state.resources else 0,
                    sum(r['monthly_cost'] for r in st.session_state.resources) * 0.3 if st.session_state.resources else 0,
                    30
                ))
            
            # Download buttons
            col1, col2 = st.columns(2)
            with col1:
                st.download_button(
                    "📥 Download Report",
                    data="Sample report content",
                    file_name=f"cloud_report_{datetime.now().strftime('%Y%m%d')}.pdf",
                    mime="application/pdf"
                )
            with col2:
                st.download_button(
                    "📊 Download Data",
                    data=json.dumps(st.session_state.analysis_result, indent=2) if st.session_state.analysis_result else "{}",
                    file_name=f"analysis_data_{datetime.now().strftime('%Y%m%d')}.json",
                    mime="application/json"
                )
        
        st.session_state.operation_in_progress = False

# ===== FOOTER =====
st.markdown("---")

# Show current mode status
col1, col2, col3 = st.columns(3)
with col1:
    if st.session_state.api_mode:
        st.info(f"🌐 Connected to API: {st.session_state.api_url}")
    else:
        if st.session_state.agent:
            mode = "LLM Mode" if st.session_state.agent.llm else "Tool-Only Mode"
            st.info(f"🧠 Local Agent: {mode}")
        else:
            st.info("⚙️ Agent not initialized (will auto-init on analysis)")

with col2:
    if st.session_state.creds and not st.session_state.api_mode:
        live = []
        if st.session_state.creds.get('aws'):
            live.append("AWS")
        if st.session_state.creds.get('azure'):
            live.append("Azure")
        if st.session_state.creds.get('gcp'):
            live.append("GCP")
        
        if live:
            st.success(f"💰 Live pricing: {', '.join(live)}")
        else:
            st.warning("💰 Demo pricing (no cloud credentials)")
    elif st.session_state.api_mode:
        st.info("🌐 Using API server credentials")

with col3:
    if st.session_state.get('operation_in_progress', False):
        st.warning("⏳ Operation in progress...")
    else:
        st.markdown("Made with ❤️ using LangChain")

# Debug expander
with st.expander("🔍 Debug Info"):
    st.json({
        "api_mode": st.session_state.api_mode,
        "api_url": st.session_state.api_url,
        "agent_initialized": st.session_state.agent is not None,
        "creds": st.session_state.creds,
        "resources_count": len(st.session_state.resources),
        "use_llm": st.session_state.agent.llm if st.session_state.agent else False,
        "operation_in_progress": st.session_state.operation_in_progress
    })
