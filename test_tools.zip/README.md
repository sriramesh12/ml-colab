# ☁️ Cloud Rationalization Agent

An AI-powered agent for cloud infrastructure optimization, cost analysis, and multi-cloud price comparison.

## 🚀 Features

- **Multi-Cloud Price Comparison**: Compare real-time prices across AWS, Azure, and GCP
- **Intelligent Workload Analysis**: Identify right-sizing opportunities and optimization candidates
- **Cost Optimization Recommendations**: Get actionable recommendations for Reserved Instances, Spot instances, and Savings Plans
- **Migration Planning**: Generate migration strategies and implementation roadmaps
- **Interactive Web Interface**: User-friendly Streamlit dashboard
- **REST API**: FastAPI backend for programmatic access
- **CLI Tool**: Command-line interface for automation
- **Async Processing**: Background job support for long-running analyses

## 📋 Prerequisites

- Python 3.11+
- OpenAI API key
- Cloud provider credentials (optional, for real-time pricing)

## 🛠️ Installation

### 1. Clone the repository
```bash
git clone https://github.com/sriramesh12/cloud-agent.git
cd cloud-agent

2
Create virtual env
python -m venv venv
source venv312/bin/activate  # On Windows: venv312\Scripts\activate ( Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass)

3
Install dependencies
pip install -r requirements.txt

4
Setup env variable
cp .env.example .env
# Edit .env with your API keys

5
Usage in bash
streamlit run web/streamlit_app.py

6
Api server
uvicorn api.main:app --reload

7
Cli tool
# Initialize agent
python cli/cloud_agent_cli.py init

# Analyze infrastructure
python cli/cloud_agent_cli.py analyze examples/sample_config.yaml

# Compare prices
python cli/cloud_agent_cli.py compare --resource ec2 --region us-east-1 --type t3.medium

# Interactive mode
python cli/cloud_agent_cli.py interactive

8
Python library
import asyncio
from src.agent import CloudRationalizationAgent

agent = CloudRationalizationAgent(openai_api_key="your-key")
result = await agent.analyze(your_request)

9
Docker deployment
# Build and run with Docker Compose
docker-compose up -d

# Access services:
# - API: http://localhost:8000
# - Streamlit UI: http://localhost:8501
# - API Docs: http://localhost:8000/docs

10
Project structure
cloud-rationalization-agent/
├── src/                    # Core agent code
│   ├── agent.py            # Main agent class
│   ├── tools/              # Agent tools
│   │   ├── aws_pricing.py
│   │   ├── azure_pricing.py
│   │   └── analyzers.py
│   └── models/             # Data models
├── api/                     # FastAPI backend
├── web/                     # Streamlit frontend
├── cli/                     # CLI tool
├── config/                  # Configuration
├── tests/                   # Unit tests
├── examples/                # Example files
├── data/                    # Data directory
├── logs/                    # Log files
├── docker-compose.yml       # Docker compose
├── Dockerfile               # Docker image
└── requirements.txt         # Dependencies

11

# Run tests
pytest tests/

# Run with coverage
pytest --cov=src tests/

Configuration

Supported Cloud Providers

· AWS: EC2, RDS, S3, Lambda, EKS
· Azure: Virtual Machines, SQL Database, Storage, Functions, AKS
· GCP: Compute Engine, Cloud SQL, Cloud Storage, Cloud Functions, GKE

Environment Variables

Variable Description Required
OPENAI_API_KEY OpenAI API key Yes
AWS_ACCESS_KEY_ID AWS access key No*
AWS_SECRET_ACCESS_KEY AWS secret key No*
AZURE_SUBSCRIPTION_KEY Azure subscription key No*
GCP_PROJECT_ID GCP project ID No*

*Required only for real-time pricing from specific providers

📊 API Documentation

Once running, visit http://localhost:8000/docs for interactive API documentation.

Key Endpoints

· POST /analyze - Analyze infrastructure
· POST /analyze/async - Async analysis
· POST /compare-prices - Compare prices
· GET /jobs/{job_id} - Get async job status
· GET /health - Health check

🧪 Testing

```bash
# Run tests
pytest tests/

# Run with coverage
pytest --cov=src tests/
```

🤝 Contributing

Contributions are welcome! Please read our Contributing Guidelines.

📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

🙏 Acknowledgments

· LangChain for the agent framework
· OpenAI for GPT models
· Cloud providers for pricing APIs

📧 Contact

For questions or support, please open an issue on GitHub.

```

### **17. Setup File - `setup.py`**
```python
"""
Setup script for Cloud Optix
"""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as f:
    requirements = f.read().splitlines()

setup(
    name="cloud-rationalization-agent",
    version="1.0.0",
    author="Ramesh Babu S",
    author_email="sri_ramesh@hotmail.com",
    description="AI-powered cloud infrastructure optimization and pricing analysis",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/sriramesh12/cloud-agent",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.11",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "cloud-agent=cli.cloud_agent_cli:cli",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)
```

How to Create the Project

You can create all these files manually, or use this script to generate them:

```python
# create_project.py
import os
import shutil

# Create directory structure
directories = [
    "src",
    "src/tools",
    "src/models",
    "src/utils",
    "api",
    "web",
    "cli",
    "config",
    "tests",
    "examples",
    "data",
    "logs"
]

for dir_path in directories:
    os.makedirs(dir_path, exist_ok=True)
    # Create __init__.py files
    init_path = os.path.join(dir_path, "__init__.py")
    if not os.path.exists(init_path):
        with open(init_path, "w") as f:
            f.write("# Auto-generated __init__.py\n")

print("✅ Directory structure created")

# Now create each file with the content provided above
# You'll need to copy-paste each file's content
```

Quick Start

1. Create the project structure
2. Copy all the file contents provided above
3. Install dependencies: pip install -r requirements.txt
4. Set up environment: Copy .env.example to .env and add your API keys
5. Run the web app: streamlit run web/streamlit_app.py
6. Or run the API: uvicorn api.main:app --reload

The complete project is now ready to use! You can extend it with:

· More cloud providers (IBM Cloud, Oracle Cloud, Alibaba)
· Additional optimization algorithms
· Integration with Terraform/CloudFormation
· Cost anomaly detection
· Budget alerts and notifications
· Historical trend analysis
· Custom reporting templates

This gives you a production-ready cloud
Rationalization agent that others can easily use