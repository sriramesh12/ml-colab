import requests
import socket
import ssl
import urllib3
urllib3.disable_warnings()


def debug_azure_network():
    print("="*60)
    print("AZURE API NETWORK DEBUG")
    print("="*60)
    
    # Test 1: Basic internet connectivity
    print("\n📌 TEST 1: Internet connectivity")
    try:
        response = requests.get("https://www.google.com", timeout=5)
        print(f"✅ Google reachable: {response.status_code}")
    except Exception as e:
        print(f"❌ Cannot reach internet: {e}")
    
    # Test 2: DNS resolution
    print("\n📌 TEST 2: DNS resolution")
    try:
        ip = socket.gethostbyname("prices.azure.com")
        print(f"✅ prices.azure.com resolves to: {ip}")
    except Exception as e:
        print(f"❌ DNS resolution failed: {e}")
    
    # Test 3: SSL certificate check
    print("\n📌 TEST 3: SSL certificate")
    try:
        context = ssl.create_default_context()
        with socket.create_connection(("prices.azure.com", 443), timeout=5) as sock:
            with context.wrap_socket(sock, server_hostname="prices.azure.com") as ssock:
                cert = ssock.getpeercert()
                print(f"✅ SSL certificate valid")
                print(f"   Issuer: {cert.get('issuer')}")
    except Exception as e:
        print(f"❌ SSL connection failed: {e}")
    
    # Test 4: Direct API call with different parameters
    print("\n📌 TEST 4: API call with minimal parameters")
    urls = [
        "https://prices.azure.com/api/retail/prices?api-version=2023-01-01",
        "https://prices.azure.com/api/retail/prices?api-version=2021-10-01-preview",
        "https://prices.azure.com/api/retail/prices?$top=1",
    ]
    
    for url in urls:
        try:
            print(f"\nTrying: {url}")
            response = requests.get(url, timeout=10, verify=False)  # Disable SSL verify for testing
            print(f"Status: {response.status_code}")
            if response.status_code == 200:
                data = response.json()
                print(f"✅ Success! Found {len(data.get('Items', []))} items")
                break
            else:
                print(f"Response: {response.text[:200]}")
        except Exception as e:
            print(f"Error: {e}")
    
    # Test 5: Check proxy settings
    print("\n📌 TEST 5: Proxy detection")
    proxies = {
        "http": os.environ.get("HTTP_PROXY", ""),
        "https": os.environ.get("HTTPS_PROXY", "")
    }
    if proxies["http"] or proxies["https"]:
        print(f"⚠️ Proxy detected: {proxies}")
        print("   Try disabling proxy or adding proxy exceptions")
    else:
        print("✅ No proxy configured")
    
    # Test 6: Try with different headers
    print("\n📌 TEST 6: Different headers")
    headers_list = [
        {"User-Agent": "Mozilla/5.0"},
        {"Accept": "application/json"},
        {}
    ]
    
    for i, headers in enumerate(headers_list):
        try:
            url = "https://prices.azure.com/api/retail/prices?api-version=2023-01-01&$top=1"
            print(f"\nHeaders {i+1}: {headers}")
            response = requests.get(url, headers=headers, timeout=10, verify=False)
            print(f"Status: {response.status_code}")
            if response.status_code == 200:
                print("✅ Success!")
                break
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    import os
    debug_azure_network()

#🔧 Alternative: Use Azure Pricing REST API Directly

#If the retail API is blocked, try the consumption API:

#python
def test_alternative_azure_api():
    """Test Azure Consumption API (requires subscription)"""
    print("\n📌 TEST 7: Azure Consumption API")
    
    # This requires a subscription ID and bearer token
    subscription_id = "your-subscription-id"  # You'll need this
    
    url = f"https://management.azure.com/subscriptions/{subscription_id}/providers/Microsoft.Consumption/pricesheet?api-version=2023-03-01"
    
    # You'd need a bearer token here
    headers = {
        "Authorization": "Bearer YOUR_TOKEN"
    }
    
    print("Note: Consumption API requires Azure subscription and token")

#💡 If All Else Fails: Hardcoded Pricing

#For now, you can use this simplified version with hardcoded prices:


"""
Azure Pricing Tool - Hardcoded version while API is being debugged
"""
from langchain.tools import BaseTool
from typing import Dict, Optional, Type
from pydantic import BaseModel, Field, ConfigDict
import json
import logging

logger = logging.getLogger(__name__)

class AzurePricingTool(BaseTool):
    name: str = "azure_pricing_tool"
    description: str = "Get Azure pricing"
    args_schema: Type[BaseModel] = AzurePricingInput
    
    model_config = ConfigDict(arbitrary_types_allowed=True)
    
    # Hardcoded pricing data (as of March 2024)
    PRICES = {
        "eastus": {
            "B2s": 0.0416,
            "B4ms": 0.166,
            "D2s v3": 0.096,
            "D4s v3": 0.192,
            "F2s v2": 0.084,
        },
        "westeurope": {
            "B2s": 0.0480,
            "D2s v3": 0.110,
        },
        "default": {
            "B2s": 0.0416,
            "B4ms": 0.166,
            "D2s v3": 0.096,
            "D4s v3": 0.192,
            "D8s v3": 0.384,
            "F2s v2": 0.084,
        }
    }
    
    def _run(self, resource_type: str, region: str, specifications: Dict, quantity: int = 1) -> str:
        instance = specifications.get('instance_type', 'D2s v3')
        
        # Get price from region-specific or default
        region_prices = self.PRICES.get(region, self.PRICES["default"])
        hourly = region_prices.get(instance, region_prices.get("D2s v3", 0.096))
        monthly = hourly * 730 * quantity
        
        return json.dumps({
            "provider": "Azure",
            "region": region,
            "instance_type": instance,
            "hourly_rate": hourly,
            "monthly_rate": monthly,
            "currency": "USD",
            "data_source": "hardcoded",
            "note": "Using hardcoded prices while API is debugged"
        }, indent=2)
