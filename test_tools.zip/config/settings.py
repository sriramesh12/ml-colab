"""
Configuration settings for Cloud Rationalization Agent
"""
from pydantic_settings import BaseSettings
from typing import Optional, Dict
from functools import lru_cache
import os
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseSettings):
    """Application settings"""
    
    # OpenAI
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4-turbo-preview")
    OPENAI_TEMPERATURE: float = float(os.getenv("OPENAI_TEMPERATURE", "0.1"))
    
    # AWS
    AWS_ACCESS_KEY_ID: Optional[str] = os.getenv("AWS_ACCESS_KEY_ID")
    AWS_SECRET_ACCESS_KEY: Optional[str] = os.getenv("AWS_SECRET_ACCESS_KEY")
    AWS_DEFAULT_REGION: str = os.getenv("AWS_DEFAULT_REGION", "us-east-1")
    
    # Azure
    AZURE_SUBSCRIPTION_KEY: Optional[str] = os.getenv("AZURE_SUBSCRIPTION_KEY")
    AZURE_REGION: str = os.getenv("AZURE_REGION", "eastus")
    
    # GCP
    GCP_PROJECT_ID: Optional[str] = os.getenv("GCP_PROJECT_ID")
    GCP_CREDENTIALS_PATH: Optional[str] = os.getenv("GCP_CREDENTIALS_PATH")
    
    # API
    API_HOST: str = os.getenv("API_HOST", "0.0.0.0")
    API_PORT: int = int(os.getenv("API_PORT", "8000"))
    API_DEBUG: bool = os.getenv("API_DEBUG", "False").lower() == "true"
    
    # Redis (for async jobs)
    REDIS_URL: Optional[str] = os.getenv("REDIS_URL", "redis://localhost:6379")
    
    # App settings
    APP_NAME: str = "Cloud Rationalization Agent"
    APP_VERSION: str = "1.0.0"
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")
    
    @property
    def AWS_CREDENTIALS(self) -> Optional[Dict]:
        """Get AWS credentials dictionary"""
        if self.AWS_ACCESS_KEY_ID and self.AWS_SECRET_ACCESS_KEY:
            return {
                "aws_access_key_id": self.AWS_ACCESS_KEY_ID,
                "aws_secret_access_key": self.AWS_SECRET_ACCESS_KEY,
                "region_name": self.AWS_DEFAULT_REGION
            }
        return None
    
    @property
    def AZURE_CREDENTIALS(self) -> Optional[Dict]:
        """Get Azure credentials dictionary"""
        if self.AZURE_SUBSCRIPTION_KEY:
            return {
                "subscription_key": self.AZURE_SUBSCRIPTION_KEY
            }
        return None
    
    @property
    def GCP_CREDENTIALS(self) -> Optional[Dict]:
        """Get GCP credentials dictionary"""
        if self.GCP_PROJECT_ID:
            return {
                "project_id": self.GCP_PROJECT_ID,
                "credentials_path": self.GCP_CREDENTIALS_PATH
            }
        return None
    
    class Config:
        env_file = ".env"
        case_sensitive = True

@lru_cache()
def get_settings() -> Settings:
    """Get cached settings"""
    return Settings()