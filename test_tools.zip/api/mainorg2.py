"""
FastAPI application for Cloud Rationalization Agent
"""
from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from typing import List, Optional
import uuid
from datetime import datetime
import logging
from contextlib import asynccontextmanager

from src.agent import CloudRationalizationAgent
from src.models.schemas import (
    RationalizationRequest, 
    RationalizationResponse,
    CloudResource,
    BusinessConstraints
)
from config.settings import Settings

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global variables
agent = None
jobs = {}

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan events handler"""
    global agent
    # Startup
    logger.info("Starting Cloud Rationalization Agent API")
    settings = Settings()
    agent = CloudRationalizationAgent(
        openai_api_key=settings.OPENAI_API_KEY,
        aws_credentials=settings.AWS_CREDENTIALS,
        azure_credentials=settings.AZURE_CREDENTIALS,
        gcp_credentials=settings.GCP_CREDENTIALS
    )
    yield
    # Shutdown
    logger.info("Shutting down Cloud Rationalization Agent API")

# Create FastAPI app
app = FastAPI(
    title="Cloud Rationalization Agent API",
    description="AI-powered cloud infrastructure optimization and pricing analysis",
    version="1.0.0",
    lifespan=lifespan
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Cloud Rationalization Agent API",
        "version": "1.0.0",
        "endpoints": [
            "/health",
            "/analyze",
            "/compare-prices",
            "/jobs/{job_id}",
            "/providers",
            "/regions"
        ]
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "agent_initialized": agent is not None
    }

@app.post("/analyze", response_model=RationalizationResponse)
async def analyze_infrastructure(request: RationalizationRequest):
    """
    Analyze cloud infrastructure and provide optimization recommendations
    """
    try:
        if not agent:
            raise HTTPException(status_code=503, detail="Agent not initialized")
        
        # Process request
        result = await agent.analyze(request)
        
        return result
        
    except Exception as e:
        logger.error(f"Analysis error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/analyze/async")
async def analyze_infrastructure_async(
    request: RationalizationRequest,
    background_tasks: BackgroundTasks
):
    """
    Asynchronously analyze cloud infrastructure
    """
    try:
        if not agent:
            raise HTTPException(status_code=503, detail="Agent not initialized")
        
        job_id = str(uuid.uuid4())
        jobs[job_id] = {
            "job_id": job_id,
            "status": "pending",
            "created_at": datetime.now(),
            "result": None
        }
        
        # Process in background
        background_tasks.add_task(process_async_analysis, job_id, request)
        
        return {
            "job_id": job_id,
            "status": "pending",
            "message": "Analysis started",
            "check_url": f"/jobs/{job_id}"
        }
        
    except Exception as e:
        logger.error(f"Async analysis error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/compare-prices")
async def compare_prices(
    resource_type: str,
    specifications: dict,
    regions: Optional[List[str]] = None
):
    """
    Compare prices across cloud providers
    """
    try:
        if not agent:
            raise HTTPException(status_code=503, detail="Agent not initialized")
        
        result = await agent.compare_prices(
            resource_type=resource_type,
            specifications=specifications,
            regions=regions
        )
        
        return result
        
    except Exception as e:
        logger.error(f"Price comparison error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/jobs/{job_id}")
async def get_job_status(job_id: str):
    """
    Get status and result of an async analysis job
    """
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    
    return jobs[job_id]

@app.get("/providers")
async def list_providers():
    """
    List supported cloud providers
    """
    return {
        "providers": [
            {
                "name": "AWS",
                "services": ["EC2", "RDS", "S3", "Lambda", "EKS"],
                "regions_supported": 30
            },
            {
                "name": "Azure",
                "services": ["Virtual Machines", "SQL Database", "Storage", "Functions", "AKS"],
                "regions_supported": 60
            },
            {
                "name": "GCP",
                "services": ["Compute Engine", "Cloud SQL", "Cloud Storage", "Cloud Functions", "GKE"],
                "regions_supported": 35
            }
        ]
    }

@app.get("/regions/{provider}")
async def list_regions(provider: str):
    """
    List available regions for a specific provider
    """
    # This would typically come from a database or API
    regions = {
        "aws": ["us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1"],
        "azure": ["eastus", "westeurope", "southeastasia", "japaneast"],
        "gcp": ["us-central1", "europe-west1", "asia-east1", "australia-southeast1"]
    }
    
    return {
        "provider": provider,
        "regions": regions.get(provider.lower(), [])
    }

async def process_async_analysis(job_id: str, request: RationalizationRequest):
    """
    Background task for async analysis
    """
    try:
        jobs[job_id]["status"] = "processing"
        
        # Run analysis
        result = await agent.analyze(request)
        
        # Update job with results
        jobs[job_id]["status"] = "completed"
        jobs[job_id]["result"] = result.dict()
        jobs[job_id]["completed_at"] = datetime.now()
        
    except Exception as e:
        jobs[job_id]["status"] = "failed"
        jobs[job_id]["error"] = str(e)
        jobs[job_id]["completed_at"] = datetime.now()
        logger.error(f"Background analysis error for job {job_id}: {e}")

@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """Global exception handler"""
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "detail": str(exc),
            "path": request.url.path
        }
    )