"""
FastAPI application for Cloud Rationalization Agent
With SSL fixes and helper integrations
"""
from fastapi import FastAPI, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from typing import Dict, Any, List, Optional
import logging
from datetime import datetime

# Import helpers with SSL fix
from src.utils.helpers import apply_ssl_fix, safe_serialize, safe_json_dumps, safe_call_tool

# Apply SSL fix at startup
apply_ssl_fix()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Cloud Rationalization Agent API",
    description="AI-powered cloud infrastructure optimization",
    version="2.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global agent instance
agent = None

@app.on_event("startup")
async def startup_event():
    """Initialize agent on startup"""
    global agent
    try:
        from src.agent import CloudRationalizationAgent
        import os
        
        # Initialize agent with optional OpenAI key
        agent = CloudRationalizationAgent(
            openai_api_key=os.getenv("OPENAI_API_KEY"),
            aws_credentials={},
            azure_credentials={},
            gcp_credentials={}
        )
        logger.info(f"✅ Agent initialized in mode: {'full' if agent.llm else 'tool-only'}")
    except Exception as e:
        logger.error(f"Failed to initialize agent: {e}")
        agent = None

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Cloud Rationalization Agent API",
        "version": "2.0.0",
        "status": "running",
        "agent_mode": "full" if agent and agent.llm else "tool-only" if agent else "unavailable",
        "endpoints": [
            "/health",
            "/compare-prices",
            "/analyze",
            "/providers",
            "/docs"
        ]
    }

@app.get("/health")
async def health():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "agent_initialized": agent is not None,
        "agent_mode": "full" if agent and agent.llm else "tool-only" if agent else "none",
        "timestamp": datetime.now().isoformat()
    }

@app.post("/compare-prices")
async def compare_prices(request: Dict[str, Any] = Body(...)):
    """
    Compare prices across cloud providers
    Uses safe helpers for robust parameter handling
    """
    try:
        if not agent:
            raise HTTPException(status_code=503, detail="Agent not initialized")
        
        # Extract parameters
        resource_type = request.get("resource_type", "ec2")
        specifications = request.get("specifications", {"instance_type": "t3.medium"})
        regions = request.get("regions", ["us-east-1"])
        
        logger.info(f"Comparing prices for {specifications} in {regions}")
        
        # Call agent's compare_prices method (tool-only)
        results = agent.compare_prices(
            resource_type=resource_type,
            specifications=specifications,
            regions=regions
        )
        
        # Use safe_serialize to ensure JSON compatibility
        return safe_serialize(results)
        
    except Exception as e:
        logger.error(f"Error in compare_prices: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/analyze")
async def analyze(request: Dict[str, Any] = Body(...)):
    """
    Analyze infrastructure
    Returns tool-only analysis if no LLM, full analysis if LLM available
    """
    try:
        if not agent:
            raise HTTPException(status_code=503, detail="Agent not initialized")
        
        # Import here to avoid circular imports
        from src.models.schemas import RationalizationRequest, CloudResource, BusinessConstraints
        
        # Parse request (simplified for demo)
        resources_data = request.get("current_infrastructure", [])
        resources = []
        
        for r in resources_data:
            resources.append(CloudResource(
                name=r.get("name", "unknown"),
                resource_type=r.get("resource_type", "compute"),
                provider=r.get("provider", "aws"),
                region=r.get("region", "us-east-1"),
                specifications=r.get("specifications", {}),
                quantity=r.get("quantity", 1),
                usage_pattern=r.get("usage_pattern", "steady"),
                monthly_cost=float(r.get("monthly_cost", 0)),
                fault_tolerant=r.get("fault_tolerant", False)
            ))
        
        # Create request
        from src.agent import RationalizationRequest
        req = RationalizationRequest(
            current_infrastructure=resources,
            business_constraints=BusinessConstraints(),
            optimization_goals=["cost_reduction"]
        )
        
        # Run analysis (will auto-select mode)
        import asyncio
        result = await agent.analyze_with_llm(req)
        
        return safe_serialize(result)
        
    except Exception as e:
        logger.error(f"Error in analyze: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/compare-simple")
async def compare_simple(
    instance_type: str = "t3.medium",
    region: str = "us-east-1"
):
    """
    Simple GET endpoint for quick price comparison
    """
    if not agent:
        return {
            "aws": 30.37,
            "azure": 35.04,
            "gcp": 27.38,
            "note": "Demo data (agent not initialized)"
        }
    
    results = agent.compare_prices(
        specifications={"instance_type": instance_type},
        regions=[region]
    )
    
    # Simplify for GET response
    simplified = {}
    for provider, data in results.items():
        if provider != '_metadata' and isinstance(data, dict):
            simplified[provider] = data.get('monthly_rate', 0)
    
    return simplified

@app.get("/providers")
async def list_providers():
    """List supported cloud providers"""
    return {
        "providers": [
            {
                "name": "AWS",
                "services": ["EC2", "RDS", "S3", "Lambda"],
                "regions": 30
            },
            {
                "name": "Azure",
                "services": ["Virtual Machines", "SQL", "Storage"],
                "regions": 60
            },
            {
                "name": "GCP",
                "services": ["Compute Engine", "Cloud SQL", "Cloud Storage"],
                "regions": 35
            }
        ]
    }

@app.get("/debug/ssl")
async def debug_ssl():
    """Debug SSL configuration"""
    import certifi
    import ssl
    
    return {
        "certifi_path": certifi.where(),
        "ssl_default_paths": str(ssl.get_default_verify_paths()),
        "env_ssl_cert": os.getenv("SSL_CERT_FILE"),
        "env_requests_ca": os.getenv("REQUESTS_CA_BUNDLE")
    }