"""
FastAPI application for Cloud Rationalization Agent
Complete version with SSL fixes and proper agent initialization
"""
from fastapi import FastAPI, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from typing import Dict, Any, List, Optional
import logging
from datetime import datetime
import os
import sys
from pathlib import Path

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent))

# Import helpers
try:
    from src.utils.helpers import apply_ssl_fix, safe_serialize
    apply_ssl_fix()
except ImportError:
    # Fallback if helpers not available
    def safe_serialize(obj):
        if hasattr(obj, 'dict'):
            return obj.dict()
        return obj

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Cloud Rationalization Agent API",
    description="AI-powered cloud infrastructure optimization",
    version="2.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global agent instance
agent = None

@app.on_event("startup")
async def startup_event():
    """Initialize agent on startup - FIXED VERSION"""
    global agent
    try:
        from src.agent import CloudRationalizationAgent
        
        # Get API key from environment
        openai_api_key = os.getenv("OPENAI_API_KEY")
        
        # Initialize agent with all parameters (fixes RecursiveGuard error)
        agent = CloudRationalizationAgent(
            openai_api_key=openai_api_key,  # Can be None for tool-only mode
            aws_credentials={},  # Always pass empty dict, not None
            azure_credentials={},
            gcp_credentials={}
        )
        
        mode_text = "FULL AGENT" if agent.llm else "TOOL-ONLY"
        logger.info(f"✅ Agent initialized successfully in {mode_text} mode")
        
    except ImportError as e:
        logger.error(f"Failed to import agent: {e}")
        agent = None
    except Exception as e:
        logger.error(f"Failed to initialize agent: {e}")
        agent = None

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Cloud Rationalization Agent API",
        "version": "2.0.0",
        "status": "running",
        "agent_mode": "full" if agent and agent.llm else "tool-only" if agent else "unavailable",
        "endpoints": [
            "/health",
            "/compare-prices",
            "/analyze",
            "/providers",
            "/docs"
        ]
    }

@app.get("/health")
async def health():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "agent_initialized": agent is not None,
        "agent_mode": "full" if agent and agent.llm else "tool-only" if agent else "none",
        "timestamp": datetime.now().isoformat()
    }

@app.post("/compare-prices")
async def compare_prices(request: Dict[str, Any] = Body(...)):
    """
    Compare prices across cloud providers
    """
    try:
        if not agent:
            # Return demo data if agent not initialized
            return {
                "aws": {
                    "provider": "AWS",
                    "hourly_rate": 0.0416,
                    "monthly_rate": 30.37,
                    "currency": "USD",
                    "pricing_model": "On-Demand (Demo)"
                },
                "azure": {
                    "provider": "Azure",
                    "hourly_rate": 0.0480,
                    "monthly_rate": 35.04,
                    "currency": "USD",
                    "pricing_model": "Pay-As-You-Go (Demo)"
                },
                "gcp": {
                    "provider": "GCP",
                    "hourly_rate": 0.0375,
                    "monthly_rate": 27.38,
                    "currency": "USD",
                    "pricing_model": "On-Demand (Demo)"
                }
            }
        
        # Extract parameters
        resource_type = request.get("resource_type", "ec2")
        specifications = request.get("specifications", {"instance_type": "t3.medium"})
        regions = request.get("regions", ["us-east-1"])
        
        logger.info(f"Comparing prices for {specifications.get('instance_type')} in {regions}")
        
        # Call agent's compare_prices method (tool-only)
        results = agent.compare_prices(
            resource_type=resource_type,
            specifications=specifications,
            regions=regions
        )
        
        # Use safe_serialize to ensure JSON compatibility
        return safe_serialize(results)
        
    except Exception as e:
        logger.error(f"Error in compare_prices: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/analyze")
async def analyze(request: Dict[str, Any] = Body(...)):
    """
    Analyze infrastructure
    Returns tool-only analysis if no LLM, full analysis if LLM available
    """
    try:
        if not agent:
            # Return demo analysis if agent not initialized
            resources = request.get("current_infrastructure", [])
            total_cost = sum(r.get("monthly_cost", 0) for r in resources)
            
            return {
                "summary": {
                    "current_cost": total_cost,
                    "optimized_cost": total_cost * 0.7,
                    "savings": total_cost * 0.3,
                    "savings_percentage": 30
                },
                "analysis": f"## Demo Analysis\n\nAnalyzed {len(resources)} resources.\n\nFor real analysis, please ensure agent is properly configured.",
                "recommendations": [
                    {
                        "title": "Right-size instances",
                        "description": "Consider downsizing underutilized instances",
                        "savings": total_cost * 0.15,
                        "risk": "low"
                    },
                    {
                        "title": "Purchase Reserved Instances",
                        "description": "For steady-state production workloads",
                        "savings": total_cost * 0.25,
                        "risk": "medium"
                    }
                ],
                "mode": "demo"
            }
        
        # Import models here to avoid circular imports
        from src.models.schemas import RationalizationRequest, CloudResource, BusinessConstraints
        
        # Parse request
        resources_data = request.get("current_infrastructure", [])
        resources = []
        
        for r in resources_data:
            try:
                resource = CloudResource(
                    name=r.get("name", "unknown"),
                    resource_type=r.get("resource_type", "compute"),
                    provider=r.get("provider", "aws"),
                    region=r.get("region", "us-east-1"),
                    specifications=r.get("specifications", {}),
                    quantity=int(r.get("quantity", 1)),
                    usage_pattern=r.get("usage_pattern", "steady"),
                    monthly_cost=float(r.get("monthly_cost", 0)),
                    fault_tolerant=r.get("fault_tolerant", False)
                )
                resources.append(resource)
            except Exception as e:
                logger.warning(f"Error parsing resource: {e}")
        
        # Create constraints
        constraints_data = request.get("business_constraints", {})
        constraints = BusinessConstraints(
            max_budget=constraints_data.get("max_budget"),
            min_availability=constraints_data.get("min_availability", "99.9%"),
            compliance_requirements=constraints_data.get("compliance_requirements", []),
            risk_tolerance=constraints_data.get("risk_tolerance", "medium")
        )
        
        # Create goals
        goals_data = request.get("optimization_goals", ["cost_reduction"])
        from src.models.schemas import OptimizationGoal
        goals = []
        for g in goals_data:
            try:
                goals.append(OptimizationGoal(g))
            except ValueError:
                goals.append(OptimizationGoal.COST_REDUCTION)
        
        # Create request
        req = RationalizationRequest(
            current_infrastructure=resources,
            business_constraints=constraints,
            optimization_goals=goals,
            time_horizon=request.get("time_horizon", "1 year")
        )
        
        # Run analysis (will auto-select mode based on agent.llm availability)
        import asyncio
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(agent.analyze_with_llm(req))
        loop.close()
        
        return safe_serialize(result)
        
    except Exception as e:
        logger.error(f"Error in analyze: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/compare-simple")
async def compare_simple(
    instance_type: str = "t3.medium",
    region: str = "us-east-1"
):
    """
    Simple GET endpoint for quick price comparison
    """
    if not agent:
        return {
            "aws": 30.37,
            "azure": 35.04,
            "gcp": 27.38,
            "note": "Demo data (agent not initialized)"
        }
    
    results = agent.compare_prices(
        specifications={"instance_type": instance_type, "os": "Linux"},
        regions=[region]
    )
    
    # Simplify for GET response
    simplified = {}
    for provider, data in results.items():
        if provider != '_metadata' and isinstance(data, dict):
            simplified[provider] = data.get('monthly_rate', data.get('monthly', 0))
    
    return simplified

@app.get("/providers")
async def list_providers():
    """List supported cloud providers"""
    return {
        "providers": [
            {
                "name": "AWS",
                "services": ["EC2", "RDS", "S3", "Lambda", "EKS"],
                "regions": 30,
                "website": "https://aws.amazon.com"
            },
            {
                "name": "Azure",
                "services": ["Virtual Machines", "SQL Database", "Storage", "Functions", "AKS"],
                "regions": 60,
                "website": "https://azure.microsoft.com"
            },
            {
                "name": "GCP",
                "services": ["Compute Engine", "Cloud SQL", "Cloud Storage", "Cloud Functions", "GKE"],
                "regions": 35,
                "website": "https://cloud.google.com"
            }
        ]
    }

@app.get("/regions/{provider}")
async def list_regions(provider: str):
    """List available regions for a specific provider"""
    regions = {
        "aws": [
            {"code": "us-east-1", "name": "US East (N. Virginia)"},
            {"code": "us-west-2", "name": "US West (Oregon)"},
            {"code": "eu-west-1", "name": "EU (Ireland)"},
            {"code": "ap-southeast-1", "name": "Asia Pacific (Singapore)"}
        ],
        "azure": [
            {"code": "eastus", "name": "US East"},
            {"code": "westeurope", "name": "West Europe"},
            {"code": "southeastasia", "name": "Southeast Asia"},
            {"code": "japaneast", "name": "Japan East"}
        ],
        "gcp": [
            {"code": "us-central1", "name": "Iowa"},
            {"code": "europe-west1", "name": "Belgium"},
            {"code": "asia-east1", "name": "Taiwan"},
            {"code": "australia-southeast1", "name": "Sydney"}
        ]
    }
    
    return {
        "provider": provider,
        "regions": regions.get(provider.lower(), [])
    }

@app.get("/debug/ssl")
async def debug_ssl():
    """Debug SSL configuration"""
    try:
        import certifi
        return {
            "certifi_path": certifi.where(),
            "certifi_exists": os.path.exists(certifi.where()),
            "env_ssl_cert": os.getenv("SSL_CERT_FILE"),
            "env_requests_ca": os.getenv("REQUESTS_CA_BUNDLE"),
            "agent_status": "initialized" if agent else "not initialized",
            "agent_mode": "full" if agent and agent.llm else "tool-only" if agent else "none"
        }
    except Exception as e:
        return {"error": str(e)}

@app.get("/debug/tools")
async def debug_tools():
    """Check if tools are working"""
    if not agent:
        return {"tools_available": False, "reason": "Agent not initialized"}
    
    try:
        # Try a simple tool call
        result = agent.compare_prices(
            specifications={"instance_type": "t3.medium"},
            regions=["us-east-1"]
        )
        return {
            "tools_available": True,
            "mode": "full" if agent.llm else "tool-only",
            "sample_result": {
                k: v.get('monthly_rate', 0) if isinstance(v, dict) else 0 
                for k, v in result.items() if k != '_metadata'
            }
        }
    except Exception as e:
        return {
            "tools_available": False,
            "error": str(e)
        }
