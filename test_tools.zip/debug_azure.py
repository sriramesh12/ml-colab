import requests
import json

def debug_azure_api():
    print("="*60)
    print("AZURE RETAIL PRICES API DEBUG")
    print("="*60)
    
    base_url = "https://prices.azure.com/api/retail/prices"
    
    # Test 1: No filters - should always work
    print("\n📌 TEST 1: No filters")
    try:
        response = requests.get(base_url, params={"api-version": "2023-01-01"}, timeout=10)
        print(f"Status Code: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Success! Found {len(data.get('Items', []))} total items")
            print(f"Sample item: {json.dumps(data['Items'][0], indent=2)[:200]}...")
        else:
            print(f"❌ Failed: {response.text[:200]}")
    except Exception as e:
        print(f"❌ Exception: {e}")
    
    # Test 2: Filter by service only
    print("\n📌 TEST 2: Filter by service (Virtual Machines)")
    try:
        params = {
            "$filter": "serviceName eq 'Virtual Machines'",
            "api-version": "2023-01-01"
        }
        print(f"Filter: {params['$filter']}")
        response = requests.get(base_url, params=params, timeout=10)
        print(f"Status Code: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Found {len(data.get('Items', []))} VM SKUs")
        else:
            print(f"❌ Failed: {response.text[:200]}")
    except Exception as e:
        print(f"❌ Exception: {e}")
    
    # Test 3: Filter by region only
    print("\n📌 TEST 3: Filter by region (eastus)")
    try:
        params = {
            "$filter": "armRegionName eq 'eastus'",
            "api-version": "2023-01-01"
        }
        print(f"Filter: {params['$filter']}")
        response = requests.get(base_url, params=params, timeout=10)
        print(f"Status Code: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Found {len(data.get('Items', []))} items in eastus")
        else:
            print(f"❌ Failed: {response.text[:200]}")
    except Exception as e:
        print(f"❌ Exception: {e}")
    
    # Test 4: Filter by service and region
    print("\n📌 TEST 4: Filter by service and region")
    try:
        params = {
            "$filter": "serviceName eq 'Virtual Machines' and armRegionName eq 'eastus'",
            "api-version": "2023-01-01"
        }
        print(f"Filter: {params['$filter']}")
        response = requests.get(base_url, params=params, timeout=10)
        print(f"Status Code: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            items = data.get('Items', [])
            print(f"✅ Found {len(items)} VM SKUs in eastus")
            if items:
                print("\nSample VM SKUs in eastus:")
                for item in items[:5]:
                    print(f"  - {item.get('armSkuName')}: ${item.get('retailPrice')}/hour")
        else:
            print(f"❌ Failed: {response.text[:200]}")
    except Exception as e:
        print(f"❌ Exception: {e}")
    
    # Test 5: Look for specific instance (D2s v3)
    print("\n📌 TEST 5: Look for D2s v3 in eastus")
    try:
        params = {
            "$filter": "serviceName eq 'Virtual Machines' and armRegionName eq 'eastus' and armSkuName eq 'D2s v3'",
            "api-version": "2023-01-01"
        }
        print(f"Filter: {params['$filter']}")
        response = requests.get(base_url, params=params, timeout=10)
        print(f"Status Code: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            items = data.get('Items', [])
            if items:
                print(f"✅ Found D2s v3!")
                item = items[0]
                print(f"  Price: ${item.get('retailPrice')}/hour")
                print(f"  Unit: {item.get('unitOfMeasure')}")
                print(f"  Product: {item.get('productName')}")
            else:
                print("❌ D2s v3 not found")
        else:
            print(f"❌ Failed: {response.text[:200]}")
    except Exception as e:
        print(f"❌ Exception: {e}")
    
    # Test 6: Try with different instance name format
    print("\n📌 TEST 6: Try with different instance name format")
    try:
        params = {
            "$filter": "serviceName eq 'Virtual Machines' and armRegionName eq 'eastus' and contains(skuName, 'D2s')",
            "api-version": "2023-01-01"
        }
        print(f"Filter: {params['$filter']}")
        response = requests.get(base_url, params=params, timeout=10)
        print(f"Status Code: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            items = data.get('Items', [])
            print(f"✅ Found {len(items)} items containing 'D2s'")
            for item in items:
                print(f"  - {item.get('armSkuName')}")
        else:
            print(f"❌ Failed: {response.text[:200]}")
    except Exception as e:
        print(f"❌ Exception: {e}")

if __name__ == "__main__":
    debug_azure_api()
