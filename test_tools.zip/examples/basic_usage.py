"""
Basic usage example for Cloud Rationalization Agent
"""
import asyncio
import json
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

from src.agent import CloudRationalizationAgent
from src.models.schemas import (
    RationalizationRequest,
    CloudResource,
    BusinessConstraints,
    OptimizationGoal
)

async def main():
    """Example of using the Cloud Rationalization Agent"""
    
    # Initialize the agent
    agent = CloudRationalizationAgent(
        openai_api_key=os.getenv("OPENAI_API_KEY"),
        aws_credentials={
            'aws_access_key_id': os.getenv("AWS_ACCESS_KEY_ID"),
            'aws_secret_access_key': os.getenv("AWS_SECRET_ACCESS_KEY")
        } if os.getenv("AWS_ACCESS_KEY_ID") else None
    )
    
    print("✅ Agent initialized")
    
    # Define current infrastructure
    resources = [
        CloudResource(
            name="web-server-01",
            resource_type="compute",
            provider="aws",
            region="us-east-1",
            specifications={
                "instance_type": "t3.medium",
                "os": "Linux",
                "cpu": 2,
                "memory": 4
            },
            quantity=3,
            usage_pattern="steady",
            monthly_cost=120.00,
            fault_tolerant=False
        ),
        CloudResource(
            name="db-server-01",
            resource_type="database",
            provider="aws",
            region="us-east-1",
            specifications={
                "instance_type": "db.t3.medium",
                "engine": "postgres",
                "storage": 100
            },
            quantity=2,
            usage_pattern="steady",
            monthly_cost=200.00,
            fault_tolerant=True
        ),
        CloudResource(
            name="batch-processor-01",
            resource_type="compute",
            provider="aws",
            region="us-west-2",
            specifications={
                "instance_type": "c5.xlarge",
                "os": "Linux"
            },
            quantity=4,
            usage_pattern="batch",
            monthly_cost=320.00,
            fault_tolerant=True
        )
    ]
    
    # Define business constraints
    constraints = BusinessConstraints(
        max_budget=2000,
        min_availability="99.9%",
        compliance_requirements=["SOC2"],
        risk_tolerance="medium"
    )
    
    # Define optimization goals
    goals = [
        OptimizationGoal.COST_REDUCTION,
        OptimizationGoal.PERFORMANCE
    ]
    
    # Create request
    request = RationalizationRequest(
        current_infrastructure=resources,
        business_constraints=constraints,
        optimization_goals=goals,
        time_horizon="1 year"
    )
    
    print("\n📊 Analyzing infrastructure...")
    print(f"Total resources: {len(resources)}")
    print(f"Current monthly cost: ${sum(r.monthly_cost for r in resources):,.2f}")
    
    # Run analysis
    try:
        result = await agent.analyze(request)
        
        print("\n✅ Analysis complete!")
        print("\n" + "="*50)
        print("RESULTS")
        print("="*50)
        
        # Print summary
        print(result.analysis[:500] + "...")  # First 500 chars
        
        # Print recommendations if available
        if result.recommendations:
            print("\n📋 Top Recommendations:")
            for i, rec in enumerate(result.recommendations[:3], 1):
                print(f"\n{i}. {rec.get('title', 'N/A')}")
                print(f"   Savings: ${rec.get('savings', 0):,.2f}")
                print(f"   Risk: {rec.get('risk_level', 'N/A')}")
        
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example: Compare prices
    print("\n" + "="*50)
    print("PRICE COMPARISON")
    print("="*50)
    
    prices = await agent.compare_prices(
        resource_type="ec2",
        specifications={
            "instance_type": "t3.medium",
            "os": "Linux"
        },
        regions=["us-east-1"]
    )
    
    for provider, data in prices.items():
        if isinstance(data, dict):
            print(f"\n{provider.upper()}:")
            print(f"  Hourly: ${data.get('hourly_rate', 0):.4f}")
            print(f"  Monthly: ${data.get('monthly_rate', 0):,.2f}")

if __name__ == "__main__":
    asyncio.run(main())