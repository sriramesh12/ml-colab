# create_project.py
import os
import shutil

# Create directory structure
directories = [
    "src",
    "src/tools",
    "src/models",
    "src/utils",
    "api",
    "web",
    "cli",
    "config",
    "tests",
    "examples",
    "data",
    "logs"
]

for dir_path in directories:
    os.makedirs(dir_path, exist_ok=True)
    # Create __init__.py files
    init_path = os.path.join(dir_path, "__init__.py")
    if not os.path.exists(init_path):
        with open(init_path, "w") as f:
            f.write("# Auto-generated __init__.py\n")

print("✅ Directory structure created")