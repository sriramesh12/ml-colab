# test_tools.py
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent))

print("="*50)
print("TESTING TOOLS WITH PYDANTIC v2")
print("="*50)

try:
    from src.tools.aws_pricing import AWSPricingTool
    from src.tools.azure_pricing import AzurePricingTool
    from src.tools.gcp_pricing import GCPPricingTool
    
    print("✅ Tools imported")
    
    # Initialize without credentials
    aws = AWSPricingTool(credentials={})
    azure = AzurePricingTool(credentials={})
    gcp = GCPPricingTool(credentials={})
    
    print("✅ Tools initialized")
    
    # Test a simple call
    result = aws._run("ec2", "us-east-1", {"instance_type": "t3.medium"}, 1)
    print("✅ Tool call works")
    print(f"   Result preview: {result[:100]}...")
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
